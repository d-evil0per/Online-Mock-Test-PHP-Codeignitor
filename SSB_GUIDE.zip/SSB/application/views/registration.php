
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Deviloper" >
    <meta name="keyword" content="SSB, NDA, CDS ,AFCAT, Online mocktest, online Exam ">

    <title>SSB Registration</title>

    <!-- Bootstrap core CSS -->
    <link href="<?=base_url()?>assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="<?=base_url()?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style-responsive.css" rel="stylesheet">
      <link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
  <link rel="apple-touch-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
    <style type="text/css">
    .overlay{
				background-color:rgba(0,0,0,0.7);
				z-index:-1;
				position:fixed;
				top:0;
				left:0;
				width:100%;
				height:100%;    
    }
    .backcolor-red{
  background: #da4453;
}
    </style>
<style type="text/css">

  .color-white{
    color:#fff;
  }
  .margin-bottom-5{
  	margin-bottom: 10px;
  }
</style>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
  <header class="header margin-bottom-5" style="z-index:1039;position: absolute;margin:10px;">
             
            <!--logo start-->
            <p class="centered "><a href="javascript:void(0)"><img src="<?=base_url()?>assets/img/SSB_GUIDE.png" width="60"></a></p>
             <h5 class="centered" ><a  href="javascript:void(0)" class="logo01"><b>SSB Guide</b></a></h5>
              
          <!-- <a  href="index.html" class="logo centered"><b>SSB</b></a> -->
            <!--logo end-->
            
           
        </header>
	<div class="overlay"> </div>
	 
	  	<div class="row">
	  		
	  		<div class="col-lg-12 " id="registration">


                  <?php if(!isset($this->session->userdata['reg_payment_status'])) { ?>
	  			  	<div class="container" id="reg_form_fillup" >
	  <div class="form-login" id="reg_form">
		         		 <h2 class="form-login-heading">Register Now <br><br> <small><span class="color-white ">Step 1: Personal Details</span></small></h2>
		         		
		         		  <div class="login-wrap">
		         		  <div class="alert alert-danger" id="error_pd" style="display:none;"> </div>
		        		<input type="text" class="form-control margin-bottom-5" placeholder="Name"  id="name" autofocus required="required">
						
						 <input type="email" class="form-control margin-bottom-5" placeholder="Email" id="email" required="required" >
		            
		             <input type="text" class="form-control margin-bottom-5" placeholder="Mobile Number" maxlength="10" id="mobile" required="required" >
		            
		            <select class="form-control margin-bottom-5" placeholder="Qualification" id="qualification" required="required">
			         <option value="">Select Your Qualification</option>	
			         <option value="10th">10<sup>th</sup></option>	
			         <option value="12th">12<sup>th</sup></option>	
						<option value="Graduation">Graduation</option>	
						<option value="Post Graduation">Post Graduation</option>	
 						</select>
 						
		            <input type="text" class="form-control margin-bottom-5" placeholder="Father's Name" id="f_name" required="required">
		            
		            <input type="text" class="form-control margin-bottom-5" placeholder="Father's Mobile Number" maxlength="10" id="f_mobile" required="required">
		            
		         	<input type="text" class="form-control margin-bottom-5" id="address" placeholder="Address"  required="required">
              <input type="text" class="form-control margin-bottom-5" id="city" placeholder="City"  required="required">
              <input type="text" class="form-control margin-bottom-5" id="state"  placeholder="State"  required="required">
              <input type="text" class="form-control margin-bottom-5" id="country"  placeholder="Country"  required="required">
              <input type="text" class="form-control margin-bottom-5" id="pin" maxlength="6" placeholder="ZIP CODE"  required="required">
                    
		            
		            <button type="button" class="btn btn-theme05 btn-block"  onclick="switchtopay('reg_form','reg_c_form',1)"><i class="fa fa-arrow-right"></i> <b>Proceed</b></button>
		           
		            
		           
		
		        </div>
		        </div>

	  <div class="form-login" id="reg_c_form" style="display: none">
		         		 <h2 class="form-login-heading">Course Details <br> <br><small><span class="color-white ">Step 2: Course Selection</span></small></h2>
		         		
		         		  <div class="login-wrap">
		         		  	<div class="alert alert-danger" id="error_cd" style="display:none;"> </div>
		         		  	<input type="hidden" id="is_ssb">
		        		  <select class="form-control margin-bottom-5" placeholder="Course" id="c_name" onchange="get_course_details()" required="required">
			         	<?=$course?>
			      	
 						</select>
					
						<span class="form-control margin-bottom-5"  style="cursor: not-allowed; display:none;" id="c_duration"> </span>
						
						  <select class="form-control margin-bottom-5" id="c_toe" style="display: none;" required="required">
			       
 						</select>
		            
		             <select class="form-control margin-bottom-5"  id="c_spe"  style="display: none;" required="required">
			        					
 						</select>
		            
		            <select class="form-control margin-bottom-5" id="c_cdate" style="display: none;" required="required">
			        	
 						</select>
 						
 						<div class="margin-bottom-5" id="c_fee_div" style="display: none;">
 							<span><b>Fee Details:</b></span>
					           <br>
					           <span><i class="fa fa-rupee"></i> <b id="c_fee"></b>/- (inclusive of taxes)(Hostel+Mess+Pick & Drop Facility)</span>
					           <br><br>
					           <span><b>Registration Fee:</b></span>
					           <br>
					           <span><i class="fa fa-rupee"></i> <b id="c_reg_fee"> </b>/- (Rest fee to be paid at time of joining)</span>
					      
 						</div>
 						
		           
		     
		            <button type="button" class="btn btn-theme05 btn-block margin-bottom-5"  onclick="switchtopay('reg_c_form','reg_pay',1)"><i class="fa fa-arrow-right"></i> <b>Proceed</b></button>
		           
		            <a href="javascript:void(0)" onclick="switchtopay('reg_c_form','reg_form',0)"><i class="fa fa-arrow-left"></i> <b>Back</b></a>
		           
		            
		           
		
		        </div>
		        </div>

		        <div class="form-login " id="reg_pay" style="display: none;">
		         		 <h2 class="form-login-heading"><i class="fa fa-credit-card"></i> Pay To Sign Up <br> <br><small><span class="color-white ">Step 3: Payment</span></small></h2>
		         		  <div class="login-wrap">

		         		  	<h5 class="centered" >PAY <i class="fa fa-rupee"></i><b id="pay_fee"></b>  as Registration Fee now to complete the registration process.</h5>
                            <h6 class="centered" >For More details.</h6>
                              <center>
                            
                             <span><b>Contact Us:</b></span>
                           <br>
                           <h6 >WHATSAPP :- <b>8572857321</b><br>
                           CALL :- <b>7015173285</b></h6>
                           <br>
                            <span><b>Address:</b></span>
                           <br>
                           <h6 >Address :#35 STAFF ROAD, NEAR ARYA GIRLS COLLEGE, AMBALA CANTT</h6>

                            </center>
		         	<!-- 	  	<div id="PYTM_CODE">
		         		  <h6 class="centered" >Scan this Paytm Code</h6>
		        		<p class="centered"><img src="<?=base_url()?>assets/img/PAYTM_ORG.jpg"  width="150"></p>
		        		
		        		<h6 class="centered" >Or</h6>
		        		<a href="javascript:void(0)" onclick="toggle_pay('PYTM_CODE','UPI_CODE')"><h5 class="centered" >PAY Using UPI Code</h5></a>
		        	</div>
		        		<div id="UPI_CODE" style="display: none">
		        		<h6 class="centered" >Scan this UPI Code</h6>
		        		<p class="centered"><img src="<?=base_url()?>assets/img/UPI_ORG.JPG"  width="150"></p>
		        		<h6 class="centered" >Or</h6>
		        		<a href="javascript:void(0)" onclick="toggle_pay('UPI_CODE','PYTM_CODE')"><h5 class="centered" >PAY Using Paytm Code</h5></a>
		        	</div> -->
		        <!-- 	<center>
		        		 <span><b>Note:</b></span>
		           <br>
		           <h6 >AFTER YOU MAKE THE PAYMENT, KINDLY SEND THE PIC OR SCREENSHOT OF THE RECEIPT WITH YOUR EMAIL ID ON WHATSAPP:- <b>8572857321</b></h6>
		            

		        	</center> -->
		           		           
		            <a class="btn btn-theme05 btn-block" href="javascript:void(0)" id="reg_btn" onclick="register()"><i class="fa fa-check"></i> <b>Pay & Register</b></a>

		            <br>
                     
		              <a href="javascript:void(0)"  onclick="switchtopay('reg_pay','reg_c_form',0)"><i class="fa fa-arrow-left"></i> <b>Back</b></a>
		
		        </div>
		        </div>

					</div>


                    <?php } else { ?>

                    <?php if($this->session->userdata['reg_payment_status']) { ?>    
					<div class="container" id="thank_you">
							<div class="container" >
	  		<div class="form-login ">
		         		 <h2 class="form-login-heading">Thank You</h2>
		         		  <div class="login-wrap">
						<center>
		        	 <h6 style="color:#2ecc71;"><i class="fa fa-check-circle"></i> Payment Successful</h6> 
		           <h6 >You have been Successfully Register! </h6>	 
		             
		        	</center>
					</div>
					</div>
					</div>
					</div>

                    <?php } else { ?>
                        <div class="container">
                            <div class="container" >
            <div class="form-login ">
                         <h2 class="form-login-heading backcolor-red">Sorry</h2>
                          <div class="login-wrap">
                        <center>
                     <h6 style="color:#da4453;"><i class="fa fa-exclamation-triangle"></i> Payment Failed!</h6> 

                   <h6 >We did not receive the payment as the transaction wasn't successful. We request you retry. Please contact your bank in case your account was debited and you still see this message.</h6>  

                  
                    <a class="btn btn-theme05 btn-block" href="javascript:void(0)" id="reg_retry_btn" onclick="retrypayment()"><i class="fa fa-check"></i> <b>Retry Payment</b></a>
                    </center>
                    </div>
                    </div>
                    </div>
                    </div>


                    <?php } } ?>
	  		</div>
	  	
	  	</div>




	



	  
	  
	  	
	 

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?=base_url()?>assets/js/jquery.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="<?=base_url()?>assets/js/jquery.backstretch.min.js"></script>
  <?php if(isset($this->session->userdata['reg_payment_status'])) { ?> 
    <script type="text/javascript">
             setTimeout(function()
             {
               var url="<?=base_url()?>registration/unset_registerpay";
               $.ajax({
                        type: 'POST',   
                        url: url,
                        dataType:"JSON",
                        success:function(data)
                        {
                            window.location.reload();
                        }
                     });

               },30000);

    </script>
    <?php } ?>
    <script>
        $.backstretch("<?=base_url()?>assets/img/SSB_BG.JPG", {speed: 500});
        function toggle_loginform(element,oelement)
        {
        	$("#"+element).hide(500);
        	$("#"+oelement).show(500);
        }


    

        function retrypayment()
{
var url="<?=base_url()?>registration/register_pay";
 $.ajax({
        
         type: 'POST',   
          url: url,
        
          dataType: 'json',
          beforeSend:function()
          {
             ajaxInProgress = true;
             $("#reg_retry_btn").html(" <i class='fa fa-check'> <b> Retrying...</b>");
             
              $("#reg_retry_btn").removeAttr("onclick");
                            
             
                        },
          success: function(data) 
              {        
                 ajaxInProgress = false;
                $("#reg_retry_btn").html(" <i class='fa fa-check'> <b>Retry Payment</b>");
                
              $("#reg_retry_btn").attr("onclick","retrypayment()");
                            window.location = data['url'];
                        }
    });
}


        function register()
        {
        	var name=$("#name").val();
        	var email=$("#email").val();
        	var mobile=$("#mobile").val();
        	 var qualification=$("#qualification").val();
        	 var f_name=$("#f_name").val();
        	 var f_mobile=$("#f_mobile").val();
        	 var address=$("#address").val();
        	 var c_id=$("#c_name").val();
        	var is_ssb=$("#is_ssb").val();
        	var c_toe=$("#c_toe").val();
        	var c_spe=$("#c_spe").val();
        	var c_cdate=$("#c_cdate").val();
        	var c_reg_fee=$("#c_reg_fee").html();
        	var c_fee=$("#c_fee").html();
            var city=$("#city").val();
            var pin=$("#pin").val();
            var state=$("#state").val();
            var country=$("#country").val();
        	   var url="<?=base_url()?>registration/register_pay";
				$.ajax({
				          url:url,
				          data:{name:name,email:email,mobile:mobile,qualification:qualification,f_name:f_name,f_mobile:f_mobile,address:address,c_id:c_id,is_ssb:is_ssb,c_toe:c_toe,c_spe:c_spe,c_cdate:c_cdate,c_reg_fee:c_reg_fee,c_fee:c_fee,city:city,pin:pin,state:state,country:country},
				          type:'post',
				          dataType:"JSON",
				          beforeSend: function()
				          {
				          		$("#reg_btn").css({"curser":"not-allowed"});
				          },
				          success: function(data)
				          {
				          	window.location = data['url'];
				          }
				      });

        	
        }

         function switchtopay(element,oelement,checksum)
        {
        
        	if(checksum)
        	{
        		if(element=="reg_form")
        		{
        			var name=$("#name").val();
        			if(name=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Name is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#name").focus();
        				return false;
        			}
        			var email=$("#email").val();
        				if(email=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Email ID is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#email").focus();
        				return false;
        			}
        			var emailReg = /^[\w._-]+[+]?[\w._-]+@[\w.-]+\.[a-zA-Z]{2,6}$/;
        			if(!(emailReg.test(email)))
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Valid Email ID is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#email").val("");
        				$("#email").focus();
        				return false;
        			}
        			var mobile=$("#mobile").val();
        				if(mobile=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Please Enter Your Mobile Number.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#mobile").focus();
        				return false;
        			}
        			var intRegex = /[0-9 -()+]+$/;
					  if(!(intRegex.test(mobile)))
					        {
					      $("#error_pd").html("<b>Opps!</b> Please Enter a Valid Mobile Number.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#mobile").val("");
        				$("#mobile").focus();
        				return false;
					        }
					     
						 var qualification=$("#qualification").val();
        				if(qualification=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Please Select Your Qualification.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#qualification").focus();
        				return false;
        			} 
        			var f_name=$("#f_name").val();
        				if(f_name=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Father's Name is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#f_name").focus();
        				return false;
        			}
        			var f_mobile=$("#f_mobile").val();
        				if(f_mobile=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Father's Mobile Number is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#f_mobile").focus();
        				return false;
        			}

        			if(!(intRegex.test(f_mobile)))
					        {
					        	$("#error_pd").html("<b>Opps!</b> Your Father's Mobile Number is InValid.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#f_mobile").val("");
        				$("#f_mobile").focus();
        				return false;
					        }
        			var address=$("#address").val();
        				if(address=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Address is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#address").focus();
        				return false;
        			}
                var city=$("#city").val();
                if(city=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your city is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#city").focus();
                return false;
              }
                var state=$("#state").val();
                if(state=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your state is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#state").focus();
                return false;
              }
                var country=$("#country").val();
                if(country=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your country is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#country").focus();
                return false;
              }
                var pin=$("#pin").val();
                if(pin=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your pin code is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#pin").focus();
                return false;
              }
                  
        		}
        		else if(element=='reg_c_form')
        		{
        			var c_name=$("#c_name").val();
        			var is_ssb=$("#is_ssb").val();
        			if(c_name=="" || is_ssb=="")
        			{
        				$("#error_cd").html("<b>Opps!</b>Please Select a Course.");
        				$("#error_cd").show(0).delay(3000).hide(0);
        				$("#c_name").focus();
        				return false;
        			}
        			if(is_ssb)
        			{
        				var c_toe=$("#c_toe").val();
        				var c_spe=$("#c_spe").val();
        				if(c_toe=="")
        				{
        					$("#error_cd").html("<b>Opps!</b>Please Select Type Of Entry.");
        				$("#error_cd").show(0).delay(3000).hide(0);
        				$("#c_toe").focus();
        				return false;
        				}	
        				if(c_spe=="")
        				{
        					$("#error_cd").html("<b>Opps!</b>Please Select SSB Previous Experience.");
        				$("#error_cd").show(0).delay(3000).hide(0);
        				$("#c_spe").focus();
        				return false;
        				}
        			}

        			var c_cdate=$("#c_cdate").val();
        			if(c_cdate=="")
        			{
        				$("#error_cd").html("<b>Opps!</b>Please Select Course Commencement Date.");
        				$("#error_cd").show(0).delay(3000).hide(0);
        				$("#c_cdate").focus();
        				return false;
        			}
        		}

        	$("#"+element).fadeOut(500);
        	$("#"+oelement).fadeIn(1000);
        	// if(oelement=="reg_pay")
        	// {
        	// 	$("#registration").removeClass("col-lg-12");
        	// 	$("#registration").addClass("col-lg-4");
        	// 	$("#contact_us").fadeIn(1000);
        	// }
        	// else
        	// {
        	// $("#contact_us").fadeOut(500);	
        	// $("#registration").removeClass("col-lg-4");
        	// $("#registration").addClass("col-lg-12");
        	// }

        	}
        	else
        	{
        	$("#"+element).fadeOut(500);
        	$("#"+oelement).fadeIn(1000);
        	// $("#contact_us").fadeOut(500);	
        	// $("#registration").removeClass("col-lg-4");
        	// $("#registration").addClass("col-lg-12");
        	}




        }

         function toggle_pay(element,other_element)
        {
        	$("#"+element).hide(500);
        	$("#"+other_element).show(500);
        }






        function get_course_details()
        {
        	var c_id=$("#c_name").val();
        	if(c_id=="")
        	{
        		$("#c_duration").hide();
        		$("#c_duration").empty();
        		
        		$("#c_toe").hide();
        		$("#c_toe").empty();
        		
        		$("#c_spe").hide();
        		$("#c_spe").empty();
        		
        		$("#c_cdate").hide();
        		$("#c_cdate").empty();
        		
        		$("#c_fee_div").hide();
        		$("#c_fee").empty();
        		$("#c_reg_fee").empty();
        		

        		return false;
        	}

        	   var url="<?=base_url()?>registration/get_course_details_by_ajax";
				$.ajax({
				          url:url,
				          data:{c_id:c_id},
				          type:'post',
				          dataType:"JSON",
				          success: function(data)
				          {
				          	$("#c_duration").html(data['c_duration']);
				          	$("#c_duration").show();
				          	if(data['is_ssb']=="1")
				          	{
				          	$("#c_toe").html(data['c_teo']);
				          	$("#c_toe").show();
				          	$("#c_spe").html(data['c_spe']);
				          	$("#c_spe").show();
				          	$("#is_ssb").val(1);
				          		
				          	}
				          	else
				          	{
				          	$("#is_ssb").val(0);
				          	$("#c_toe").empty();
				          	$("#c_toe").hide();
				          	$("#c_spe").empty();
				          	$("#c_spe").hide();
				          	}
				          	 	$("#c_cdate").html(data['c_cdate']);
				          	 	$("#c_cdate").show();
				          	 	$("#c_fee").html(data['c_fee']);
				          	 	$("#pay_fee").html(data['c_reg_fee']);
				          	 	$("#c_reg_fee").html(data['c_reg_fee']);
				          	 	$("#c_fee_div").show();
				          	
				          }

				});

        }
    </script>


  </body>
</html>
