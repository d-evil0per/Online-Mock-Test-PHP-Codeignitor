<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Test Series- View/Edit </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title">Test Series Details</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <?php if($viewtype=="VIEW") { ?>
              <div class="col-12" style="overflow-x:auto">
                
              <table id="ts_data_table" class="table table-bordered table-striped" style="font-size: .7em;">
                <thead>
                <tr>
                  <th>Test Id</th>
                  <th>Test Key</th>
                  <th>Test Name</th>
                  <th>Test Description</th>
                  <th>Test Instructions</th>
                  <th>Test Image Url</th>
                  <th>Test Time Limit</th>
                  <th>Test Type</th>
                  <th>Test Status</th>
                  <th>Test Enrollment Fee</th>
                  <th>Test TimeStamp</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
               <?php foreach ($reg_det->result() as $regkey) { ?>
                 <tr>
                  <td><?=$regkey->id?></td>
                  <td><?=$regkey->test_key?></td>
                  <td><?=$regkey->test_name?></td>
                  <td><?=$regkey->test_description?></td>
                  <td><?=$regkey->test_instructions?></td>
                  <td><?=$regkey->test_img_url?></td>
                  <td><?=$regkey->test_time_limit?></td>
                  <td><?=$regkey->test_type?></td>
                  <td><?php if($regkey->test_status=="1"){ echo "ACTIVE"; }else{ echo "IN-ACTIVE"; } ?></td>
                  
                  <td><?=$regkey->test_enrollment_fee?></td>
                  <td><?=$regkey->test_timestamp?></td>
                  <td><a href="<?=base_url()?>admin/test-series/?type=ts-view-edit&test_id=<?=$regkey->id?>">Edit</a></td>
                 </tr>
              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                    <th>Test Id</th>
                  <th>Test Key</th>
                  <th>Test Name</th>
                  <th>Test Description</th>
                  <th>Test Instructions</th>
                  <th>Test Image Url</th>
                  <th>Test Time Limit</th>
                  <th>Test Type</th>
                  <th>Test Status</th>
                  <th>Test Enrollment Fee</th>
                  <th>Test TimeStamp</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
              
            </div>
            <?php } else if($viewtype=="EDIT") { ?>
            <div class="col-6">
              <input type="hidden" name="tid" id="tid" value="<?=$tid?>">
              <input type="hidden" name="has_changes" id="has_changes" value="0">
                <div class="form-group">
                    <label for="t_name">Test Name <sup>*</sup></label>
                    <input type="text" class="form-control" id="t_name" placeholder="Test name" value="<?=$test_name?>">
                  </div>
                  <div class="form-group">
                    <label for="t_desc">Test Description <sup>*</sup></label>
                    <textarea class="form-control" rows="10" id="t_desc" placeholder="Test Description" ><?=$test_description?></textarea> 
                  </div>
                  <div class="form-group">
                    <label for="t_instr">Test Instructions <sup>*</sup></label>
                    <textarea class="form-control" rows="10" id="t_instr" placeholder="Test Instructions" ><?=$test_instructions?></textarea> 
                  </div>
                  <div class="form-group">
                    <label for="t_img">Test Image Url <sup>*</sup></label>
                    <img src="<?=$test_img_url?>" width="400" height="200" id="t_img">
                    </div>
                    <div class="form-group">
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" accept=".png, .jpg, .jpeg"  name="pic_upload" id="pic_upload" onchange="previewFile(this)">
                        <label class="custom-file-label" for="pic_upload">Choose file</label>
                      </div>
                    </div>
                  </div>
                   <div class="form-group">
                    <label for="t_time">Test Time Limit <sup>*</sup></label>
                    <input type="number" class="form-control" min="1" id="t_time" placeholder="Test Time Limit " value="<?=$test_time_limit?>">
                  </div>
                  
                   <div class="form-group">
                    <label for="t_type">Test Type  <sup>*</sup></label>
                     <small><p>Note: OBJECTIVE For Multiple Choice And APPERCEPTION for Image Type Questions</p></small>
                    <select class="form-control" id="t_type">
                      <option value="" <?php if($test_type=="") { echo "Selected"; } ?>> Select Test Type</option>
                      <option value="OBJECTIVE" <?php if($test_type=="OBJECTIVE") { echo "Selected"; } ?>> OBJECTIVE</option>
                      <option value="APPERCEPTION" <?php if($test_type=="APPERCEPTION") { echo "Selected"; } ?>> APPERCEPTION</option>
                    </select>
                  </div>
                   <div class="form-group">
                    <label for="t_status">Test Status  <sup>*</sup></label>
                     <small><p>Note: ACTIVE For Activting Test And IN-ACTIVE for Deactivting Test</p></small>
                    <select class="form-control" id="t_status">
                      <option value="" <?php if($test_status=="") { echo "Selected"; } ?>> Select Test Status</option>
                      <option value="1" <?php if($test_status=="1") { echo "Selected"; } ?>>ACTIVE</option>
                      <option value="0" <?php if($test_status=="0") { echo "Selected"; } ?>>IN-ACTIVE</option>
                    </select>
                  </div>
                   <div class="form-group">
                    <label for="t_efee">Test Enrollment Fee <sup>*</sup></label>
                    <input type="number" class="form-control" min="0" id="t_efee" placeholder="Test Enrollment Fee" value="<?=$test_enrollment_fee?>">
                  </div>
                   
                 
                <div  id="error_msg" style="color:#ff0000;display:none">
               
              </div>  
            </div>
              <?php }  else {?>
               <div class="col-6">
              <input type="hidden" name="has_changes" id="has_changes" value="0">

                <div class="form-group">
                    <label for="t_name">Test Name <sup>*</sup></label>
                    <input type="text" class="form-control" id="t_name" placeholder="Test name" value="">
                  </div>
                  <div class="form-group">
                    <label for="t_desc">Test Description <sup>*</sup></label>
                    <textarea class="form-control" row=10 id="t_desc" placeholder="Test Description" value=""></textarea> 
                  </div>
                  <div class="form-group">
                    <label for="t_instr">Test Instructions <sup>*</sup></label>
                    <textarea class="form-control" row=10 id="t_instr" placeholder="Test Instructions" value=""></textarea> 
                  </div>
                  <div class="form-group">
                    <label for="t_img">Test Image Url <sup>*</sup></label>
                    <img src="<?=base_url()?>assets/img/iconNoAvatar.png" width="400" height="200" id="t_img">
                  </div>

                    <div class="form-group">
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" accept=".png, .jpg, .jpeg"  name="pic_upload" id="pic_upload" onchange="previewFile(this)">
                        <label class="custom-file-label" for="pic_upload">Choose file</label>
                      </div>
                    </div>
                  </div>
                   <div class="form-group">
                    <label for="t_time">Test Time Limit <sup>*</sup></label>
                    <input type="number" class="form-control" min="1" id="t_time" placeholder="Test Time Limit " value="">
                  </div>
                  
                   <div class="form-group">
                    <label for="t_type">Test Type  <sup>*</sup></label>
                     <small><p>Note: OBJECTIVE For Multiple Choice And APPERCEPTION for Image Type Questions</p></small>
                    <select class="form-control" id="t_type">
                      <option value=""> Select Test Type</option>
                      <option value="OBJECTIVE"> OBJECTIVE</option>
                      <option value="APPERCEPTION"> APPERCEPTION</option>
                    </select>
                  </div>
                   <div class="form-group">
                    <label for="t_status">Test Status  <sup>*</sup></label>
                     <small><p>Note: ACTIVE For Activting Test And IN-ACTIVE for Deactivting Test</p></small>
                    <select class="form-control" id="t_status">
                      <option value=""> Select Test Status</option>
                      <option value="1">ACTIVE</option>
                      <option value="0">IN-ACTIVE</option>
                    </select>
                  </div>
                   <div class="form-group">
                    <label for="t_efee">Test Enrollment Fee <sup>*</sup></label>
                    <input type="number" class="form-control" min="0" id="t_efee" placeholder="Test Enrollment Fee" value="">
                  </div>
                 
                <div  id="error_msg" style="color:#ff0000;display:none">
               
              </div>  
            </div>
              <?php } ?>
            </div>
            <?php if($viewtype=="EDIT") { ?>
            <div class="card-footer">
              
                  <button type="button" class="btn btn-primary"  id="btn_update" onclick="update()">Update</button>
                  <a  class="btn btn-secondary" href="javascript:void(0)" onclick="delete_test()" >Delete</a>
                </div>
                <?php } ?>
                <?php if($viewtype=="ADD") { ?>
            <div class="card-footer">
              
                  <button type="button" class="btn btn-primary"  id="btn_update" onclick="add()">ADD</button>
                  <a  class="btn btn-secondary" href="<?=base_url()?>admin" >Cancel</a>
                </div>
                <?php } ?>
            <!-- /.card-body -->
          </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
     </div>
     <?php if($viewtype=="VIEW") { ?>
     <script>
  $(function () {
    
    $('#ts_data_table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
<?php } else if ($viewtype=="EDIT"){ ?>
<script type="text/javascript">
   function previewFile(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
       
      $("#has_changes").val(1);
      
           $("#t_img").attr("src",e.target.result);
          
           
      };
      reader.readAsDataURL(input.files[0]);
    }
  }

  function delete_test()
{
  var tid=$("#tid").val();
   var url="<?=base_url()?>admin_dashboard/delete_ts";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{tid:tid},
                         dataType: 'json',
                           
                              success: function(data) 
                                  {  
                                   
                                      if(data['status']=="success")
                                      {
                                        window.location=data['url'];
                                      }
                                  }
                                });
}



  function update()
  {
    var tid=$("#tid").val();
    var t_name=$("#t_name").val();
    var t_desc=$("#t_desc").val();
    var t_instr=$("#t_instr").val();
    var t_img=$("#t_img").attr("src");
    var t_time=$("#t_time").val();
    var t_type=$("#t_type").val();
    var t_status=$("#t_status").val();
    var t_efee=$("#t_efee").val();
    var has_changes=$("#has_changes").val();


    if(t_name=="" || t_desc=="" || t_instr=="" || t_img=="" || t_time=="" || t_type=="" || t_status=="" || t_efee=="" )
    {
      $("#error_msg").html("Please  Fill The  '*' Required Fields ");
      $("#error_msg").show(0).delay(3000).hide(0);
      return false;
    }

       var url="<?=base_url()?>admin_dashboard/update_ts";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{tid:tid,t_name:t_name,t_desc:t_desc,t_instr:t_instr,t_img:t_img,t_time:t_time,t_type:t_type,t_status:t_status,t_efee:t_efee,has_changes:has_changes},
                         dataType: 'json',
                            beforSend:function()
                            {
                              $("#btn_update").html("Updating..");
                              $("#btn_update").removeAttr("onclick");
                            },
                              success: function(data) 
                                  {  
                                    $("#btn_update").html("Update");
                                    $("#btn_update").attr("onclick","update()");
                                      if(data['status']=="success")
                                      {
                                        window.location=data['url'];
                                      }
                                  }
                                });
                            

  }
</script>
<?php } else {  ?>
<script type="text/javascript">
   function previewFile(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
       
      $("#has_changes").val(1);
      
           $("#t_img").attr("src",e.target.result);
          
           
      };
      reader.readAsDataURL(input.files[0]);
    }
  }
  function add()
  {
    var tid=$("#tid").val();
    var t_name=$("#t_name").val();
    var t_desc=$("#t_desc").val();
    var t_instr=$("#t_instr").val();
        var t_img=$("#t_img").attr("src");
    var t_time=$("#t_time").val();
    var t_type=$("#t_type").val();
    var t_status=$("#t_status").val();
    var t_efee=$("#t_efee").val();
var has_changes=$("#has_changes").val();
if(has_changes=="0")
{
   $("#error_msg").html("Image is  Required  ");
      $("#error_msg").show(0).delay(3000).hide(0);
      return false;
}

    if(t_name=="" || t_desc=="" || t_instr=="" || t_img=="" || t_time=="" || t_type=="" || t_status=="" || t_efee=="" )
    {
      $("#error_msg").html("Please  Fill The  '*' Required Fields ");
      $("#error_msg").show(0).delay(3000).hide(0);
      return false;
    }

       var url="<?=base_url()?>admin_dashboard/add_ts";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{tid:tid,t_name:t_name,t_desc:t_desc,t_instr:t_instr,t_img:t_img,t_time:t_time,t_type:t_type,t_status:t_status,t_efee:t_efee,has_changes:has_changes},
                         dataType: 'json',
                            beforSend:function()
                            {
                              $("#btn_update").html("ADD");
                              $("#btn_update").removeAttr("onclick");
                            },
                              success: function(data) 
                                  {  
                                    $("#btn_update").html("ADD");
                                    $("#btn_update").attr("onclick","add()");
                                      if(data['status']=="success")
                                      {
                                        window.location=data['url'];
                                      }
                                  }
                                });
                            

  }
</script>
<?php } ?>