<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">TEST SETS- View/Edit </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 <?php if($viewtype=="SET") { ?>
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title">Test SETs Details</h3>
            </div>
            <div class="card-body">
              <div class="col-12" style="overflow-x:auto">
                
              <table id="regist_data_table" class="table table-bordered table-striped" style="font-size: .7em;">
                <thead>
                <tr>
                  <th>SET Id</th>
                  <th>SET For</th>
                  <th>SET Name</th>
                
                  <th>SET Status</th>
                  <th>SET Created On</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    <?php foreach ($set_det->result() as $regkey) { ?>
                 <tr>
                  <td><?=$regkey->set_id?></td>
                  <td><?=$regkey->test_name?></td>
                  <td><?=$regkey->test_set_name?></td>
                  
                  <td><?php if($regkey->test_set_status){ echo "ACTIVE"; }else{ echo "IN-ACTIVE"; } ?></td>
                  
                  <td><?=$regkey->test_set_timestamp?></td>
                  <td><a href="<?=base_url()?>admin/set-det/?set_id=<?=$regkey->set_id?>">VieW/Edit</a></td>
                 </tr>
              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                    <th>SET Id</th>
                  <th>SET For</th>
                  <th>SET Name</th>
                
                  <th>SET Status</th>
                  <th>SET Created On</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
              
            </div>
            </div>
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>

<?php } else { ?>
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title"><?=$sname?> Question Details</h3>
              <input type="hidden" name="set_id" id="set_id" value="<?=$set_id?>">
            </div>
            <div class="card-body">
              <div class="col-12" style="overflow-x:auto">
                
              <table id="regist_data_table" class="table table-bordered table-striped" style="font-size: .7em;">
                <thead>
                <tr>
                  <th>Question Id</th>
                  <th>SET Name</th>
                   <th>SET Type</th>
                  <th>Questions </th>
                
                  <th>Annswer options</th>
                  <th>Correct Anwser</th>
                  <th>Question Status</th>
                  <th>Question Created ON</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                
                    <?php foreach ($ques_det->result() as $regkey) { ?>
                 <tr>
                  <td><?=$regkey->question_id?></td>
                  <td><?=$regkey->test_set_name?></td>
                  <td><?=$stype?></td>
                  <td><?=$regkey->question_content?></td>
                  
                  <td><?=$regkey->question_options?></td>
                  
                  <td><?=$regkey->question_correct_option?></td>
                  <td><?=$regkey->question_status?></td>
                  <td><?=$regkey->question_timestamp?></td>
                  <td><a href="<?=base_url()?>admin/ques-set/?ques_id=<?=$regkey->question_id?>&ques_type=<?=$stype?>">VieW/Edit</a></td>
                 </tr>
              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                  <th>Question Id</th>
                  <th>SET Name</th>
                  <th>SET Type</th>
                  <th>Questions </th>
                
                  <th>Annswer options</th>
                  <th>Correct Anwser</th>
                  <th>Question Status</th>
                  <th>Question Created ON</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
              
            </div>
            </div>
            <div class="card-footer">
              
                  <button type="button" class="btn btn-primary"  id="btn_update" onclick="delete_set()">DELETE SET</button>
                  
                </div>
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
<?php } ?>

    <!-- /.content -->
     </div>
          <script>
  $(function () {
    
    $('#regist_data_table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
 <?php if($viewtype=="SET-VIEW") { ?>
 <script type="text/javascript">
   
   function delete_set()
   {
     var set_id=$("#set_id").val();
   var url="<?=base_url()?>admin_dashboard/delete_set";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{set_id:set_id},
                         dataType: 'json',
                           
                              success: function(data) 
                                  {  
                                   
                                      if(data['status']=="success")
                                      {
                                        window.location=data['url'];
                                      }
                                  }
                                });
   }
 </script>
 <?php } ?>