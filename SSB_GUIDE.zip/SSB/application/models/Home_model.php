<?php 
class Home_model extends CI_Model{
    function __construct() {
        parent::__construct();
$this->load->database();
    }


function gettest_allseries()
{
	return $this->db->query("SELECT * FROM test_series ");
}

function chkuid($val)
{
	return $this->db->query("SELECT COUNT(*) as num FROM users WHERE user_id='$val'")->row()->num;
}

function chkemail($val)
{
	return $this->db->query("SELECT COUNT(*) as num FROM users WHERE user_email='$val'")->row()->num;
}

function gettestdetails($key)
{
	return $this->db->query("SELECT * FROM test_series WHERE test_key='$key'")->row();
}


function getuserby_userid_pass($id,$pass)
{
	return $this->db->query("SELECT * FROM users WHERE user_id='$id' AND user_passkey='$pass'");
}

function updatepass($id,$str)
{
	return $this->db->query("UPDATE users SET user_passkey='".md5($str)."' WHERE user_email='$id'");
}
function insert_signup($data)
{
	$this->db->insert("users",$data);
	return $this->db->insert_id();
}

function save_notification($data)
{
	$this->db->insert("user_notification",$data);
	
}

function getuser_details($id)
{
	return $this->db->query("SELECT * FROM users WHERE id=$id")->row();
}

function getnotificationsALL($id)
{
	return $this->db->query("SELECT * FROM user_notification WHERE notification_to=$id ");
}

function gettest_details($key)
{
	$test=explode(",",$key);
	$str="";
	foreach ($test as $value) {
		if($str=="")
		{
		$str.='"'.$value.'"';	
		}
		else
		{
			$str.=',"'.$value.'"';
		}
		
	}
	return $this->db->query("SELECT * FROM test_series WHERE test_key IN (".$str.")");
}

function getrecommdation_test($test_arr)
{
	$test=explode(",",$test_arr);
	$str="";
	foreach ($test as $value) {
		if($str=="")
		{
		$str.='"'.$value.'"';	
		}
		else
		{
			$str.=',"'.$value.'"';
		}
		
	}
	return $this->db->query("SELECT * FROM test_series WHERE test_key NOT IN (".$str.")");
}

function getdistinct_test_date()
{
	return $this->db->query("SELECT DISTINCT(DATE(test_timestamp)) as dtime FROM test_scores where test_status=1");
}


function getusertestdetails($id)
{

	return $this->db->query("SELECT * FROM test_scores WHERE user_id=$id " );
}

function getnotifications($id)
{

	return $this->db->query("SELECT * FROM user_notification WHERE notification_to=$id AND notification_status=0 Order BY notification_timestamp DESC" );
}
function setstatus_notification($id)
{
	$this->db->query("UPDATE user_notification SET notification_status=1 WHERE id=$id");
}



function update_profile($data,$where)
{
	$this->db->where($where);
	$this->db->update("users",$data);
}


function ifalreadyenroll($key,$id)
{
	return $this->db->query("SELECT COUNT(*) as num FROM users WHERE (FIND_IN_SET('".$key."',user_selected_test)>0) AND id=$id")->row()->num;
}

function getsets_id($key)
{
	return $this->db->query("SELECT * FROM test_sets WHERE test_set_for='$key' AND test_set_status=1");
}

function getset_question_count($id)
{
	return $this->db->query("SELECT COUNT(*) as num FROM test_sets_questions WHERE set_id=$id AND question_status=1")->row()->num;
}


function getquestions($set,$start,$end)
{
	return $this->db->query("SELECT * FROM test_sets_questions WHERE set_id=$set AND question_status=1 LIMIT $start,$end")->row();
}

function getcorrect_ans($q)
{
	return $this->db->query("SELECT question_correct_option FROM test_sets_questions WHERE question_id=$q ")->row()->question_correct_option;
}

function inser_test_score($data)
{
	$this->db->insert("test_scores",$data);
	return $this->db->insert_id();
}
function save_ssb_answer($data)
{
	$this->db->insert("user_ssb_answers",$data);
}
function update_test_score($data,$where)
{
	$this->db->where($where);
	$this->db->update("test_scores",$data);
}






}

?>