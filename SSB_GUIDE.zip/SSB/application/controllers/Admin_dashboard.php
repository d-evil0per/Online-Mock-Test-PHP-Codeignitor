<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_dashboard extends CI_Controller {

function __construct() {
        parent::__construct();

 $this->load->model("admin_dashboard_model");

 $this->load->helper('url');
 $this->load->library('user_agent');
  require_once ("assets/PHPMailer/PHPMailerAutoload.php");
  include APPPATH . 'third_party/Crypto.php';

   // require_once 'assests/function.resize.php';
 // $this->load->helper('seo_helper');
  
 $this->admin_user_id="";


   $this->getsession_data();
       

 }

  function getsession_data()
  {
       if(isset($this->session->userdata['admin_user_id']))
       {
            $this->user_id = $this->session->userdata['admin_user_id'];
            
           
        }  


  }

 function loggedin()
 {
    
    if(!isset($this->session->userdata['admin_user_id'])){
        
  return 0;
    }
    else
    {
      return 1;
    }
    

 }

function logout()
{
	$session_data = array('admin_user_id');
    $this->session->unset_userdata($session_data);
	header("Location:".base_url()."admin");
}

	public function index()
	{
		if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}
		// dashboard body data
			$no_of_regis=$this->admin_dashboard_model->getdashcard_data("REGISTRATION");
			$no_of_signups=$this->admin_dashboard_model->getdashcard_data("SIGNUPS");
			$total_revenue=$this->admin_dashboard_model->getdashcard_data("REVENUE");
			$no_of_transactions=$this->admin_dashboard_model->getdashcard_data("TRANSACTIONS");
			$latest_signups=$this->admin_dashboard_model->getdashdata_lists("SIGNUPS");
			$latest_registrations=$this->admin_dashboard_model->getdashdata_lists("REGISTRATION");
			$latest_transactions=$this->admin_dashboard_model->getdashdata_lists("TRANSACTIONS");
			$latest_ssb_submit=$this->admin_dashboard_model->getdashdata_lists("SSB_SUBMIT");


			$data_body=array();
			$data_body['no_of_regis']=$no_of_regis | 0;
			$data_body['no_of_signups']=$no_of_signups | 0;
			$data_body['total_revenue']=$total_revenue | 0;
			$data_body['no_of_transactions']=$no_of_transactions | 0;

			$data_body['latest_signups']=$latest_signups;
			$data_body['latest_registrations']=$latest_registrations;
			$data_body['latest_transactions']=$latest_transactions;
			$data_body['latest_ssb_submit']=$latest_ssb_submit;
		// dashboard body data ends
		$this->load->view('admin_header');

		$this->load->view('admin_dashboard',$data_body);
		$this->load->view('admin_footer');
	}

	public function login()
	{
			if($this->loggedin())
			{
				header("Location:".base_url()."admin");
			}
		$this->load->view('admin_login');
	}


	function signin()
	{
		$uid=$_POST['uid'];
		$pass=$_POST['pass'];
		$chkuser=$this->admin_dashboard_model->chkuser($uid,$pass);
		if($chkuser)
		{
			$session_data = array('admin_user_id'=>$uid);
    		$this->session->set_userdata($session_data);
    		$res['status']="success";
    		$res['url']=base_url()."admin";
		}
		else
		{
			$res['status']="failure";
		}
		echo json_encode($res);
	}


function registration_details()
{
	if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}
	if(!isset($_GET['type']))
	{
		header("Location:".base_url()."admin");
	}

	if($_GET['type']=="rd-view-edit")
	{
		if(isset($_GET['course_id']))
	{
		$cid=$_GET['course_id'];
		$reg_det=$this->admin_dashboard_model->getreg_det_byid($cid);
		$data['cid']=$cid;
		$data['course_name']=$reg_det->course_name;
		$data['course_duration']=$reg_det->course_duration;
		$data['type_of_entry']=$reg_det->type_of_entry;
		$data['previous_experience']=$reg_det->previous_experience;
		$data['course_commencement_date']=$reg_det->course_commencement_date;
		$data['fee_amount']=$reg_det->fee_amount;
		$data['registration_fee']=$reg_det->registration_fee;
		$data['viewtype']="EDIT";
	}
	else
	{
		$reg_det=$this->admin_dashboard_model->getreg_det();
		$data['reg_det']=$reg_det;
		$data['viewtype']="VIEW";
	}
	}
	else if($_GET['type']=="rd-add") {
		$data['viewtype']="ADD";

	}
	else {
		header("Location:".base_url()."admin");
	}
	
		




		$this->load->view('admin_header');
		$this->load->view('admin_registration_details',$data);
		$this->load->view('admin_footer');
}

function update_reg_det()
{
	$cid=$_POST['cid'];
	$c_name=$_POST['c_name'];
	$c_duration=$_POST['c_duration'];
	$c_toe=$_POST['c_toe'];
	$c_spe=$_POST['c_spe'];
	$c_cdate=$_POST['c_cdate'];
	$c_fee=$_POST['c_fee'];
	$c_rfee=$_POST['c_rfee'];

	$data_update = array();
	$where['course_id']=$cid;
	$data_update['course_name']=$c_name;
	$data_update['course_duration']=$c_duration;
	$data_update['type_of_entry']=$c_toe;
	$data_update['previous_experience']=$c_spe;
	$data_update['course_commencement_date']=$c_cdate;
	$data_update['fee_amount']=$c_fee;
	$data_update['registration_fee']=$c_rfee;

	$this->admin_dashboard_model->update_reg_det($data_update,$where);
	$res['status']="success";
	$res['url']=base_url()."admin/registration-details/?type=rd-view-edit";
	echo json_encode($res);

}

function update_ts()
{
	$tid=$_POST['tid'];
	$test_name=$_POST['t_name'];
	$test_description=$_POST['t_desc'];
	$test_instructions=$_POST['t_instr'];
	$test_img_url=$_POST['t_img'];
	$test_time_limit=$_POST['t_time'];
	$test_type=$_POST['t_type'];
	$test_status=$_POST['t_status'];
	$test_enrollment_fee=$_POST['t_efee'];
	$has_changes=$_POST['has_changes'];

	if($has_changes)
	{
		
		$path=$_SERVER['DOCUMENT_ROOT']."/assets/admin/uploads/test_series/";


		    $image_parts = explode(";base64,", $test_img_url);
			$image_type_aux = explode("image/", $image_parts[0]);
			$image_type = $image_type_aux[1];
			$image_base64 = base64_decode($image_parts[1]);
			date_default_timezone_set('Australia/Melbourne');
			 $date = date('m/d/Yh:i:sa', time());
			 $rand=rand(10000,99999);
			 $encname=$date.$rand;
			$file = md5($encname) .'.'.$image_type;
			$filepath=$path.$file;
			if (!file_exists($path)) {
                                   mkdir($path, 0777, true);
                                   }
			file_put_contents($filepath, $image_base64);
			$img_url=base_url()."assets/admin/uploads/test_series/".$file;
		 // $res['filepath']=$filepath;
	}
	else
	{
		$img_url=$test_img_url;
	}



	$data_update = array();
		$where['id']=$tid;
		$data_update['test_name']=$test_name;
		$data_update['test_description']=$test_description;
		$data_update['test_instructions']=$test_instructions;
		$data_update['test_img_url']=$img_url;
		$data_update['test_time_limit']=$test_time_limit;
		$data_update['test_type']=$test_type;
		$data_update['test_status']=$test_status;
		$data_update['test_enrollment_fee']=$test_enrollment_fee;
		

	$this->admin_dashboard_model->update_ts($data_update,$where);
	$res['status']="success";
	$res['url']=base_url()."admin/test-series/?type=ts-view-edit";
	echo json_encode($res);

}

function delete_ques()
{
	$ques_id=$_POST['ques_id'];
	$this->admin_dashboard_model->del_ques($ques_id);
	$res['status']="success";
	$res['url']=base_url()."admin/set-det";
	echo json_encode($res);

}
function update_ques()
{
	$ques_id=$_POST['ques_id'];
	$ques=$_POST['ques'];
	$ques_type=$_POST['ques_type'];

	$ques_status=$_POST['ques_status'];
	$where['question_id']=$ques_id;
	
	$data_update['question_status']=$ques_status;

	if($ques_type=="OBJECTIVE")
	{
			$ques_opt=$_POST['ques_opt'];
			$ques_c_opt=$_POST['ques_c_opt'];
			$data_update['question_options']=$ques_opt;
			$data_update['question_correct_option']=$ques_c_opt;
			$data_update['question_content']=$ques;
	}
	else
	 {
	 	$path=$_SERVER['DOCUMENT_ROOT']."/assets/admin/uploads/questions/";


		    $image_parts = explode(";base64,", $ques);
			$image_type_aux = explode("image/", $image_parts[0]);
			$image_type = $image_type_aux[1];
			$image_base64 = base64_decode($image_parts[1]);
			date_default_timezone_set('Australia/Melbourne');
			 $date = date('m/d/Yh:i:sa', time());
			 $rand=rand(10000,99999);
			 $encname=$date.$rand;
			$file = md5($encname) .'.'.$image_type;
			$filepath=$path.$file;
			if (!file_exists($path)) {
                                   mkdir($path, 0777, true);
                                   }
			file_put_contents($filepath, $image_base64);
			$data_update['question_content']=base_url()."assets/admin/uploads/questions/".$file;
			$res['filepath']=$filepath;
	}

	// print_r($data_update);
	$this->admin_dashboard_model->update_ques($data_update,$where);
	$res['status']="success";
	// $res['url']=base_url()."admin/set-det";
	echo json_encode($res);
	
}

function add_ts()
{
	$tid=$_POST['tid'];
	$test_name=$_POST['t_name'];
	$test_description=$_POST['t_desc'];
	$test_instructions=$_POST['t_instr'];
	$test_img_url=$_POST['t_img'];
	$test_time_limit=$_POST['t_time'];
	$test_type=$_POST['t_type'];
	$test_status=$_POST['t_status'];
	$test_enrollment_fee=$_POST['t_efee'];
	$has_changes=$_POST['has_changes'];

	if($has_changes)
	{
		
		$path=$_SERVER['DOCUMENT_ROOT']."/assets/admin/uploads/test_series/";


		    $image_parts = explode(";base64,", $test_img_url);
			$image_type_aux = explode("image/", $image_parts[0]);
			$image_type = $image_type_aux[1];
			$image_base64 = base64_decode($image_parts[1]);
			date_default_timezone_set('Australia/Melbourne');
			 $date = date('m/d/Yh:i:sa', time());
			 $rand=rand(10000,99999);
			 $encname=$date.$rand;
			$file = md5($encname) .'.'.$image_type;
			$filepath=$path.$file;
			if (!file_exists($path)) {
                                   mkdir($path, 0777, true);
                                   }
			file_put_contents($filepath, $image_base64);
			$img_url=base_url()."assets/admin/uploads/test_series/".$file;
		 // $res['filepath']=$filepath;
	}
	else
	{
		$res['status']="failure";
	
	echo json_encode($res);
	exit;
	}



	$data_insert = array();
			date_default_timezone_set('Australia/Melbourne');
			 $date = date('m/d/Yh:i:sa', time());
			 $rand=rand(10000,99999);
			 $encname=$date.$rand;

		$data_insert['test_key']=md5($test_name.$encname);
		$data_insert['test_name']=$test_name;
		$data_insert['test_description']=$test_description;
		$data_insert['test_instructions']=$test_instructions;
		$data_insert['test_img_url']=$img_url;
		$data_insert['test_time_limit']=$test_time_limit;
		$data_insert['test_type']=$test_type;
		$data_insert['test_status']=$test_status;
		$data_insert['test_enrollment_fee']=$test_enrollment_fee;
		

	$this->admin_dashboard_model->add_ts($data_insert);
	$res['status']="success";
	$res['url']=base_url()."admin/test-series/?type=ts-view-edit";
	echo json_encode($res);

}

function add_reg_det()
{
	$cid=$_POST['cid'];
	$c_name=$_POST['c_name'];
	$c_duration=$_POST['c_duration'];
	$c_toe=$_POST['c_toe'];
	$c_spe=$_POST['c_spe'];
	$c_cdate=$_POST['c_cdate'];
	$c_fee=$_POST['c_fee'];
	$c_rfee=$_POST['c_rfee'];

	$data_insert = array();
	
	$data_insert['course_name']=$c_name;
	$data_insert['course_duration']=$c_duration;
	$data_insert['type_of_entry']=$c_toe;
	$data_insert['previous_experience']=$c_spe;
	$data_insert['course_commencement_date']=$c_cdate;
	$data_insert['fee_amount']=$c_fee;
	$data_insert['registration_fee']=$c_rfee;

	$this->admin_dashboard_model->add_reg_det($data_insert);
	$res['status']="success";
	$res['url']=base_url()."admin/registration-details/?type=rd-view-edit";
	echo json_encode($res);

}

function delete_reg_det()
{
	$cid=$_POST['cid'];
	$this->admin_dashboard_model->del_reg_det($cid);
	$res['status']="success";
	$res['url']=base_url()."admin/registration-details/?type=rd-view-edit";
	echo json_encode($res);

}

function delete_ts()
{
	$tid=$_POST['tid'];
	$this->admin_dashboard_model->del_ts($tid);
	$res['status']="success";
	$res['url']=base_url()."admin/test-series/?type=ts-view-edit";
	echo json_encode($res);

}

function test_series()
{
	if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}
	if(!isset($_GET['type']))
	{
		header("Location:".base_url()."admin");
	}

	if($_GET['type']=="ts-view-edit")
	{
		if(isset($_GET['test_id']))
	{
		$tid=$_GET['test_id'];
		$reg_det=$this->admin_dashboard_model->gettest_series_byid($tid);
		$data['tid']=$tid;

		$data['test_name']=$reg_det->test_name;
		$data['test_description']=$reg_det->test_description;
		$data['test_instructions']=$reg_det->test_instructions;
		$data['test_img_url']=$reg_det->test_img_url;
		$data['test_time_limit']=$reg_det->test_time_limit;
		$data['test_type']=$reg_det->test_type;
		$data['test_status']=$reg_det->test_status;
		$data['test_enrollment_fee']=$reg_det->test_enrollment_fee;
		
		$data['viewtype']="EDIT";
	}
	else
	{
		$reg_det=$this->admin_dashboard_model->gettest_series();
		$data['reg_det']=$reg_det;
		$data['viewtype']="VIEW";
	}
	}
	else if($_GET['type']=="ts-add") {
		$data['viewtype']="ADD";

	}
	else {
		header("Location:".base_url()."admin");
	}
	
		




		$this->load->view('admin_header');
		$this->load->view('admin_test_series',$data);
		$this->load->view('admin_footer');
}

function ques_set()
{
	if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}

	if(!isset($_GET['ques_id'])   )
	{
		header("Location:".base_url()."admin/set-det");
	}
	if(!isset($_GET['ques_type']))
	{
		header("Location:".base_url()."admin/set-det");
	}
	
		
			$ques_det=$this->admin_dashboard_model->getques_by($_GET['ques_id']);
			
			$data['question_content']=$ques_det->question_content;
			if($_GET['ques_type']=="OBJECTIVE")

			{
				$data['question_options']=$ques_det->question_options;
				$data['question_correct_option']=$ques_det->question_correct_option;
			}
			$data['question_status']=$ques_det->question_status;
			$data['ques_id']=$_GET['ques_id'];
			$data['viewtype']=$_GET['ques_type'];
		
	
		
		$this->load->view('admin_header');
		$this->load->view('admin_question_details',$data);
		$this->load->view('admin_footer');
}

function delete_set()
{
	$set_id=$_POST['set_id'];
	$this->admin_dashboard_model->del_set($set_id);
	$res['status']="success";
	$res['url']=base_url()."admin/set-det";
	echo json_encode($res);

}

function set_det()
{
		if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}

	if(!isset($_GET['set_id']))
	{
		$sets=$this->admin_dashboard_model->getsets();
		$data['set_det']=$sets;
		$data['viewtype']="SET";
	}
	else
	{
		if(isset($_GET['set_id']))
		{
			$sets=$this->admin_dashboard_model->getsets_by($_GET['set_id']);
			$set_name=$sets->test_set_name;
			$set_type=$sets->test_type;
			$data['set_id']=$_GET['set_id'];
			$data['sname']=$set_name;
			$data['stype']=$set_type;
			$ques=$this->admin_dashboard_model->getques_byset($_GET['set_id']);
			$data['ques_det']=$ques;
			$data['viewtype']="SET-VIEW";
		}
	}
		
		$this->load->view('admin_header');
		$this->load->view('admin_question_set',$data);
		$this->load->view('admin_footer');
}

function add_set_det()
{

		$test_series=$this->admin_dashboard_model->gettest_series();
		$data['test_series']=$test_series;
		$this->load->view('admin_header');
		$this->load->view('admin_question_upload',$data);
		$this->load->view('admin_footer');
}



function upload_ssb_question()
{
	 


						echo json_encode($res);
}


function import()
{
	print_r($_FILES);
	print_r($_POST);

	$t_type=$_POST['t_type'];
	$t_set=$_POST['t_set'];
	if($t_set==0)
	{
		$t_nset=$_POST['t_nset'];	
		$data_set['test_set_for']=$t_type;
		$data_set['test_set_name']=$t_nset;
		$set_id=$this->admin_dashboard_model->insert_set($data_set);
	}	
	else
	{
		$set_id=$t_set;
	}
	//csv
	$msg='';
	if(isset($_FILES['pic_upload']))
	{
		
	$file_name = $_FILES['pic_upload']['name'];
      $file_size = $_FILES['pic_upload']['size'];
      $file_tmp = $_FILES['pic_upload']['tmp_name'];
      $file_type = $_FILES['pic_upload']['type'];
//      $file_ext=strtolower(end(explode('.',$file_name)));
      // print_r($_FILES);
      // exit;
      $extensions= array("text/csv");
      
      if(in_array($file_type,$extensions)=== false){
         $msg="extension not allowed, please choose a .csv file.";
      }
      
      
      if($msg=="") {
        // move_uploaded_file($file_tmp,"./uploads/".$file_name);
          
$handle = fopen($file_tmp, "r");
while (($data = fgetcsv($handle,0, ",")) !== FALSE) {
    $data_oques = array(
        'question_content' => $data[0], 
        'question_options' => $data[1],
        'question_correct_option' => $data[2],
       
               );
    $data_oques['set_id']=$set_id;
     $this->admin_dashboard_model->insert_ques($data_oques);
}
fclose($handle);
         $msg="file has been imported successfully!!";
      }

     
	}

	//image
	if(isset($_FILES['U_upload_file']))
	{
	$U_upload_file=$_FILES['U_upload_file'];


                      $no_of_files=sizeof($U_upload_file);
                      
                      for($i=($no_of_files-1);$i>=0;$i--)
                      {
                          $post_array = explode(";",$U_upload_file[$i]);
                            $image_type = explode(":",$post_array[0]);
                            
                            
                            
                            if($image_type[1]=="image/jpeg" || $image_type[1]=="image/png" ){
                              switch($image_type[1])
                              {
                                case "image/jpeg":
                                                        $ext=".jpeg";
                                break;
                                case "image/png":
                                                        $ext=".png";
                                break;
                                  
                              }
                              $image =substr($post_array[1],6);
                              $imageData = base64_decode($image);
                              $source = imagecreatefromstring($imageData);
                              $angle = 0;
                              $rotate = imagerotate($source, $angle, 0); 
                              
                                              $path  = $_SERVER['DOCUMENT_ROOT'] ."/assets/admin/uploads/questions/";
                                                $imageurl=base_url()."assets/admin/uploads/questions/";
                                           
                                            
                                            if (!file_exists($path)) {
                                              mkdir($path, 0777, true);
                                            }
                                            
                              date_default_timezone_set('Australia/Melbourne');
								 $date = date('m/d/Yh:i:sa', time());
								 $rand=rand(10000,99999);
								 $encname=$date.$rand;
                             $imagefile=md5($encname).$ext;
                              $imageName=$path.$imagefile;
                              
                                                   
                              $imageSave = imagejpeg($rotate,$imageName,100);
                              imagedestroy($source);
                              list($width, $height, $type, $attr) = getimagesize($imageName);
                             
                              if($width>720)
                              {
                                $config['image_library'] = 'gd2';
                              $config['source_image'] = $imageName;
                              //$config['new_image'] = './image_uploads/';
                              $config['maintain_ratio'] = TRUE;
                              $config['width'] = 720;
                              $this->load->library('image_lib');
                              $this->image_lib->initialize($config);

                              $this->image_lib->resize();

                              $this->image_lib->clear(); 

                            
                          
                              }


                              $data_ques['question_content']=$imageurl.$imagefile;
                              $data_ques['set_id']=$set_id;
                              $this->admin_dashboard_model->insert_ques($data_ques);

							}
						}

 $msg="Upload Successfull";

	}

	$_SESSION['upload_session']=$msg;
	header("Location:".base_url()."admin/set-det/sd-add");
}


function get_testset()
{
	$tkey=$_POST['t_type'];
	$test_det=$this->admin_dashboard_model->gettest_series_bykey($tkey);
	$t_type=$test_det->test_type;
	$set_det=$this->admin_dashboard_model->getsets_bykey($tkey);
	if($set_det->num_rows()>0)
	{
		$res['has_set']=1;
		$set_options='<option value="">Select Set</option><option value="0">New Set</option>';

		foreach ($set_det->result() as $svalue) {
					$set_options.='<option value="'.$svalue->set_id.'">'.$svalue->test_set_name.'</option>';
		}
		$res['t_set']=$set_options;
	}
	else
	{
		$res['has_set']=0;
		$res['ques_new_set']=' <label for="t_nset">New SET <sup>*</sup></label>
                    <input type="text" class="form-control" name="t_nset" id="t_nset" placeholder="Set Name" value="" required>
                  </div>';

	}


	if($t_type=="OBJECTIVE")
	{
	$res['ques_upload_option']='<label >Import Questions list in .csv format <sup>*</sup></label>
					<a href="'.base_url().'assets/admin/uploads/demo/demo_questions_sheet.csv" download="demo_questions_sheet.csv"><i class="fa fa-download"></i> Demo Sheet</a>
                   <div class="form-group">
                    <div class="input-group">
                      <div class="custom-file">
                        
                        <input type="file" class="custom-file-input" accept=".csv"  name="pic_upload" id="pic_upload" onchange="previewFile(this)" required>
                        <label class="custom-file-label" for="pic_upload" id="label_pic_upload">Choose .csv file</label>
                      </div>
                    </div>
                  </div>';
	}
	else
	{
		$res['ques_upload_option']=' <div class="form-group">
                    <label for="t_img">Uplaod Question Image <sup>*</sup></label>
                    <div class="row" id="U_prev">
                    
                    </div>
                    
                  </div>
                   <div class="form-group">
                    <div class="input-group">
                      <div class="custom-file">
                       
                        <input type="file" class="custom-file-input" accept=".png, .jpg, .jpeg"  name="U_upload_file[]" id="U_upload_file" onchange="U_previewFile(this)" multiple required>
                        <label class="custom-file-label" for="U_upload_file" id="label_u_upload">Choose .png, .jpg, .jpeg file</label>
                      </div>
                       <div class="input-group-append">
                        <span class="input-group-text" onclick="clear_files()">clear</span>
                      </div>
                    </div>
                  </div>';
	}

	echo json_encode($res);
}

function users()
{
		if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}
	if(!isset($_GET['type']))
	{
		header("Location:".base_url()."admin");
	}

	if($_GET['type']=="omt-users")
	{
	
		$user_det=$this->admin_dashboard_model->get_user_det("ONLINE");
		$data['user_det']=$user_det;
		$data['viewtype']="ONLINE";
	
	}
	else if($_GET['type']=="ocr-users") {
		$user_det=$this->admin_dashboard_model->get_user_det("OFFLINE");
		$data['user_det']=$user_det;
		$data['viewtype']="OFFLINE";

	}
	else {
		header("Location:".base_url()."admin");
	}
	
		




		$this->load->view('admin_header');
		$this->load->view('admin_users',$data);
		$this->load->view('admin_footer');
}


function trans_det()
{
	if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}

	$trans_det=$this->admin_dashboard_model->get_transc_det();
		$data['trans_det']=$trans_det;
			$this->load->view('admin_header');
		$this->load->view('admin_transc_det',$data);
		$this->load->view('admin_footer');



}

function ssb_us()
{
	if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}

	$ssb_us_det=$this->admin_dashboard_model->get_ssb_us();
	
		$data['ssb_us_det']=$ssb_us_det;
			$this->load->view('admin_header');
		$this->load->view('admin_ssb_us',$data);
		$this->load->view('admin_footer');



}

function ssb_answers()
{
	if(!$this->loggedin())
			{
				header("Location:".base_url()."admin_login");
			}

if(!isset($_GET['uid']) && !(isset($_GET['test_id'])))
	{
		header("Location:".base_url()."admin/ssb-us");
	}

	if($this->admin_dashboard_model->get_ssb_ans_count($_GET['test_id']))
	{
		$ssb_answers_det=$this->admin_dashboard_model->get_ssb_ans_det($_GET['test_id']);

		$data['ssb_answers_det']=$ssb_answers_det;
		$test_det=$this->admin_dashboard_model->gettest_byid($_GET['test_id']);
		$test_name=$test_det->test_type_name;
		$user_name=$test_det->user_name;
		$test_id=$test_det->id;
		$test_status=$test_det->test_status;
		$data['test_name']=$test_name;
		$data['user_name']=$user_name;
		$data['test_id']=$test_id;
		$data['test_status']=$test_status;
		$data['test_time']=$test_det->test_timestamp;
	
		
			$this->load->view('admin_header');
		$this->load->view('admin_ssb_answers',$data);
		$this->load->view('admin_footer');
	}
	else
	{
		header("Location:".base_url()."admin/ssb-us");
	}
	



}



function update_score()
{
	$tid=$_POST['tid'];
	$score=$_POST['score'];
	$where['test_score_id']=$tid;
	$where_ts['id']=$tid;
	$data_qa['user_answer_remarks']="DECLARED";
	$data_ts['test_score']=$score;
	$data_ts['test_status']=1;
	$this->admin_dashboard_model->update_ssb_answers($data_qa,$where);
	$this->admin_dashboard_model->update_tscore($data_ts,$where_ts);
	$res['status']="success";
	echo json_encode($res);
}




}
