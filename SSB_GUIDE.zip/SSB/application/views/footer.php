 <!--footer start-->
      <footer class="site-footer backcolor-red">
          <div class="text-center">
              2018- SSB GUIDE
              <a href="<?=base_url()?>dashboard#" class="go-top">
                  <i class="fa fa-angle-up"></i>
              </a>
          </div>
      </footer>
      <!--footer end-->
  </section>

    <!-- js placed at the end of the document so the pages load faster -->
    
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?=base_url()?>assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.scrollTo.min.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.nicescroll.js" type="text/javascript"></script>
    <script src="<?=base_url()?>assets/js/jquery.sparkline.js"></script>


    <!--common script for all pages-->
    <script src="<?=base_url()?>assets/js/common-scripts.js"></script>
    
    <script type="text/javascript" src="<?=base_url()?>assets/js/gritter/js/jquery.gritter.js"></script>
    <script type="text/javascript" src="<?=base_url()?>assets/js/gritter-conf.js"></script>

    <!--script for this page-->
    <script src="<?=base_url()?>assets/js/sparkline-chart.js"></script>    
  <script src="<?=base_url()?>assets/js/zabuto_calendar.js"></script>  
 
    
  
  <script type="text/javascript">
        $(document).ready(function () {
            display_notification()
        });
  </script>
  
  <script type="application/javascript">
       function display_notification()
            {

                var url="<?=base_url()?>home/getlatestnotification";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                        
                         dataType: 'json',
                         
                              success: function(data) 
                                  {        
                                    if(data['status']=="success")
                                    {
                                             var unique_id = $.gritter.add({
                                            // (string | mandatory) the heading of the notification
                                            title: data['title'],
                                            // (string | mandatory) the text inside the notification
                                            text: data['content'],
                                            // (string | optional) the image to display on the left
                                            image: '',
                                            // (bool | optional) if you want it to fade out on its own or just sit there
                                            sticky: true,
                                            // (int | optional) the time you want it to be alive for before fading out
                                            time: '3000',
                                            // (string | optional) the class name you want to apply to that specific message
                                            class_name: 'my-sticky-class'
                                            });

                                             marker_notification_seen(data['id']);
                                    }
                                    else
                                    {
                                       return false;
                                    }
                                   
                                    }
                         });




          
            }


            function marker_notification_seen(id)
            {
                 var url="<?=base_url()?>home/marker_notification_seen_byid";
                 $.ajax({type: 'POST', url: url, data:{id:id},dataType: 'json',success: function(data) 
                                  { 
                                    return false;
                                  }
                              });
            }
    </script>
  

  </body>
</html>
