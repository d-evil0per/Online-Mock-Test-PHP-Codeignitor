<?php 
class Admin_dashboard_model extends CI_Model{
    function __construct() {
        parent::__construct();
$this->load->database();
    }

function chkuser($id,$pass)
{
	return $this->db->query("SELECT COUNT(*) as num FROM admin_credentials WHERE admin_user_id='$id' AND admin_pass='$pass'")->row()->num;
}

function getdashcard_data($type)
{
	switch ($type) {
		case 'REGISTRATION':
								return $this->db->query("SELECT COUNT(*) as num FROM registration_enquiry")->row()->num;
			break;
		case 'SIGNUPS':
								return $this->db->query("SELECT COUNT(*) as num FROM users")->row()->num;
			break;
		case 'REVENUE':
								return $this->db->query("SELECT SUM(payable_amt) as num FROM payment_details WHERE payment_status=1")->row()->num;
			break;
		case 'TRANSACTIONS':
								return $this->db->query("SELECT COUNT(*) as num FROM payment_details WHERE payment_status IN (1,2,3)")->row()->num;
			break;
		
	}

}

function get_user_det($type)
{
	if($type=="ONLINE")
	{
		return $this->db->query("SELECT *  FROM users  ORDER BY user_profile_created_date DESC");
	}
	else
	{
		return $this->db->query("SELECT *  FROM registration_enquiry ORDER BY registration_date DESC");
	}
}

function get_transc_det()
{
	return $this->db->query("SELECT * FROM payment_details WHERE payment_status IN (1,2,3) ORDER BY payment_update_date DESC");
}

function getdashdata_lists($type)
{
	switch ($type) {
		case 'REGISTRATION':
								return $this->db->query("SELECT *  FROM registration_enquiry ORDER BY registration_date DESC LIMIT 0,5");
			break;
		case 'SIGNUPS':
								return $this->db->query("SELECT *  FROM users ORDER BY user_profile_created_date DESC LIMIT 0,10");
			break;
		case 'SSB_SUBMIT':
								return $this->db->query("SELECT * FROM test_scores ts INNER JOIN users u ON ts.user_id =u.id WHERE ts.is_ssb=1  ORDER BY ts.test_timestamp DESC LIMIT 0,10");
			break;
		case 'TRANSACTIONS':
								return $this->db->query("SELECT * FROM payment_details WHERE payment_status IN (1,2,3) ORDER BY payment_update_date DESC LIMIT 0,10");
			break;
		
	}


}

function getreg_det()
{
	return  $this->db->query("SELECT * FROM registration_details");
}
function getreg_det_byid($id)
{
	return  $this->db->query("SELECT * FROM registration_details WHERE course_id=$id")->row();
}

function update_reg_det($data,$where)
{
	$this->db->where($where);
	$this->db->update("registration_details",$data);
}
function update_ts($data,$where)
{
	$this->db->where($where);
	$this->db->update("test_series",$data);
}
function update_tscore($data,$where)
{
	$this->db->where($where);
	$this->db->update("test_scores",$data);
}
function update_ssb_answers($data,$where)
{
	$this->db->where($where);
	$this->db->update("user_ssb_answers",$data);
}
function update_ques($data,$where)
{

	$this->db->where($where);
	$this->db->update("test_sets_questions",$data);
}
function add_reg_det($data)
{
	
	$this->db->insert("registration_details",$data);
}
function del_reg_det($id)
{
	
	$this->db->query("DELETE FROM registration_details WHERE course_id=$id ");
}
function del_ques($id)
{
	
	$this->db->query("DELETE FROM test_sets_questions WHERE question_id=$id ");
}
function add_ts($data)
{
	
	$this->db->insert("test_series",$data);
}
function del_ts($id)
{
	
	$this->db->query("DELETE FROM test_series WHERE id=$id ");
}
function gettest_series_byid($tid)
{
	return $this->db->query("SELECT * FROM test_series WHERE id=$tid")->row();
}
function gettest_series_bykey($tid)
{
	return $this->db->query("SELECT * FROM test_series WHERE test_key='$tid'")->row();
}
function gettest_series()
{
	return $this->db->query("SELECT * FROM test_series ");
}


function getsets()
{
	return $this->db->query("SELECT * FROM test_sets ts INNER JOIN test_series t_s ON ts.test_set_for=t_s.test_key WHERE t_s.test_status=1");

}


function getsets_by($id)
{
	return $this->db->query("SELECT * FROM test_sets ts INNER JOIN test_series t_s ON ts.test_set_for=t_s.test_key WHERE t_s.test_status=1 AND ts.set_id=$id")->row();
}

function getsets_bykey($key)
{
	return $this->db->query("SELECT * FROM test_sets  WHERE test_set_status=1 AND test_set_for='$key'");
}

function getques_by($id)
{
	return $this->db->query("SELECT * FROM test_sets_questions tsq INNER JOIN test_sets ts ON tsq.set_id=ts.set_id WHERE tsq.question_id=$id")->row();
}

function getques_byset($id)
{
	return $this->db->query("SELECT * FROM test_sets_questions tsq INNER JOIN test_sets ts ON tsq.set_id=ts.set_id WHERE tsq.set_id=$id ");
}

function del_set($set_id)
{
	$this->db->query("DELETE FROM test_sets WHERE set_id=$set_id ");
	$this->db->query("DELETE FROM test_sets_questions WHERE set_id=$set_id ");
}

function insert_set($data)
{
	$this->db->insert("test_sets",$data);
	return $this->db->insert_id();
}

function insert_ques($data)
{
	$this->db->insert("test_sets_questions",$data);
}


function get_ssb_us()
{
	return $this->db->query("SELECT ts.*,u.user_name FROM test_scores ts INNER JOIN users u ON ts.user_id=u.id WHERE ts.is_ssb=1");
}

function get_ssb_ans_det($id)
{
	return $this->db->query("SELECT usa.*,tsq.question_content FROM user_ssb_answers usa INNER JOIN test_sets_questions tsq ON usa.test_ques_id=tsq.question_id WHERE usa.test_score_id=$id");
}
function get_ssb_ans_count($id)
{
	return $this->db->query("SELECT COUNT(*) as num FROM user_ssb_answers WHERE test_score_id=$id")->row()->num;
}

function gettest_byid($id)
{
	return $this->db->query("SELECT ts.*,u.user_name FROM test_scores ts INNER JOIN users u ON ts.user_id=u.id WHERE ts.id=$id ")->row();
}
} ?>