    
  <section id="main-content">

          <section class="wrapper">
<div class="row">
<div class="col-lg-12 main-chart">
 <div class="index-content">
  <?php if(!isset($this->session->userdata['enroll_payment_status'])) { ?>
    <div class="container" >
       
             
                <div class="col-lg-10" >
                    <div class="card" style="padding: 10px">
                      <center>
                        <br>
                        <h3 class="backred">Details </h3>
                        <input type="hidden" name="key" id="test_key"  value="<?=$test_key?>">
                        <h5><b><?=$test_name?></b></h5>
                        <h6>Time : <b><?=$test_time?></b> Mins</h6>
                          <b><p>Descriptions </p></b>
                           </center>
                          <ul>
                           <li>
                            <?=$desc?>
                          </li> 
                           <li>
                           <br><center><b><p>Enrollment Fee: <i class="fa fa-rupee"></i> <?=$test_fee?></p></b></center>
                          </li>
                            </ul>


<center><a class="btn btn-theme05 btn-block" href="javascript:void(0)" onclick="enrollnow()" style="width:100px"> <b>Enroll Now</b></a></center>
                </div>
           

    </div>
</div>
<?php } else { ?>

                    <?php if($this->session->userdata['enroll_payment_status']) { ?> 
            <div class="container" id="thank_you">
                            <div class="container" >
            <div class="form-login ">
                         <h2 class="form-login-heading">Thank You</h2>
                          <div class="login-wrap">
                        <center>
                     <h6 style="color:#2ecc71;"><i class="fa fa-check-circle"></i> Payment Successful</h6> 
                   <h6 >You have been Successfully Signed UP! </h6>   
                     
                    </center>
                    </div>
                    </div>
                    </div>
                    </div>

                   <?php } else { ?>
                        <div class="container">
                            <div class="container" >
            <div class="form-login ">
                         <h2 class="form-login-heading backcolor-red">Sorry</h2>
                          <div class="login-wrap">
                        <center>
                     <h6 style="color:#da4453;"><i class="fa fa-exclamation-triangle"></i> Payment Failed!</h6> 

                   <h6 >We did not receive the payment as the transaction wasn't successful. We request you retry. Please contact your bank in case your account was debited and you still see this message.</h6>  

                  
                    <a class="btn btn-theme05 btn-block" href="javascript:void(0)" id="reg_retry_btn" onclick="retrypayment()"><i class="fa fa-check"></i> <b>Retry Payment</b></a>
                    </center>
                    </div>
                    </div>
                    </div>
                    </div>

                    <?php } } ?>
</div>
</div>
</div>
</section>
</section>




<script type="text/javascript">
  setTimeout(function()
             {
               var url="<?=base_url()?>home/unset_enrollpay";
               $.ajax({
                        type: 'POST',   
                        url: url,
                        dataType:"JSON",
                        success:function(data)
                        {
                            window.location.reload();
                        }
                     });

               },30000);



     function retrypayment()
            {
                var url="<?=base_url()?>home/enrollment_pay";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                        
                         dataType: 'json',
                                beforeSend:function()
                                    {
                                         ajaxInProgress = true;
                                         $("#reg_retry_btn").html(" <i class='fa fa-check'> <b> Retrying...</b>");
                                         
                                          $("#reg_retry_btn").removeAttr("onclick");
                                    },
                              success: function(data) 
                                  {        
                                     ajaxInProgress = false;
                                    $("#reg_retry_btn").html(" <i class='fa fa-check'> <b>Retry Payment</b>");
                                    
                                  $("#reg_retry_btn").attr("onclick","retrypayment()");
                                                window.location = data['url'];
                                    }
                         });
            }
  function enrollnow()
  {
    var key=$("#test_key").val();
       var url="<?=base_url()?>home/enrollment_pay";
        $.ajax({
                  url:url,
                  data:{key:key},
                  type:'post',
                  dataType:"JSON",
                 
                  success: function(data)
                  {
                    window.location = data['url'];
                  }
              });

          
        }
  
</script>

