<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/
$route['default_controller'] = 'Home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
$route['profile']="home/profile";
$route['dashboard']="home/dashboard";
$route['notification']="home/notification";
$route['login']="home/login";
$route['get-started']="home/get_test_started";
$route['enroll-now']="home/enroll_now";
$route['skilltest/question/(:any)/(:any)']="home/skill_test/$2";
$route['admin']="admin_dashboard/index";
$route['admin_login']="admin_dashboard/login";

$route['admin/registration-details']="admin_dashboard/registration_details";

$route['admin/test-series']="admin_dashboard/test_series";
$route['admin/set-det']="admin_dashboard/set_det";
$route['admin/set-det/sd-add']="admin_dashboard/add_set_det";
$route['admin/ques-set']="admin_dashboard/ques_set";


$route['admin/users']="admin_dashboard/users";

$route['admin/ssb-answers']="admin_dashboard/ssb_answers";
$route['admin/ssb-us']="admin_dashboard/ssb_us";
$route['admin/trans-det']="admin_dashboard/trans_det";

$route['admin/send-note']="admin_dashboard/send_note";
$route['admin/send-mail']="admin_dashboard/send_mail";