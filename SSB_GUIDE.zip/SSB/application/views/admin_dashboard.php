  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Dashboard </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box">
              <span class="info-box-icon bg-info elevation-1"><i class="fa fa-users"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Offline Registrations </span>
                <span class="info-box-number">
                  <?=$no_of_regis?>
                  
                </span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-danger elevation-1"><i class="fa fa-users"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Online Signups</span>
                <span class="info-box-number"><?=$no_of_signups?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->

          <!-- fix for small devices only -->
          <div class="clearfix hidden-md-up"></div>

          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-success elevation-1"><i class="fa fa-rupee"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">Revenue</span>
                <span class="info-box-number"><?=$total_revenue?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
          <div class="col-12 col-sm-6 col-md-3">
            <div class="info-box mb-3">
              <span class="info-box-icon bg-warning elevation-1"><i class="fa fa-credit-card"></i></span>

              <div class="info-box-content">
                <span class="info-box-text">No .of Transactions</span>
                <span class="info-box-number"><?=$no_of_transactions?></span>
              </div>
              <!-- /.info-box-content -->
            </div>
            <!-- /.info-box -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

        <div class="row">
          
           <div class="col-md-6">
                <!-- USERS LIST -->
                <div class="card">
                  <div class="card-header">
                    <h3 class="card-title">Latest Online Signups</h3>

                    <div class="card-tools">
                     
                      <button type="button" class="btn btn-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                      </button>
                      <button type="button" class="btn btn-tool" data-widget="remove"><i class="fa fa-times"></i>
                      </button>
                    </div>
                  </div>
                  <!-- /.card-header -->
                  <div class="card-body p-0">
                    <ul class="users-list clearfix">
                      <?php foreach ($latest_signups->result() as $lsign) { ?>
                      
                      <li>
                        <?php if($lsign->user_profile_pic!="") { ?>
                        <img src="<?=$lsign->user_profile_pic?>" width="60" height="60" alt="User Image">
                        <?php } else { ?>
                        <img src="<?=base_url()?>assets/img/iconNoAvatar.png" width="60" height="60" alt="User Image">
                        <?php } ?>
                        <a class="users-list-name" href="javascript:void(0)"><?=$lsign->user_name?></a>
                        <span class="users-list-date"><?=date("d M y",strtotime($lsign->user_profile_created_date))?></span>
                      </li>
                      
                     <?php } ?>
                    </ul>
                    <!-- /.users-list -->
                  </div>
                  <!-- /.card-body -->
                  <div class="card-footer text-center">
                    <a href="<?=base_url()?>admin/users/?type=omt-users">View All Users</a>
                  </div>
                  <!-- /.card-footer -->
                </div>
                <!--/.card -->
              </div>
             <div class="col-md-6">
            <!-- /.card -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Latest Offline Registrations</h3>

              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <ul class="products-list product-list-in-card pl-2 pr-2">
                  <?php foreach ($latest_registrations->result() as $lreg) { ?>
                  <li class="item">
                   
                    <div class="product-info">
                      <a href="javascript:void(0)" class="product-title"><?=$lreg->name?>
                        <span class="badge badge-success float-right"><i class="fa fa-rupee"></i><?=$lreg->paid_amount?></span></a>
                      <span class="product-description">
                        Course: <?=$lreg->course_name?>
                        <br>
                        Mobile: <?=$lreg->mobile_no?>
                        <br>
                        Email: <?=$lreg->email_id?>
                      </span>
                    </div>
                  </li>
                  <!-- /.item -->
                  <?php } ?>
                </ul>
              </div>
              <!-- /.card-body -->
              <div class="card-footer text-center">
                <a href="<?=base_url()?>admin/users/?type=ocr-users" class="uppercase">View All Registrations</a>
              </div>
              <!-- /.card-footer -->
            </div>
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

        <!-- Main row -->
        <div class="row">
          <!-- Left col -->
          <div class="col-md-12">
            <!-- MAP & BOX PANE -->

            
            <!-- /.row -->

            <!-- TABLE: LATEST ORDERS -->
            <div class="card">
              <div class="card-header border-transparent">
                <h3 class="card-title">Latest Transactions</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse">
                    <i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-widget="remove">
                    <i class="fa fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <div class="table-responsive">
                  <table class="table m-0">
                    <thead>
                    <tr>
                      <th>Payment ID</th>
                      <th>Payeer Name</th>
                      <th>Payeer Email</th>
                      <th>Payeer mobile</th>
                      <th>Payment Through</th>
                      <th>Payment For</th>
                      <th>Pay Amount</th>
                      <th>Status</th>
                      <th>Payment Date</th>
                    </tr>
                    </thead>
                    <tbody>
                       <?php foreach ($latest_transactions->result() as $ltrac) { ?>
                    <tr>
                      <td><a href="javascript:void(0)"><?=$ltrac->pay_id?></a></td>
                      <td><?=$ltrac->user_name?></td>
                      <td><?=$ltrac->user_email?></td>
                      <td><?=$ltrac->user_mobile_no?></td>
                      <td><?=$ltrac->paid_through?></td>
                      <td><?=$ltrac->paid_for?></td>
                      <td><i class="fa fa-rupee"></i> <?=$ltrac->payable_amt?></td>
                      <?php if($ltrac->payment_status==1) { ?>
                         <td><span class="badge badge-success">COMPLETE</span></td>
                         <?php } else if ($ltrac->payment_status==2) { ?>
                         <td><span class="badge badge-danger">FAILED</span></td>
                         <?php } else { ?>
                         <td><span class="badge badge-warning">ABORTED</span></td>
                         <?php } ?>
                      <td>
                        <?=date("d M y",strtotime($ltrac->payment_update_date))?>
                      </td>
                    </tr>
                    <?php } ?>
                    </tbody>
                  </table>
                </div>
                <!-- /.table-responsive -->
              </div>
              <!-- /.card-body -->
              <div class="card-footer clearfix">
             
                <a href="<?=base_url()?>admin/trans-det" class="btn btn-sm btn-secondary float-right">View All Transactions</a>
              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->

          <div class="col-md-12">
           

        

            <!-- PRODUCT LIST -->
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Recently Submitted SSB Answers</h3>

                <div class="card-tools">
                  <button type="button" class="btn btn-tool" data-widget="collapse">
                    <i class="fa fa-minus"></i>
                  </button>
                  <button type="button" class="btn btn-tool" data-widget="remove">
                    <i class="fa fa-times"></i>
                  </button>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body p-0">
                <ul class="products-list product-list-in-card pl-2 pr-2">
                   <?php foreach ($latest_ssb_submit->result() as $lssb) { ?>
                  <li class="item">

                    <div class="product-img">
                      <?php if($lssb->user_profile_pic!="") { ?>
                        <img src="<?=$lssb->user_profile_pic?>" class="img-size-50" alt="User Image">
                        <?php } else { ?>
                        <img src="<?=base_url()?>assets/img/iconNoAvatar.png" class="img-size-50" alt="User Image">
                        <?php } ?>

                      
                    </div>
                    <div class="product-info">
                      <a href="<?=base_url()?>admin/ssb-us?test_id=<?=$lssb->id?>" class="product-title"><?=$lssb->user_name?>
                        <?php if($lssb->test_status) { ?>
                        <span class="badge badge-success float-right">Result Declared</span></a>
                        <?php } else { ?>
                         <span class="badge badge-warning float-right">Result Pending</span></a>
                        <?php } ?>
                      <span class="product-description">
                        Test : <?=$lssb->test_type_name?>
                        <br>
                        Time Taken : <?=round($lssb->test_time_taken)." Mins"?>
                        <br>
                        Test Score : <?php if($lssb->test_score==0 && $lssb->test_status==0){ echo "N/A"; } else { echo $lssb->test_score; }?> 
                        <br>
                        Date: <?=date("d M y",strtotime($lssb->test_timestamp))?>
                      </span>
                    </div>
                  </li>
                  <?php } ?>
                </ul>
              </div>
              <!-- /.card-body -->
              <div class="card-footer text-center">
                <a href="<?=base_url()?>admin/ssb-us" class="uppercase">View All Submission</a>
              </div>
              <!-- /.card-footer -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->