<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Registration extends CI_Controller {

 function __construct() {
        parent::__construct();
 $this->load->model('registration_model');
  require_once ("assets/PHPMailer/PHPMailerAutoload.php");
  include APPPATH . 'third_party/Crypto.php';
  
 
 }
	public function index()
	{
		
		$course_option="<option value=''>Select a Course</option>";
		$course=$this->registration_model->getcourse_details();
		foreach ($course->result() as $c_details) {
			$course_option.="<option value='".$c_details->course_id."'>".$c_details->course_name."</option>";
		}
		$data = array('course' =>$course_option);

		 $this->load->view('registration',$data);
	}


	public function get_course_details_by_ajax()
	{
		$c_id=$_POST['c_id'];
		$c_teo='';
		$c_spe='';
		$is_ssb=0;

		$c_details=$this->registration_model->get_course_details_by_id($c_id);
		$c_duration="Course Duration : ".$c_details->course_duration." Days";
		if($c_details->course_name=="Super 30 – SSB")
		{
			$is_ssb=1;
			$c_teo="<option value=''> Type Of Entry </option>";
			$c_spe="<option value=''>SSB Previous Experience</option>";
			$type_of_entry=explode(',',$c_details->type_of_entry);
			foreach ($type_of_entry as $key ){
			$c_teo.="<option value='".$key."'>".$key."</option>";
			}
			$ssb_pe=explode(',',$c_details->previous_experience);
			foreach ($ssb_pe as $spe) {
			$c_spe.="<option value='".$spe."'>".$spe."</option>";
			}

		}
		
		$c_cdate='<option value="">Course commencement Date</option>';
		$ccdate=explode(',',$c_details->course_commencement_date);
		foreach ($ccdate as $date) {
			$c_cdate.='<option value="'.$date.'">'.date("d M Y",strtotime($date)).'</option>';
					}

		$c_fee=$c_details->fee_amount;
		$c_reg_fee=$c_details->registration_fee;

		$res['c_duration']=$c_duration;
		$res['is_ssb']=$is_ssb;
		$res['c_teo']=$c_teo;
		$res['c_spe']=$c_spe;
		$res['c_cdate']=$c_cdate;
		$res['c_fee']=$c_fee;
		$res['c_reg_fee']=$c_reg_fee;
		echo json_encode($res);


	}

	function register_pay()
{
  
$c_id="";
$c_name="";
$is_ssb="";
$name="";
$f_name="";
$qualification="";
$address="";
$mobile="";
$f_mobile="";
$email="";
$c_cdate="";
$c_reg_fee="";
$c_fee="";
$c_due="";
$c_teo="";
$c_spe="";
$city="";
$pin="";
$state="";
$country="";

if(isset($_POST['c_id']))
{
$c_id=$_POST['c_id'];
		$is_ssb=$_POST['is_ssb'];
		
		$c_details=$this->registration_model->get_course_details_by_id($c_id);
		$c_name=$c_details->course_name;
		$session_data = array();
		$session_data['name']=$name=$_POST['name'];
		$session_data['father_name']=$f_name=$_POST['f_name'];
		$session_data['qualification']=$qualification=$_POST['qualification'];
		$session_data['address']=$address=$_POST['address'];
		$session_data['mobile_no']=$mobile=$_POST['mobile'];
		$session_data['f_mobile_no']=$f_mobile=$_POST['f_mobile'];
		$session_data['email_id']=$email=$_POST['email'];
		$session_data['course_id']=$c_id;
		$session_data['course_name']=$c_name;
		$session_data['course_commencement_date']=$c_cdate=$_POST['c_cdate'];
		$session_data['paid_amount']=$c_reg_fee=$_POST['c_reg_fee'];
		$session_data['due_amount']=$c_due=((int)$_POST['c_fee']-(Int)$_POST['c_reg_fee']);
		$session_data['c_fee']=$_POST['c_fee'];
		$session_data['city']=$city=ucwords($_POST['city']);
		$session_data['pin']=$pin=$_POST['pin'];
      $session_data['state']=$state=ucwords($_POST['state']);
    $session_data['country']=$country=ucwords($_POST['country']);
		if((int)$is_ssb)
		{
			$session_data['ssb_type_of_entry']=$c_teo=$_POST['c_toe'];
			$session_data['ssb_previous_experience']=$c_spe=$_POST['c_spe'];
			
		}
		else
		{
			$session_data['ssb_type_of_entry']=$c_teo="";
			$session_data['ssb_previous_experience']=$c_spe="";
		}
		$session_data['is_ssb']=$is_ssb;

		
			$this->session->set_userdata($session_data);

}
else if (isset($this->session->userdata['course_id']))
{
$c_id=$this->session->userdata['course_id'];
$c_name=$this->session->userdata['course_name'];
$is_ssb=$this->session->userdata['is_ssb'];
$name=$this->session->userdata['name'];
$f_name=$this->session->userdata['father_name'];
$qualification=$this->session->userdata['qualification'];
$address=$this->session->userdata['address'];
$mobile=$this->session->userdata['mobile_no'];
$f_mobile=$this->session->userdata['f_mobile_no'];
$email=$this->session->userdata['email_id'];
$c_cdate=$this->session->userdata['course_commencement_date'];
$c_reg_fee=$this->session->userdata['paid_amount'];
$c_fee=$this->session->userdata['c_fee'];
$c_due=$this->session->userdata['due_amount'];
$c_teo=$this->session->userdata['ssb_type_of_entry'];
$c_spe=$this->session->userdata['ssb_previous_experience'];
$city=$this->session->userdata['city'];
$pin=$this->session->userdata['pin'];
$state=$this->session->userdata['state'];
$country=$this->session->userdata['country'];
}


  
     
  
   
    $currDate = date("Y-m-d h:i");
   $session_id = md5(date("Y-m-d").$email);
    $custadd=$address.','.$city.','.$state.','.$country.','.$pin; 



      $max_paymentid = $this->registration_model->getLastOrderNumber();
      if (strlen($max_paymentid->id) == 1)
        $start_char = '000'.strval($max_paymentid->id);
      else if(strlen($max_paymentid->id) == 2 )
        $start_char = '00'.strval($max_paymentid->id);
      else if(strlen($max_paymentid->id) == 3 )
        $start_char = '0'.strval($max_paymentid->id);
      else
        $start_char = strval($max_paymentid->id);
      
       $payment_number = date("ym").$start_char;
    $data=array(
                  	'pay_id'=>$payment_number,
                    'session_id'=>$session_id,
                    'user_name'=>$name,
                    'user_address'=>$custadd,
                    'user_mobile_no'=>$mobile,
                    'user_email'=>$email,
                    'paid_for'=>$c_name,
                    'paid_through'=>"REGISTRATION",
                    'payable_amt'=>$c_reg_fee,
                    'payment_date'=>$currDate,
                    'payment_status'=>0,
                    
                );  
 $order_id = $this->registration_model->savepostpayment($data);


      $cc_data = array();
      $payment_gateway=$this->registration_model->getpayment_detail("CCAvenue");
      $cc_data['merchant_id'] = $payment_gateway->merchant_id;
      $cc_data['order_id'] = $payment_number;
      $cc_data['amount'] = $c_reg_fee;
      $cc_data['currency'] = $payment_gateway->currency;
      $cc_data['redirect_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/registration/reg_paymentstatus';
      $cc_data['cancel_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/registration/reg_paymentstatus';
        $cc_data['language'] = 'EN';
      $cc_data['billing_name'] = $name;
      $cc_data['billing_address'] = $address;
      $cc_data['billing_city'] = $city;
      $cc_data['billing_state'] = $state;     
      $cc_data['billing_country'] = $country;
      $cc_data['billing_tel'] = $mobile;
      $cc_data['billing_email'] = $email;
      $cc_data['billing_zip'] = $pin;

   
      $working_key = $payment_gateway->working_key;
      $access_code = $payment_gateway->access_key;
        
      
      $merchant_data='';
    
      foreach ($cc_data as $key => $value){
        $merchant_data.=$key.'='.$value.'&';
      }

        $encrypted_data=encrypt($merchant_data,$working_key); // Method for encrypting the data.
   
        // $test_url=str_replace("##ENC_DATA##",$encrypted_data, $payment_gateway->test_payment_gateway);
        $test_url=str_replace("##ENC_DATA##",$encrypted_data, $payment_gateway->live_payment_gateway); //live payment 
        $test_url=str_replace("##ACCESS_CODE##",$access_code,$test_url);
        
      
    
      $res['url']=$test_url;                  
      echo json_encode($res);

}




function reg_paymentstatus()
{


 $payment_gateway=$this->registration_model->getpayment_detail("CCAvenue");
 
  $working_key = $payment_gateway->working_key;      
      

    $encResponse=$_POST["encResp"];     //This is the response sent by the CCAvenue Server
  $rcvdString=decrypt($encResponse,$working_key);   //Crypto Decryption used as per the specified working key.
  $order_status="";
  $decryptValues=explode('&', $rcvdString);
  $dataSize=sizeof($decryptValues);
  $ref_no='';
        $status='';
        $amount='';
        $order_id='';
        $currDate = date("Y-m-d H:i:s");
  for($i = 0; $i < $dataSize; $i++) 
  {
    $information=explode('=',$decryptValues[$i]);
              
    if($i==3) $order_status=$information[1];
                if($i==2)       $ref_no=$information[1];
                if($i==10)       $amount=$information[1];
                if($i==0)       $order_id=$information[1];
  }

  if($order_status==="Success")
  {
    $status=1;
    
  }
  else if($order_status==="Aborted")
  {
    $status=3;
  
  }
  else if($order_status==="Failure")
  {
    $status=2;
  }
  else
  {
    $status=2;
  
  }

  // print_r($decryptValues);
  // echo $status;
  // exit;      

  
    
    

            if(!isset($this->session->userdata['course_id']))
                        {
                            echo '<script>window.location = "'.base_url().'"</script>';
                        }
          
      		$c_id=$this->session->userdata['course_id'];
			$c_name=$this->session->userdata['course_name'];
			$is_ssb=$this->session->userdata['is_ssb'];
			$name=$this->session->userdata['name'];
			$f_name=$this->session->userdata['father_name'];
			$qualification=$this->session->userdata['qualification'];
			$address=$this->session->userdata['address'];
			$mobile=$this->session->userdata['mobile_no'];
			$f_mobile=$this->session->userdata['f_mobile_no'];
			$email=$this->session->userdata['email_id'];
			$c_cdate=$this->session->userdata['course_commencement_date'];
			$c_reg_fee=$this->session->userdata['paid_amount'];
			$c_fee=$this->session->userdata['c_fee'];
			$c_due=$this->session->userdata['due_amount'];
			$c_teo=$this->session->userdata['ssb_type_of_entry'];
			$c_spe=$this->session->userdata['ssb_previous_experience'];
			$city=$this->session->userdata['city'];
			$pin=$this->session->userdata['pin'];



                          $this->registration_model->updatepaymentdetails($order_id,$status,$encResponse);
                         

             if($status==1)
             {
                   
       
		
		$data_insert = array();
		$data_insert['name']=$name;
		$data_insert['father_name']=$f_name;
		$data_insert['qualification']=$qualification;
		$data_insert['address']=$address;
		$data_insert['mobile_no']=$mobile;
		$data_insert['f_mobile_no']=$f_mobile;
		$data_insert['email_id']=$email;
		$data_insert['course_id']=$c_id;
		$data_insert['course_name']=$c_name;
		$data_insert['course_commencement_date']=$c_cdate;
		$data_insert['paid_amount']=$c_reg_fee;
		$data_insert['due_amount']=((int)$c_fee-(Int)$c_reg_fee);
		if((int)$is_ssb)
		{
			$data_insert['ssb_type_of_entry']=$c_teo;
			$data_insert['ssb_previous_experience']=$c_spe;
			$content="Hi Team,<br><br> A new registration has been done, Please find the candidate's details below.<br><table border='1'><tr><th>Candidate Name</th><th>Email</th><th>Mobile Number</th><th>Father's Name</th><th>Father's Number</th><th>Qualification</th><th>Address</th><th>Course Name</th><th>Type Of Entry</th><th>SSB Previous Experience</th><th>Course Commencement Date </th><th>Amount Paid </th></tr><tr><td>".$data_insert['name']."</td><td>".$data_insert['email_id']."</td><td>".$data_insert['mobile_no']."</td><td>".$data_insert['father_name']."</td><td>".$data_insert['f_mobile_no']."</td><td>".$data_insert['qualification']."</td><td>".$data_insert['address']."</td><td>".$data_insert['course_name']."</td><td>".$data_insert['ssb_type_of_entry']."</td><td>".$data_insert['ssb_previous_experience']."</td><td>".$data_insert['course_commencement_date']."</td><td>".$data_insert['paid_amount']."</td></tr></table><br> Cheers<br><br> Team SSB GUIDE";
		}
		else
		{
			$content="Hi Team,<br><br> A new registration has been done, Please find the candidate's details below.<br><table border='1'><tr><th>Candidate Name</th><th>Email</th><th>Mobile Number</th><th>Father's Name</th><th>Father's Number</th><th>Qualification</th><th>Address</th><th>Course Name</th><th>Course Commencement Date </th><th>Amount Paid </th></tr><tr><td>".$data_insert['name']."</td><td>".$data_insert['email_id']."</td><td>".$data_insert['mobile_no']."</td><td>".$data_insert['father_name']."</td><td>".$data_insert['f_mobile_no']."</td><td>".$data_insert['qualification']."</td><td>".$data_insert['address']."</td><td>".$data_insert['course_name']."</td><td>".$data_insert['course_commencement_date']."</td><td>".$data_insert['paid_amount']."</td></tr></table><br> Cheers<br><br> Team SSB GUIDE";
		}
		

		$this->registration_model->insert_registration($data_insert);
		$subject="New Registration #".$data_insert['name']." - ".date("d, M y h:iA");
		$res1=$this->sendmail('ndassbguide@gmail.com','SSB GUIDE',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content);
		// $res1=$this->sendmail('dhir.xcess@gmail.com','Developer',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content); //for test purpose

		$sub="Registration Successful for ".$data_insert['course_name']." At SSB GUIDE";
		$con="Hi ".$data_insert['name'].",<br><br> You have been successfully Register For ".$data_insert['course_name'].". <br> Please Call <b>7015173285</b> Or Whatsapp On <b>8572857321</b> For Any help. <br> Cheers <br><br> Team SSB GUIDE";

		$res2=$this->sendmail($data_insert['email_id'],$data_insert['name'],"noreply@ssbguide.com","SSB GUIDE Team",$sub,$con);
               
                       $session_data = array('reg_payment_status' => 1,
                                              'order_id'=>$order_id,
                                               'price'=>$amount);
                      // Add user data in session
                      $this->session->set_userdata($session_data);



                             $session_data = array(
                                                  'course_id',
                                                  'course_name',
                                                  'is_ssb',
                                                  'name',
                                                 ' father_name',
                                                  'qualification',
                                                 ' address',
                                                 ' mobile_no',
                                                 ' f_mobile_no',
                                                 ' email_id',
                                                 ' course_commencement_date',
                                                 ' c_fee',
                                                  'due_amount',
                                                  'ssb_type_of_entry',
                                                  'ssb_previous_experience',
                                                  'city',
                                                  'pin'

                                                    
                                                    );
                      $this->session->unset_userdata($session_data);
                    
                      
                      
             }
             else
             {
               $session_data = array('reg_payment_status' => 0,'order_id'=>$order_id);
                                              // 'price'=>$amount);
                      // Add user data in session
                      $this->session->set_userdata($session_data);
                    
                
             }
            
            
             $purl=base_url()."registration";
              echo "<script>window.location='".$purl."'</script>";
         
             

}

function unset_registerpay()
{
	  $session_data = array('reg_payment_status' ,'order_id');

                      $this->session->unset_userdata($session_data);
                      $res['status']="success";
                      echo json_encode($res);
}


		function sendmail($to,$toname,$from,$fromname,$subject,$content)
	{
			$mail = new PHPMailer;

			                              

			$mail->From = $from;
			$mail->FromName = $fromname;

			$mail->addAddress($to, $toname);

			$mail->isHTML(true);

			$mail->Subject = $subject;
			$mail->Body = $content;
			

			if(!$mail->send()) 
			{
			    $msg= "Enquiry Error: " . $mail->ErrorInfo;
			} 
			else 
			{
			    $msg ="Enquiry has been sent successfully";
			}

			return $msg;
	}
}
