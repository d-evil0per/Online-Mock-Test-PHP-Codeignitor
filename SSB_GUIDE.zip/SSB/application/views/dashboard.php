

      <!--main content start-->
      <section id="main-content">

          <section class="wrapper">

              
                  
                     


<div class="row">
<div class="col-lg-12 main-chart">

  <?php if($has_selected_test=="1") { ?>
     <div class="index-content">
    <div class="border-head">
                          <h3>Erolled In</h3>
                      </div>
    <div class="container" >
            <?php foreach ($selected_test->result() as $skey) { ?>
             <?php if($skey->test_status) { ?>
                <div class="col-lg-4" >
                    <div class="card" >
                        <img src="<?=$skey->test_img_url?>">
                        <h4><?=strtoupper($skey->test_name)?></h4>
                     <p><?=implode(' ', array_slice(explode(' ', $skey->test_description), 0, 40)) . "..."?></p>
                        <a href="<?=base_url()?>get-started/?test_key=<?=$skey->test_key?>" class="blue-button">Take Test</a>
                    </div>
                </div>
            <?php } } ?>   

    </div>
</div>
	<?php } ?>				



  <?php if($has_given_test) { ?>
					<div class="row mt">
                      <div class="col-lg-8">
                       

                              <div class="content-panel">
                          <table class="table table-striped table-advance table-hover">
                            <h4>Test Scores</h4>
                            <hr>
                              <thead>
                              <tr>
                                  <th><i class="fa fa-bars"></i> Test Name</th>
                                  <th class="hidden-phone"><i class="fa fa-calendar"></i> Date </th>
                                  <th><i class="fa fa-line-chart"></i> Score</th>
                                  <th><i class="fas fa-clipboard-check"></i> Remarks </th>
                                  
                              </tr>
                              </thead>
                              <tbody>
                               <?php foreach ($testdetails->result() as $td) { ?>
                               <?php if($td->is_ssb) { ?>

                                   <tr>
                                  <td><a href="javascript:void(0)"><?=$td->test_type_name?></a></td>
                                  <td class="hidden-phone"><?=date("d M y",strtotime($td->test_timestamp))?></td>
                                  <?php if($td->test_status==1)
                                  { ?>
                                    <td><?=$td->test_score?> %</td>
                                  <?php if($td->test_score>=33) { ?>
                                  <td><span class="label label-success label-mini">Qualified</span></td>
                                  <?php } else { ?>
                                    <td><span class="label label-danger label-mini">Not Qualified</span></td>
                                  <?php } ?>
                                 
                                 <?php  } else { ?>
                                 <td>N/A </td>
                                  <td><span class="label label-warning label-mini">Result Pending</span></td>
                                  
                                     
                                  
                                  <?php } ?>
                                     
                                     
                              </tr>

                               <?php } else {?>

                                   <?php if($td->test_status==1) { ?>
                                  <tr>
                                  <td><a href="javascript:void(0)"><?=$td->test_type_name?></a></td>
                                  <td class="hidden-phone"><?=date("d M y",strtotime($td->test_timestamp))?></td>
                                  <td><?=$td->test_score?> %</td>
                                  <?php if($td->test_score>=33) { ?>
                                  <td><span class="label label-success label-mini">Qualified</span></td>
                                  <?php } else { ?>
                                    <td><span class="label label-danger label-mini">Not Qualified</span></td>
                                  <?php } ?>
                                 
                              </tr>
                              <?php } ?>

                               <?php } ?>
                               <?php } ?>
                              </tbody>
                          </table>
                      </div><!-- /content-panel -->
                      </div>
                     
                  </div>
                  <?php } ?>

<?php if($user_rec->num_rows()>0) { ?>
    <div class="index-content">
 <div class="border-head">
                          <h3>Our Recommendation</h3>
                      </div>
    <div class="container">
      <?php foreach ($user_rec->result() as $rkey) { ?>
      <?php if($rkey->test_status) { ?>
            <a href="javascript:void(0)">
                <div class="col-lg-4">
                    <div class="card">
                        <img src="<?=$rkey->test_img_url?>">
                         <h4><?=strtoupper($rkey->test_name)?></h4>
                     <p><?=implode(' ', array_slice(explode(' ', $rkey->test_description), 0, 40)) . "..."?></p>
                        <a href="<?=base_url()?>enroll-now/?test_key=<?=$rkey->test_key?>" class="blue-button">Enroll Now</a>
                    </div>
                </div>
            </a>
           
<?php } } ?> 
    </div>
</div>
	<?php } ?> 				
                  </div><!-- /col-lg-9 END SECTION MIDDLE -->
                  
                  
      <!-- **********************************************************************************************************************************************************
      RIGHT SIDEBAR CONTENT
      *********************************************************************************************************************************************************** -->                  
                  
         
                      
                  </div><!-- /col-lg-3 -->
              </div><! --/row -->
          </section>
      </section>
