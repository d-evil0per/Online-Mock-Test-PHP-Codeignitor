<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">USER DETAILS </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title">Transaction Details</h3>
            </div>
            <div class="card-body">
              <div class="col-12" style="overflow-x:auto">
                
              <table id="regist_data_table" class="table table-bordered table-striped" style="font-size: .7em;">
                <thead>
                <tr>
                      <th>Payment ID</th>
                      <th>Payeer Name</th>
                      <th>Payeer Email</th>
                      <th>Payeer mobile</th>
                      <th>Payment Through</th>
                      <th>Payment For</th>
                      <th>Pay Amount</th>
                      <th>Status</th>
                      <th>Payment Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($trans_det->result() as $ltrac) { ?>
                    <tr>
                      <td><a href="javascript:void(0)"><?=$ltrac->pay_id?></a></td>
                      <td><?=$ltrac->user_name?></td>
                      <td><?=$ltrac->user_email?></td>
                      <td><?=$ltrac->user_mobile_no?></td>
                      <td><?=$ltrac->paid_through?></td>
                      <td><?=$ltrac->paid_for?></td>
                      <td><i class="fa fa-rupee"></i> <?=$ltrac->payable_amt?></td>
                      <?php if($ltrac->payment_status==1) { ?>
                         <td><span class="badge badge-success">COMPLETE</span></td>
                         <?php } else if ($ltrac->payment_status==2) { ?>
                         <td><span class="badge badge-danger">FAILED</span></td>
                         <?php } else { ?>
                         <td><span class="badge badge-warning">ABORTED</span></td>
                         <?php } ?>
                      <td>
                        <?=date("d M y",strtotime($ltrac->payment_update_date))?>
                      </td>
                    </tr>
                    <?php } ?>
                </tbody>
                <tfoot>
              <tr>
                      <th>Payment ID</th>
                      <th>Payeer Name</th>
                      <th>Payeer Email</th>
                      <th>Payeer mobile</th>
                      <th>Payment Through</th>
                      <th>Payment For</th>
                      <th>Pay Amount</th>
                      <th>Status</th>
                      <th>Payment Date</th>
                    </tr>
                </tfoot>
              </table>
              
            </div>
            </div>
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>



    <!-- /.content -->
     </div>
          <script>
  $(function () {
    
    $('#regist_data_table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
