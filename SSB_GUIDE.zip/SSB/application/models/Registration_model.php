<?php 
class Registration_model extends CI_Model{
    function __construct() {
        parent::__construct();
$this->load->database();
    }

function getcourse_details()
{
	return $this->db->query("SELECT * FROM registration_details");
}
function get_course_details_by_id($id)
{
	return $this->db->query("SELECT * FROM registration_details where course_id=$id")->row();
}

function insert_registration($data)
{
	$this->db->insert("registration_enquiry",$data);
}

  function getLastOrderNumber(){
  		$sql = "Select ifnull(max(right(pay_id,4)),0)+1 as id from payment_details ";
  		$result = $this->db->query($sql);	
  		return $result->row();
  	}
  	function savepostpayment($data)
  	{
  		$this->db->insert("payment_details",$data);
  	}
function getpayment_detail($name)
{
    return $this->db->query("SELECT * FROM payment_credentials WHERE gateway_name='$name'")->row();
}
function updatepaymentdetails($order_id,$status,$encResponse)
  {
      $currDate = date("Y-m-d H:i:s");
       $sql = "UPDATE  payment_details SET  payment_status=$status,payment_response='".$encResponse."',payment_update_date='$currDate' where pay_id='".$order_id."'";
      
              $res=$this->db->query($sql);   
             
  }
}