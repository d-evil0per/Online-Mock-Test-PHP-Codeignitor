<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">Registeration- View/Edit </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title">Registration Details</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <?php if($viewtype=="VIEW") { ?>
              <div class="col-12" style="overflow-x:auto">
                
              <table id="regist_data_table" class="table table-bordered table-striped" style="font-size: .7em;">
                <thead>
                <tr>
                  <th>Course Id</th>
                  <th>Course Name</th>
                  <th>Course Duration (in days)</th>
                  <th>Type Of Entry (only for SSB)</th>
                  <th>Previous Experience (only for SSB)</th>
                  <th>Course Commencement Date</th>
                  <th>Course Fee</th>
                  <th>Course Registration Fee</th>
                  <th>Course created On</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
               <?php foreach ($reg_det->result() as $regkey) { ?>
                 <tr>
                  <td><?=$regkey->course_id?></td>
                  <td><?=$regkey->course_name?></td>
                  <td><?=$regkey->course_duration?></td>
                  <td><?php if($regkey->type_of_entry==""){ echo "N/A"; }else{ echo $regkey->type_of_entry; } ?></td>
                  <td><?php if($regkey->previous_experience==""){ echo "N/A"; }else{ echo $regkey->previous_experience; } ?></td>
                  <td><?=$regkey->course_commencement_date?></td>
                  <td><?=$regkey->fee_amount?></td>
                  <td><?=$regkey->registration_fee?></td>
                  <td><?=$regkey->created_timestamp?></td>
                  <td><a href="<?=base_url()?>admin/registration-details/?type=rd-view-edit&course_id=<?=$regkey->course_id?>">Edit</a></td>
                 </tr>
              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                   <th>Course Id</th>
                  <th>Course Name</th>
                  <th>Course Duration (in days)</th>
                  <th>Type Of Entry (only for SSB)</th>
                  <th>Previous Experience (only for SSB)</th>
                  <th>Course Commecement Date</th>
                  <th>Course Fee</th>
                  <th>Course Registration Fee</th>
                  <th>Course created On</th>
                  <th>Action</th>
                </tr>
                </tfoot>
              </table>
              
            </div>
            <?php } else if($viewtype=="EDIT") { ?>
            <div class="col-6">
              <input type="hidden" name="cid" id="cid" value="<?=$cid?>">

                <div class="form-group">
                    <label for="c_name">Course Name <sup>*</sup></label>
                    <input type="text" class="form-control" id="c_name" placeholder="Course name" value="<?=$course_name?>">
                  </div>
                   <div class="form-group">
                    <label for="c_duration">Course Duration (In Days) <sup>*</sup></label>
                    <input type="number" class="form-control" min="1" id="c_duration" placeholder="Course Duration" value="<?=$course_duration?>">
                  </div>
                   <div class="form-group">

                    <label for="c_toe">Type OF Entry (Only For SSB)</label>
                    <small><p>Note: All Options Must Seprated by " , ". e.g : Technical,written etc</p></small>
                    <input type="text" class="form-control" id="c_toe" placeholder="Type OF Entry" value="<?=$type_of_entry?>">
                  </div>
                   <div class="form-group">
                    <label for="c_spe">SSB Previous Experience (only For SSB) </label>
                    <small><p>Note: All Options Must Seprated by " , ". e.g : Fresher,Dropouts etc</p></small>
                    <input type="text" class="form-control" id="c_spe" placeholder="SSB Previous Experience " value="<?=$previous_experience?>">
                  </div>
                   <div class="form-group">
                    <label for="c_cdate">Course Commencement Date <sup>*</sup></label>
                     <small><p>Note: All Dates Must Seprated by " , ". e.g : 2018-06-01,2018-06-16 etc</p></small>
                    <input type="text" class="form-control" id="c_cdate" placeholder="Course Commencement Date" value="<?=$course_commencement_date?>">
                  </div>
                   <div class="form-group">
                    <label for="c_fee">Course Fee <sup>*</sup></label>
                    <input type="number" class="form-control" min="0" id="c_fee" placeholder="Course Fee" value="<?=$fee_amount?>">
                  </div>
                   <div class="form-group">
                    <label for="c_rfee">Course Registration Fee <sup>*</sup></label>
                    <input type="number" class="form-control" min="0" id="c_rfee" placeholder="Course Registration Fee" value="<?=$registration_fee?>">
                  </div>
                 
                <div  id="error_msg" style="color:#ff0000;display:none">
               
              </div>  
            </div>
              <?php }  else {?>
               <div class="col-6">
              

                <div class="form-group">
                    <label for="c_name">Course Name <sup>*</sup></label>
                    <input type="text" class="form-control" id="c_name" placeholder="Course name" >
                  </div>
                   <div class="form-group">
                    <label for="c_duration">Course Duration (In Days) <sup>*</sup></label>
                    <input type="number" class="form-control" min="1" id="c_duration" placeholder="Course Duration" >
                  </div>
                   <div class="form-group">

                    <label for="c_toe">Type OF Entry (Only For SSB)</label>
                    <small><p>Note: All Options Must Seprated by " , ". e.g : Technical,written etc</p></small>
                    <input type="text" class="form-control" id="c_toe" placeholder="Type OF Entry" >
                  </div>
                   <div class="form-group">
                    <label for="c_spe">SSB Previous Experience (only For SSB) </label>
                    <small><p>Note: All Options Must Seprated by " , ". e.g : Fresher,Dropouts etc</p></small>
                    <input type="text" class="form-control" id="c_spe" placeholder="SSB Previous Experience " >
                  </div>
                   <div class="form-group">
                    <label for="c_cdate">Course Commencement Date <sup>*</sup></label>
                     <small><p>Note: All Dates Must Seprated by " , ". e.g : 2018-06-01,2018-06-16 etc</p></small>
                    <input type="text" class="form-control" id="c_cdate" placeholder="Course Commencement Date" v>
                  </div>
                   <div class="form-group">
                    <label for="c_fee">Course Fee <sup>*</sup></label>
                    <input type="number" class="form-control" min="0" id="c_fee" placeholder="Course Fee" >
                  </div>
                   <div class="form-group">
                    <label for="c_rfee">Course Registration Fee <sup>*</sup></label>
                    <input type="number" class="form-control" min="0" id="c_rfee" placeholder="Course Registration Fee" >
                  </div>
                 
                <div  id="error_msg" style="color:#ff0000;display:none">
               
              </div>  
            </div>
              <?php } ?>
            </div>
            <?php if($viewtype=="EDIT") { ?>
            <div class="card-footer">
              
                  <button type="button" class="btn btn-primary"  id="btn_update" onclick="update()">Update</button>
                  <a  class="btn btn-secondary" href="javascript:void(0)" onclick="delete_course()" >Delete</a>
                </div>
                <?php } ?>
                <?php if($viewtype=="ADD") { ?>
            <div class="card-footer">
              
                  <button type="button" class="btn btn-primary"  id="btn_update" onclick="add()">ADD</button>
                  <a  class="btn btn-secondary" href="<?=base_url()?>admin" >Cancel</a>
                </div>
                <?php } ?>
            <!-- /.card-body -->
          </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <!-- /.content -->
     </div>
     <?php if($viewtype=="VIEW") { ?>
     <script>
  $(function () {
    
    $('#regist_data_table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
<?php } else if ($viewtype=="EDIT"){ ?>
<script type="text/javascript">
  

  function delete_course()
{
  var cid=$("#cid").val();
   var url="<?=base_url()?>admin_dashboard/delete_reg_det";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{cid:cid},
                         dataType: 'json',
                           
                              success: function(data) 
                                  {  
                                   
                                      if(data['status']=="success")
                                      {
                                        window.location=data['url'];
                                      }
                                  }
                                });
}



  function update()
  {
    var c_name=$("#c_name").val();
    var cid=$("#cid").val();
    var c_duration=$("#c_duration").val();
    var c_toe=$("#c_toe").val();
    var c_spe=$("#c_spe").val();
    var c_cdate=$("#c_cdate").val();
    var c_fee=$("#c_fee").val();
    var c_rfee=$("#c_rfee").val();


    if(c_name=="" || c_duration=="" || c_cdate=="" || c_fee=="" || c_rfee=="")
    {
      $("#error_msg").html("Please  Fill The  '*' Required Fields ");
      $("#error_msg").show(0).delay(3000).hide(0);
      return false;
    }

       var url="<?=base_url()?>admin_dashboard/update_reg_det";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{cid:cid,c_name:c_name,c_duration:c_duration,c_toe:c_toe,c_spe:c_spe,c_cdate:c_cdate,c_fee:c_fee,c_rfee:c_rfee},
                         dataType: 'json',
                            beforSend:function()
                            {
                              $("#btn_update").html("Updating..");
                              $("#btn_update").removeAttr("onclick");
                            },
                              success: function(data) 
                                  {  
                                    $("#btn_update").html("Update");
                                    $("#btn_update").attr("onclick","update()");
                                      if(data['status']=="success")
                                      {
                                        window.location=data['url'];
                                      }
                                  }
                                });
                            

  }
</script>
<?php } else {  ?>
<script type="text/javascript">
  
  function add()
  {
    var c_name=$("#c_name").val();
    var cid=$("#cid").val();
    var c_duration=$("#c_duration").val();
    var c_toe=$("#c_toe").val();
    var c_spe=$("#c_spe").val();
    var c_cdate=$("#c_cdate").val();
    var c_fee=$("#c_fee").val();
    var c_rfee=$("#c_rfee").val();


    if(c_name=="" || c_duration=="" || c_cdate=="" || c_fee=="" || c_rfee=="")
    {
      $("#error_msg").html("Please  Fill The  '*' Required Fields ");
      $("#error_msg").show(0).delay(3000).hide(0);
      return false;
    }

       var url="<?=base_url()?>admin_dashboard/add_reg_det";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{cid:cid,c_name:c_name,c_duration:c_duration,c_toe:c_toe,c_spe:c_spe,c_cdate:c_cdate,c_fee:c_fee,c_rfee:c_rfee},
                         dataType: 'json',
                            beforSend:function()
                            {
                              $("#btn_update").html("ADD");
                              $("#btn_update").removeAttr("onclick");
                            },
                              success: function(data) 
                                  {  
                                    $("#btn_update").html("ADD");
                                    $("#btn_update").attr("onclick","add()");
                                      if(data['status']=="success")
                                      {
                                        window.location=data['url'];
                                      }
                                  }
                                });
                            

  }
</script>
<?php } ?>