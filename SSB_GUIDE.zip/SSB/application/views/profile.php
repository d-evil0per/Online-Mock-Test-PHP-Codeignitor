<!--main content start-->
      <section id="main-content">
          <section class="wrapper">
          
              <!-- page start-->
          <!--  <link href="//netdna.bootstrapcdn.com/bootstrap/3.1.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.1.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script> -->
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class=" well white-panel" >
        <center>
        <a href="#aboutModal" data-toggle="modal" data-target="#myModal"><img src="<?=$user_avator?>" name="aboutme" width="140" height="140" class="img-circle"></a>
        <h3><?=$user_name?></h3>
        <h6 class="color-red"> @<?=$user_id?> </h6>
        <h6 class="color-red"> <?=$user_gender?> </h6>
         <h6 ><i class="fa fa-map-marker"></i><?php if($user_location==""){ echo "somewhere in the earth"; }else{ echo $user_location;}?></h6>
        <hr class="border-red">
        <div class="row">
                    <div class="col-md-3">
                      <p class="small mt">MEMBER SINCE</p>
                      <p class="color-red"><?=date("d M Y",strtotime($user_profile_created_date))?></p>
                    </div>
                    <div class="col-md-3">
                      <p class="small mt">Date Of Birth</p>
                      <p class="color-red"><?=date("d/M/Y",strtotime($user_dob))?></p>
                    </div>
                     <div class="col-md-3">
                      <p class="small mt">Email</p>
                      <p class="color-red"><?=$user_email?></p>
                    </div>
                     <div class="col-md-3">
                      <p class="small mt">Mobile</p>
                      <p class="color-red"><?php if($user_mobile==""){ echo "N/A"; }else{ echo $user_mobile;}?></p>
                    </div>
                    

                  </div>
                  <hr class="border-red">
                   <div class="row">
                    <div class="col-md-12">
                      <p class="small mt">About </p>
                      <p class="color-red"><?php if($user_about==""){ echo "Hi, I am new Here."; }else{ echo $user_about;}?></p>
                    </div>
                   
                    

                  </div>
                  
        <em>click your face to edit</em>
    </center>
    </div>
    <!-- Modal -->
    <style type="text/css">
      
       .profile-dp {
                              
                              opacity: 0;
                              position:relative;
                              width: 0%;
                          }
    </style>
    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header backcolor-yellow ">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true"></button>
                    <h4 class="modal-title" id="myModalLabel">Edit Your Profile</h4>
                    </div>
                <div class="modal-body">
                    <center>
                       
       <input type="file" accept=".png, .jpg, .jpeg" class="profile-dp" name="pic_upload" id="pic_upload" onchange="previewFile(this)">
                    <img src="<?=$user_avator?>" id="profile_pic" name="aboutme" width="140" height="140" border="0" class="img-circle"></a>
                    <a href="javascript:void(0)" onclick="opendailog()"><h5 class="centered" ><i class="fa fa-upload"></i> <b>Change Image</b>
                    </h5></a>
                    <h6 class="color-red"> @<?=$user_id?> </h6>
                    <hr class="border-red">
                    <center>
                          <div class="login-wrap">
                            <input type="hidden" name="id" id="uid" value="<?=$uid?>">
                             <input type="hidden" name="has_changes" id="has_changes" value="0">
                             <div class="alert alert-danger" id="error_pd" style="display:none;"> </div>
                <input type="text" class="form-control" placeholder="Name"  id="name" onchange="setchangeflag()" value="<?=$user_name?>" autofocus required="required">
            <br>
             <input type="email" class="form-control" placeholder="Email" id="email" onchange="setchangeflag()" value="<?=$user_email?>" required="required" >
                <br>
                 <input type="date" class="form-control" placeholder="Date of Birth" id="dob" onchange="setchangeflag()" max="<?=date('Y-m-d')?>" value="<?=date("Y-m-d",strtotime($user_dob))?>" required="required" >
                <br>
                <input type="text" class="form-control" placeholder="Mobile No" onchange="setchangeflag()" id="mobile" value="<?=$user_mobile?>"  required="required">
                <br>
                <input type="text" class="form-control" placeholder="Location" onchange="setchangeflag()" id="location" value="<?=$user_location?>"  required="required">
                     <br>
                     <select class="form-control"  value="<?=$user_gender?>" onchange="setchangeflag()" id="gender" required="required">
                      <option value="">Are You Male,Female OR Others?</option>
                      <option value="Male"<?php if($user_gender=="Male"){ echo "selected"; }?>>Male</option>
                      <option value="Female" <?php if($user_gender=="Female"){ echo "selected"; }?>>Female</option>
                      <option value="Others" <?php if($user_gender=="Female"){ echo "Others"; }?>>Others</option>
                     </select>
                     <br>
                     <textarea class="form-control" id="about" rows="3" onchange="setchangeflag()" id="about" placeholder="Tell Us About Yourself" required="required"><?php if($user_about==""){ echo "Hi, I am new Here."; }else{ echo $user_about;}?></textarea>
                     <br>
            <input type="text" class="form-control" placeholder="Change Password" onchange="setchangeflag()" id="pass"   required="required">
      
            </div>
                    </center>
                </div>
                <div class="modal-footer">
                    <center>
                    <button type="button" class="btn btn-theme05 btn-block" id="btn_save" onclick="save_profile()">Close & Update</button>
                    </center>
                </div>
            </div>
        </div>
    </div>
</div>
              </div>
              <!-- page end-->
          </section>          
      </section><!-- /MAIN CONTENT -->
<script type="text/javascript">



function save_profile()
{
  var has_changes= $("#has_changes").val();
    if(has_changes=="1")
      {
        var id=$("#uid").val();
        var user_name=$("#name").val();
        var user_email=$("#email").val();
        var user_mobile=$("#mobile").val();
        var user_dob=$("#dob").val();
        var user_location=$("#location").val();
        var user_gender=$("#gender").val();
        var user_about=$("#about").val();
        var user_profile_pic=$("#profile_pic").attr("src");
        var user_passkey=$("#pass").val();


            if(user_name=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your Name is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#name").focus();
                return false;
              }
                if(user_email=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your Email is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#email").focus();
                return false;
              }
                var emailReg = /^[\w._-]+[+]?[\w._-]+@[\w.-]+\.[a-zA-Z]{2,6}$/;
              if(!(emailReg.test(user_email)))
              {
                $("#error_pd").html("<b>Opps!</b> Your Valid Email ID is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#email").val("");
                $("#email").focus();
                return false;
              }
                 if(user_dob=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your Date of Birth is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#dob").focus();
                return false;
              }
                if(user_mobile=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your Mobile No is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#mobile").focus();
                return false;
              }
              var intRegex = /[0-9 -()+]+$/;
            if(!(intRegex.test(user_mobile)))
                  {
                $("#error_pd").html("<b>Opps!</b> Please Enter a Valid Mobile Number.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#mobile").val("");
                $("#mobile").focus();
                return false;
                  }
                if(user_location=="")
              {
                $("#error_pd").html("<b>Opps!</b> Your Location is Required.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#location").focus();
                return false;
              }
                if(user_gender=="")
              {
                $("#error_pd").html("<b>Opps!</b> Please select Your Gender.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#gender").focus();
                return false;
              }
                if(user_about=="")
              {
                $("#error_pd").html("<b>Opps!</b> Tell Us About Yourself.");
                $("#error_pd").show(0).delay(3000).hide(0);
                $("#about").focus();
                return false;
              }


              var url="<?=base_url()?>home/save_profile";
                 $.ajax({
                  type: 'POST',
                  url: url, 
                  data:{id:id,user_name:user_name,user_email:user_email,user_mobile:user_mobile,user_dob:user_dob,user_location:user_location,user_gender:user_gender,user_about:user_about,user_profile_pic:user_profile_pic,user_passkey:user_passkey},
                  dataType: 'json',
                  success: function(data) 
                                  { 
                                    window.location.reload();
                                  }
                              });
      }
}



  setInterval(function(){
   var has_changes= $("#has_changes").val();
    if(has_changes=="1")
      {
        $("#btn_save").removeAttr("data-dismiss");
      }
      else
        {
          $("#btn_save").attr("data-dismiss","modal");
        }},2000);


  function setchangeflag()
  {
    $("#has_changes").val(1);
      
  }
  function opendailog()
{

  $('#pic_upload').click();  
  
}
 function previewFile(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
       
      $("#has_changes").val(1);
      
           $("#profile_pic").attr("src",e.target.result);
          
           
      };
      reader.readAsDataURL(input.files[0]);
    }
  }
</script>