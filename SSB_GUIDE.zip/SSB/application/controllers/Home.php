<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

 function __construct() {
        parent::__construct();

 $this->load->model("home_model");
  $this->load->model("registration_model");
 $this->load->helper('url');
 $this->load->library('user_agent');
  require_once ("assets/PHPMailer/PHPMailerAutoload.php");
  include APPPATH . 'third_party/Crypto.php';

   // require_once 'assests/function.resize.php';
 // $this->load->helper('seo_helper');
  
 $this->user_id="";
 $this->user_email="";
  $this->user_name="";

   $this->getsession_data();
       

 }

  function getsession_data()
  {
       if(isset($this->session->userdata['user_id']))
       {
            $this->user_id = $this->session->userdata['user_id'];
            $this->user_name = $this->session->userdata['user_name'];
            $this->user_email=$this->session->userdata['user_email'];
           
        }  


  }

 function loggedin()
 {
    
    if(!isset($this->session->userdata['user_id'])){
        
  return 0;
    }
    else
    {
      return 1;
    }
    

 }

function logout()
{
	$session_data = array(
	   							'user_id',
                                'user_email',
                                'user_name'
                            );
                      // Add user data in session
                      $this->session->unset_userdata($session_data);


    header("Location:".base_url());
}



function signin()
{
	$userid=$_POST['userid'];
	$pass=md5($_POST['pass']);
	$user_details=$this->home_model->getuserby_userid_pass($userid,$pass);
	if($user_details->num_rows()>0)
	{
		$res['status']="success";
		$session_data = array(
	   							'user_id' => $user_details->row()->id,
                                'user_email'=>$user_details->row()->user_email,
                                'user_name'=>$user_details->row()->user_name
                            );
                      // Add user data in session
                      $this->session->set_userdata($session_data);
                      $data_notification = array();
		$data_notification['notification_from']="Admin";
		$data_notification['notification_to']=$user_details->row()->id;
		$data_notification['notification_title']="Welcome Back ".$name;
		$data_notification['notification_Content']="Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ";
		$this->home_model->save_notification($data_notification);
	}
	else
	{
		$res['status']="failure";

	}
	echo json_encode($res);
}


public function index()
{
	  $title="SSB GUIDE";
    $desc="SSB GUIDE , ONLINE NDA,ONLINE CDS, ONLINE AFCAT, ONLINE SSB Mock test";


    $data_header=array();
     $data_header['title']=$title;
    $data_header['desc']=$desc;
	$this->load->view('home',$data_header);
}
public function dashboard()
{
	if(!$this->loggedin())
    {
    	header('Location:'.base_url()."login");
      exit;
    }

    // header data starts here
    $user_id=$this->user_id;
    $user_name=$this->user_name;

    $user_details=$this->home_model->getuser_details($user_id);
    $user_avator=$user_details->user_profile_pic;
    if($user_avator=="")
    {
    	$user_avator=base_url()."assets/img/iconNoAvatar.png";
    }
   


    $getnotifications=$this->home_model->getnotifications($user_id);
    $getnotifications_count=$getnotifications->num_rows();
    $title="User DashBoard | SSB GUIDE";
    $desc="SSB GUIDE DashBoard , ONLINE NDA,ONLINE CDS, ONLINE AFCAT, ONLINE SSB Mock test";


    $data_header=array();
    $data_header['user_name']=$user_name;
    $data_header['user_profile_pic']=$user_avator;
    $data_header['user_notification_count']=$getnotifications_count;
    $data_header['user_notification']=$getnotifications;
    $data_header['title']=$title;
    $data_header['desc']=$desc;
 // header data ends here


// home data starts here


 
 if($user_details->user_selected_test!="")

    {
    	$has_selected_test=1;
    	$selected_test=$this->home_model->gettest_details($user_details->user_selected_test);
    }
    else
    {
    	$has_selected_test=0;
    	$selected_test="";
    }


  $user_rec=$this->home_model->getrecommdation_test($user_details->user_selected_test);
  if($has_selected_test)
  {
 	$has_given_test=1;
 	$test_details=$this->home_model->getusertestdetails($user_id);
	
  }
  else
  {
  	$has_given_test=0;
  }


$data_content = array();
$data_content['has_selected_test']=$has_selected_test;
$data_content['has_given_test']=$has_given_test;
$data_content['selected_test']=$selected_test;
$data_content['user_rec']=$user_rec;
$data_content['testdetails']=$test_details;


// print_r($user_selected_test); 

  // home data ends here

// print_r($rows);
// exit;


	$this->load->view('header',$data_header);
	$this->load->view('dashboard',$data_content);
	$this->load->view('footer');
}

public function profile()
{
	if(!$this->loggedin())
    {
    	header('Location:'.base_url()."login");
      exit;
    }

    // header data starts here
    $user_id=$this->user_id;
    $user_name=$this->user_name;

    $user_details=$this->home_model->getuser_details($user_id);
    $user_avator=$user_details->user_profile_pic;
    if($user_avator=="")
    {
    	$user_avator=base_url()."assets/img/iconNoAvatar.png";
    }
   


    $getnotifications=$this->home_model->getnotifications($user_id);
    $getnotifications_count=$getnotifications->num_rows();
    $title="User Profile | SSB GUIDE";
    $desc="SSB GUIDE DashBoard , ONLINE NDA,ONLINE CDS, ONLINE AFCAT, ONLINE SSB Mock test";


    $data_header=array();
    $data_header['user_name']=$user_name;
    $data_header['user_profile_pic']=$user_avator;
    $data_header['user_notification_count']=$getnotifications_count;
    $data_header['user_notification']=$getnotifications;
    $data_header['title']=$title;
    $data_header['desc']=$desc;
 // header data ends here


// home data starts here


$data_content = array();
$data_content['user_name']=$user_name;
$data_content['user_avator']=$user_avator;
$data_content['user_id']=$user_details->user_id;
$data_content['user_email']=$user_details->user_email;
$data_content['user_mobile']=$user_details->user_mobile;
$data_content['user_dob']=$user_details->user_dob;
$data_content['uid']=$user_details->id;
$data_content['user_location']=$user_details->user_location;
$data_content['user_about']=$user_details->user_about;
$data_content['user_gender']=$user_details->user_gender;
$data_content['user_profile_created_date']=$user_details->user_profile_created_date;






	$this->load->view('header',$data_header);
	$this->load->view('profile',$data_content);
	$this->load->view('footer');
}


function save_profile()
{
	 $id=$_POST['id'];
        $user_name=$_POST['user_name'];
        $user_email=$_POST['user_email'];
        $user_mobile=$_POST['user_mobile'];
        $user_dob=$_POST['user_dob'];
        $user_location=$_POST['user_location'];
        $user_gender=$_POST['user_gender'];
        $user_about=$_POST['user_about'];
      

        // $path=$_SERVER['DOCUMENT_ROOT']."/assets/admin/uploads/profile/";


        $post_array = explode(";",$_POST['user_profile_pic']);
                            $image_type = explode(":",$post_array[0]);
                            
                            
                            
                            if($image_type[1]=="image/jpeg" || $image_type[1]=="image/png" ){
                              switch($image_type[1])
                              {
                                case "image/jpeg":
                                                        $ext=".jpeg";
                                break;
                                case "image/png":
                                                        $ext=".png";
                                break;
                                  
                              }
                              $image =substr($post_array[1],6);
                              $imageData = base64_decode($image);
                              $source = imagecreatefromstring($imageData);
                              $angle = 0;
                              $rotate = imagerotate($source, $angle, 0); 
                              
                                              $path  = $_SERVER['DOCUMENT_ROOT'] ."/assets/admin/uploads/profile/";
                                                $imageurl=base_url()."assets/admin/uploads/profile/";
                                           
                                            
                                            if (!file_exists($path)) {
                                              mkdir($path, 0777, true);
                                            }
                                            
                              date_default_timezone_set('Australia/Melbourne');
                 $date = date('m/d/Yh:i:sa', time());
                 $rand=rand(10000,99999);
                 $encname=$date.$rand;
                             $imagefile=md5($encname).$ext;
                              $imageName=$path.$imagefile;
                              
                                                   
                              $imageSave = imagejpeg($rotate,$imageName,100);
                              imagedestroy($source);
                              list($width, $height, $type, $attr) = getimagesize($imageName);
                             
                              if($width>720)
                              {
                                $config['image_library'] = 'gd2';
                              $config['source_image'] = $imageName;
                              //$config['new_image'] = './image_uploads/';
                              $config['maintain_ratio'] = TRUE;
                              $config['width'] = 720;
                              $this->load->library('image_lib');
                              $this->image_lib->initialize($config);

                              $this->image_lib->resize();

                              $this->image_lib->clear(); 

                            
                          
                              }
                            }


                           
       $user_profile_pic=$imageurl.$imagefile;





        $user_passkey=$_POST['user_passkey'];
        if($user_passkey!="")
        {
        	$data_update['user_passkey']=md5($user_passkey);
        }
        $where['id']=$id;

        $data_update['user_name']=$user_name;
        $data_update['user_email']=$user_email;
        $data_update['user_mobile']=$user_mobile;
        $data_update['user_dob']=$user_dob;
        $data_update['user_location']=$user_location;
        $data_update['user_gender']=$user_gender;
        $data_update['user_about']=$user_about;
        $data_update['user_profile_pic']=$user_profile_pic;
        $this->home_model->update_profile($data_update,$where);
        $res['status']="success";
        echo json_encode($res);
}


public function enroll_now()
{
	if(!$this->loggedin())
    {
    	header('Location:'.base_url()."login");
      exit;
    }
    if(!isset($_GET['test_key']))
    {
    	header('Location:'.base_url()."dashboard");
      exit;
    }


     $user_id=$this->user_id;
    $user_name=$this->user_name;
		$key =$_GET['test_key'];

$chkenroll=$this->home_model->ifalreadyenroll($key,$user_id);
if($chkenroll)
{
	header('Location:'.base_url()."dashboard");
      exit;
}

    $test_details=$this->home_model->gettest_details($key);
       if($test_details->num_rows()>0)
    {


    	   $user_details=$this->home_model->getuser_details($user_id);
    $user_avator=$user_details->user_profile_pic;
    if($user_avator=="")
    {
    	$user_avator=base_url()."assets/img/iconNoAvatar.png";
    }
   


    $getnotifications=$this->home_model->getnotifications($user_id);
    $getnotifications_count=$getnotifications->num_rows();
 


    	$test_name=$test_details->row()->test_name;
        $test_desc=$test_details->row()->test_description;
            
                $test_time=$test_details->row()->test_time_limit;
    $title=$test_name." | SSB GUIDE";
   


    $data_header=array();
   
    $data_header['title']=$title;
    $data_header['desc']=$test_desc;




    $data_header=array();
    $data_header['user_name']=$user_name;
    $data_header['user_profile_pic']=$user_avator;
    $data_header['user_notification_count']=$getnotifications_count;
    $data_header['user_notification']=$getnotifications;
   
		$data_body['desc']=$test_desc;
    $data_body['test_name']=$test_name;
   $data_body['test_fee']=$test_details->row()->test_enrollment_fee;
    $data_body['test_time']=$test_time;
    $data_body['test_key']=$key;
     
    $this->load->view('header',$data_header);
	$this->load->view('enroll-now',$data_body);
	$this->load->view('footer');
	
    }
    else
    {
    	header('Location:'.base_url()."dashboard");
      exit;
    }
 





    

 
    
}


public function skill_test($key)
{
	// echo $key;
if(!$this->loggedin())
    {
    	header('Location:'.base_url()."login");
      exit;
    }
   
    $test_details=$this->home_model->gettest_details($key);

    if($test_details->num_rows()==0)
    {
    	header('Location:'.base_url()."dashboard");
      exit;
    }

    if(isset($_SESSION['user_test_id']))
    {
    	$data['test_score']=0;
		$data['test_time_taken']=0;
		$data['test_status']=1;
		$where['id']=$_SESSION['user_test_id'];
		$this->home_model->update_test_score($data,$where);
		unset($_SESSION['user_test_id']);
		unset($_SESSION['qlimit']);
    }
  
	
$test_time=$test_details->row()->test_time_limit;


// random set genrator
 $sets_indx=$this->home_model->getsets_id($key);
 if($sets_indx->num_rows()==0)
 {
 	header('Location:'.base_url()."get-started/?test_key=".$key);
      exit;
 }
    $set_idarr = array(); 
    foreach ($sets_indx->result() as $sid) {
    	$set_idarr[]=$sid->set_id;
    }
$test_ques=0;

 while (!$test_ques) {
 $randIndex = array_rand($set_idarr);
 
// output the value for the random index
$set=$set_idarr[$randIndex];

$test_ques=$this->home_model->getset_question_count($set);
 }
// get random index from array $arrX
// var_dump($set_idarr);
// echo $set;
// echo $test_ques;
// random set genrator ends



 $data_test_score['test_type_name']=$test_details->row()->test_name;
 if($test_details->row()->test_type=="APPERCEPTION")
 {
   $data_test_score['is_ssb']=1;
 }
 $data_test_score['test_type_key']=$key;
 $data_test_score['user_id']=$this->user_id;
 $data_test['user_test_id']=$this->home_model->inser_test_score($data_test_score);
$data_test['test_type']=$test_details->row()->test_type;
 // $data_test['test_type']="APPERCEPTION";
  $data_test['test_type_name']=$test_details->row()->test_name;
 $data_test['key']=$key;
 $data_test['set']=$set;
 $data_test['qlimit']=$test_ques;
 $data_test['tlimit']=$test_time;
 	$data_test['desc']=$test_details->row()->test_description;
    $data_test['title']=$test_details->row()->test_name."| Test IN PROGRESS" ;

	$_SESSION['user_test_id']=$data_test['user_test_id'];
	$_SESSION['qlimit']=$test_ques;

	$this->load->view('skilltest',$data_test);
}

function submittest()
{

	$time=$_POST['time'];
	$test_id=$_POST['test_id'];
	
	$answer=$_SESSION['SET_USER_ANSWER'];
	
	$pos=0;
	$neg=0;
	foreach ($answer as $q => $a) {
		$c_ans=$this->home_model->getcorrect_ans($q);
		if($c_ans==$a)
		{
			$pos++;
		}
		else
		{
			$neg++;
		}
	}

$sum=$_SESSION['qlimit'];
$percentage=($pos/$sum)*100;


$data['test_score']=$percentage;
$data['test_time_taken']=$time;
$data['test_status']=1;
$where['id']=$test_id;
$this->home_model->update_test_score($data,$where);
unset($_SESSION['user_test_id']);
// $res['pos']=$pos;
// $res['neg']=$neg;
// $res['time']=$time;
// $res['test_id']=$test_id;
// $res['score']=json_encode($_SESSION['SET_USER_ANSWER']);
// $res['%']=$percentage;
$res['status']="success";
$res['url']=base_url()."dashboard";
	echo json_encode($res);
}
function ssbsubmittest()
{

	$time=$_POST['time'];
	$test_id=$_POST['test_id'];
	
	$answer=$_SESSION['SET_USER_ANSWER'];
	

	foreach ($answer as $q => $a) {
		$data['test_score_id']=$test_id;
		$data['test_ques_id']=$q;
		$data['user_answer']=$a;
		$this->home_model->save_ssb_answer($data);
		
	}
	$data_ts['test_time_taken']=$time;

$where['id']=$test_id;
$this->home_model->update_test_score($data_ts,$where);
unset($_SESSION['user_test_id']);
             $data_notification = array();
		$data_notification['notification_from']="Admin";
		$data_notification['notification_to']=$this->user_id;
		$data_notification['notification_title']="Result Pending";
		$data_notification['notification_Content']="Hi, You have successfully Given Your SSB Test, Soon Result Will Be Shown In your Dashboard<br> Cheers    ";
		$this->home_model->save_notification($data_notification);
$content="Hi Team,<br><br> A new SSB Test Submission has been done By ".$this->user_name." <br>Please Check on this Link <s ref='".base_url()."admin/ssb-answers/?uid=".$this->user_id."&test_id=".$test_id."'> Click To View </a> <br>Cheers<br><br> Team SSB GUIDE";
		


$subject="New SSB Test Submission -".date("d, M y h:iA");
		$res1=$this->sendmail('ndassbguide@gmail.com','SSB GUIDE',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content);

$res['status']="success";

	echo json_encode($res);
}

function getssbquestion()
{
	$is_first=$_POST['is_first'];
	$setid=$_POST['setid'];
	$ques_id=$_POST['ques_id'];
	$answer=$_POST['answer'];
	$start=$_POST['start'];
	$end=$_POST['end'];
	$qlimit=$_POST['qlimit'];
	if(!$is_first)
	{
		
		$_SESSION['SET_USER_ANSWER'][$ques_id]=$answer;

	}
	else
	{
		unset($_SESSION['SET_USER_ANSWER']);
	}
if($start<$qlimit)
{
	$ques=$this->home_model->getquestions($setid,$start,$end);

	
		$res['status']="OK";
		$res['id']=$ques->question_id;
		$res['img']=$ques->question_content;
		


	}
	else
{
$res['status']="Not-OK";
	
		
}
	echo json_encode($res);
}

function getquestion()
{
	$is_first=$_POST['is_first'];
	$setid=$_POST['setid'];
	$ques_id=$_POST['ques_id'];
	$answer=$_POST['answer'];
	$start=$_POST['start'];
	$end=$_POST['end'];
	$qlimit=$_POST['qlimit'];
	if(!$is_first)
	{
		
		$_SESSION['SET_USER_ANSWER'][$ques_id]=$answer;

	}
	else
	{
		unset($_SESSION['SET_USER_ANSWER']);
	}
if($start<$qlimit)
{
	$ques=$this->home_model->getquestions($setid,$start,$end);

	
		$res['status']="OK";
		$res['id']=$ques->question_id;
		$res['content']=$ques->question_content;
		$qoptions=explode("##",$ques->question_options);
		$qops="";
		foreach ($qoptions as $options) {
			$qops.=' <li class="list-group-item d-flex justify-content-between align-items-center"> 
                            <div class="radio">
                            <label>
                              <input type="radio" name="optionsRadios" id="optionsRadios2" value="'.$options.'">'.$options.'
                            </label>
                          </div>
                        </li>';
		}
		$res['options']=$qops;


	}
	else
{
$res['status']="Not-OK";
	
		
}
	echo json_encode($res);
}
public function get_test_started()
{
	if(!$this->loggedin())
    {
    	header('Location:'.base_url()."login");
      exit;
    }
    if(!isset($_GET['test_key']))
    {
    	header('Location:'.base_url()."dashboard");
      exit;
    }
    $key =$_GET['test_key'];

    $test_details=$this->home_model->gettest_details($key);

    if($test_details->num_rows()>0)
    {
    	$test_name=$test_details->row()->test_name;
        $test_desc=$test_details->row()->test_description;
            $test_instr=$test_details->row()->test_instructions;
                $test_time=$test_details->row()->test_time_limit;
    $title=$test_name." | SSB GUIDE";
   


    $data_header=array();
   
    $data_header['title']=$title;
    $data_header['desc']=$test_desc;

    $data_header['test_name']=$test_name;
    $data_header['test_instr']=$test_instr;
    $data_header['test_time']=$test_time;
    $data_header['test_key']=$key;
     
    
	$this->load->view('get-started',$data_header);
    }
    else
    {
    	header('Location:'.base_url()."dashboard");
      exit;
    }
    
}
public function notification()
{
	if(!$this->loggedin())
    {
    	header('Location:'.base_url()."login");
      exit;
    }

    // header data starts here
    $user_id=$this->user_id;
    $user_name=$this->user_name;

    $user_details=$this->home_model->getuser_details($user_id);
    $user_avator=$user_details->user_profile_pic;
    if($user_avator=="")
    {
    	$user_avator=base_url()."assets/img/iconNoAvatar.png";
    }
   


    $getnotifications=$this->home_model->getnotifications($user_id);
    $getnotifications_count=$getnotifications->num_rows();
    $title="User Profile | SSB GUIDE";
    $desc="SSB GUIDE DashBoard , ONLINE NDA,ONLINE CDS, ONLINE AFCAT, ONLINE SSB Mock test";


    $data_header=array();
    $data_header['user_name']=$user_name;
    $data_header['user_profile_pic']=$user_avator;
    $data_header['user_notification_count']=$getnotifications_count;
    $data_header['user_notification']=$getnotifications;
    $data_header['title']=$title;
    $data_header['desc']=$desc;
 // header data ends here


// home data starts here

$notifications=$this->home_model->getnotificationsALL($user_id);

$data_content = array();
$data_content['notifications']=$notifications;





	$this->load->view('header',$data_header);
	$this->load->view('notification',$data_content);
	$this->load->view('footer');
}


function getlatestnotification()
{
	$user_id=$this->user_id;
	$notifications=$this->home_model->getnotifications($user_id);
	if($notifications->num_rows()>0)
	{
		$res['status']="success";
		$res['id']=$notifications->row()->id;
	$res['title']="<center>".$notifications->row()->notification_title."</center>";
	$res['content']="<center>".$notifications->row()->notification_content."</center>";
	}
	else
	{
		$res['status']="failure";
	}
	
	echo json_encode($res);
}

function marker_notification_seen_byid()
{
	$id=$_POST['id'];
	$this->home_model->setstatus_notification($id);
	$res['status']="success";
	echo json_encode($res);
}



public function login()
{
	if($this->loggedin())
    {
    	header('Location:'.base_url()."dashboard");
      
    }

	$test_series=$this->home_model->gettest_allseries();
	$data['test_series']=$test_series;
	$this->load->view('login',$data);
}
function chkuid()
{
	$value=$_POST['value'];
	$chk=$this->home_model->chkuid($value);
	if($chk)
	{
		$res['status']="failure";
	}
	else
	{
		$res['status']="success";
	}
	echo json_encode($res);
}
function chkemail()
{
	$value=$_POST['value'];
	$chk=$this->home_model->chkemail($value);
	if($chk)
	{
		$res['status']="failure";
	}
	else
	{
		$res['status']="success";
	}
	echo json_encode($res);
}

function gettestdetails()
{
	$key=$_POST['value'];
	$testdetails=$this->home_model->gettestdetails($key);
	$res['status']="success";
	$res['price']=$testdetails->test_enrollment_fee;
	$res['name']=$testdetails->test_name;
	echo json_encode($res);
}


function forgetpass()
{
	$email=$_POST['email'];

	$chk=$this->home_model->chkemail($email);
	if($chk)
	{
			 $characters = '0123456789AZXSQWEDCRFVTGBYHNUJMIKOLPqawszxedcrfvvtgbyhnmujkiolp!@#$%^&*';
           $string = '';
           for ($i = 0; $i < 6; $i++)
            {
                 $string .= $characters[rand(0, strlen($characters) - 1)];
            }


    $this->home_model->updatepass($email,$string);
	$sub="Request For Reset Password At SSB GUIDE";
		$con="Hi,<br><br> You have Requested For Password Reset.<br> Please Signin Using this temporary password and Reset it from your profile. <br> PASSWORD :".$string." <br>Please Call <b>7015173285</b> Or Whatsapp On <b>8572857321</b> For Any help. <br> Cheers <br><br> Team SSB GUIDE";

		$res2=$this->sendmail($data_insert['user_email'],$data_insert['user_name'],"noreply@ssbguide.com","SSB GUIDE Team",$sub,$con);
		$res['status']="success";




	}
	else
	{
		$res['status']="failure";
	}




		
		echo json_encode($res);
}


function signup_withoutpay()
{
	$name=$_POST['name'];
	$email=$_POST['email'];
	$dob=$_POST['dob'];
	$uid=$_POST['uid'];
	$pass=$_POST['pass'];
	$test_key=$_POST['test_type'];


		$data_insert = array();
		$data_insert['user_name']=$name;
		$data_insert['user_email']=$email;
		$data_insert['user_id']=$uid;
		$data_insert['user_passkey']=md5($pass);
		$data_insert['user_dob']=$dob;

	$id=$this->home_model->insert_signup($data_insert);

	$data_notification = array();
		$data_notification['notification_from']="Admin";
		$data_notification['notification_to']=$id;
		$data_notification['notification_title']="Welcome To SSB GUIDE";
		$data_notification['notification_Content']="Hi ".$name.", <br> You have been Signed up Successfully. Please Complete Your Profile And Explore Our Recommendation Section for Enrollments.<br> Cheers    ";
		$this->home_model->save_notification($data_notification);

	   $session_data = array(
	   							'user_id' => $id,
                                'user_email'=>$email,
                                'user_name'=>$name
                            );
                      // Add user data in session
                      $this->session->set_userdata($session_data);


	   	$content="Hi Team,<br><br> A new Signup has been done, Please find the candidate's details below.<br><table border='1'><tr><th>Candidate Name</th><th>Email</th><th>Date Of Birth</th><th>User Id</th></tr><tr><td>".$data_insert['user_name']."</td><td>".$data_insert['user_email']."</td><td>".$data_insert['user_dob']."</td><td>".$data_insert['user_id']."</td></tr></table><br> Cheers<br><br> Team SSB GUIDE";
		
		

		


		$subject="New Signup #".$data_insert['user_name']." - ".date("d, M y h:iA");
		$res1=$this->sendmail('ndassbguide@gmail.com','SSB GUIDE',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content);
		// $res1=$this->sendmail('dhir.xcess@gmail.com','Developer',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content); //for test purpose

		$sub="Signup Successful At SSB GUIDE";
		$con="Hi ".$data_insert['user_name'].",<br><br> You have been successfully Signed up . <br> Please Call <b>7015173285</b> Or Whatsapp On <b>8572857321</b> For Any help. <br> Cheers <br><br> Team SSB GUIDE";

		$res2=$this->sendmail($data_insert['user_email'],$data_insert['user_name'],"noreply@ssbguide.com","SSB GUIDE Team",$sub,$con);


                      $res['url']=base_url()."dashboard";
                      echo json_encode($res);
	
}







function enrollment_pay()
{
	$key="";

if(isset($_POST['key']))
{
		
		$key=$_POST['key'];
		$session_data = array();
		$session_data['key']=$key;
		$this->session->set_userdata($session_data);
}
else if (isset($this->session->userdata['key']))
{
	$key=$this->session->userdata['key'];
}


$currDate = date("Y-m-d h:i");
	$test_details=$this->home_model->gettestdetails($key);
	$test_name=$test_details->test_name;
	$test_price=$test_details->test_enrollment_fee;

	$uid=$this->user_id;
	$user_details=$this->home_model->getuser_details($uid);
	$name=$user_details->user_name;
	$email=$user_details->user_email;
	$address=$user_details->user_location;
	$mobile=$user_details->user_mobile;
	$session_id = md5(date("Y-m-d").$email);

      $max_paymentid = $this->registration_model->getLastOrderNumber();
      if (strlen($max_paymentid->id) == 1)
        $start_char = '000'.strval($max_paymentid->id);
      else if(strlen($max_paymentid->id) == 2 )
        $start_char = '00'.strval($max_paymentid->id);
      else if(strlen($max_paymentid->id) == 3 )
        $start_char = '0'.strval($max_paymentid->id);
      else
        $start_char = strval($max_paymentid->id);
      
       $payment_number = date("ym").$start_char;
    $data=array(
                  	'pay_id'=>$payment_number,
                    'session_id'=>$session_id,
                    'user_name'=>$name,
                    'user_address'=>$address,
                    'user_mobile_no'=>$mobile,
                    'user_email'=>$email,
                    'paid_for'=>$test_name,
                    'paid_through'=>"Enrollment-".$test_name,
                    'payable_amt'=>$test_price,
                    'payment_date'=>$currDate,
                    'payment_status'=>0,
                    
                );  
 $order_id = $this->registration_model->savepostpayment($data);


      $cc_data = array();
      $payment_gateway=$this->registration_model->getpayment_detail("CCAvenue");
      $cc_data['merchant_id'] = $payment_gateway->merchant_id;
      $cc_data['order_id'] = $payment_number;
      $cc_data['amount'] = $test_price;
      $cc_data['currency'] = $payment_gateway->currency;
      $cc_data['redirect_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/home/enroll_paymentstatus';
      $cc_data['cancel_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/home/enroll_paymentstatus';
      $cc_data['language'] = 'EN';
      $cc_data['billing_name'] = $name;
      $cc_data['billing_email'] = $email;
      $cc_data['billing_address'] = $address;
      $cc_data['billing_tel'] = $mobile;
     
      

   
      $working_key = $payment_gateway->working_key;
      $access_code = $payment_gateway->access_key;
        
      
      $merchant_data='';
    
      foreach ($cc_data as $key => $value){
        $merchant_data.=$key.'='.$value.'&';
      }

        $encrypted_data=encrypt($merchant_data,$working_key); // Method for encrypting the data.
   
        // $test_url=str_replace("##ENC_DATA##",$encrypted_data, $payment_gateway->test_payment_gateway);
        $test_url=str_replace("##ENC_DATA##",$encrypted_data, $payment_gateway->live_payment_gateway); //live payment 
        $test_url=str_replace("##ACCESS_CODE##",$access_code,$test_url);
        
      
    
      $res['url']=$test_url;                  
      echo json_encode($res);

}


function enroll_paymentstatus()
{


 $payment_gateway=$this->registration_model->getpayment_detail("CCAvenue");
 
  $working_key = $payment_gateway->working_key;      
      

    $encResponse=$_POST["encResp"];     //This is the response sent by the CCAvenue Server
  $rcvdString=decrypt($encResponse,$working_key);   //Crypto Decryption used as per the specified working key.
  $order_status="";
  $decryptValues=explode('&', $rcvdString);
  $dataSize=sizeof($decryptValues);
  $ref_no='';
        $status='';
        $amount='';
        $order_id='';
        $currDate = date("Y-m-d H:i:s");
  for($i = 0; $i < $dataSize; $i++) 
  {
    $information=explode('=',$decryptValues[$i]);
              
    if($i==3) $order_status=$information[1];
                if($i==2)       $ref_no=$information[1];
                if($i==10)       $amount=$information[1];
                if($i==0)       $order_id=$information[1];
  }

  if($order_status==="Success")
  {
    $status=1;
    
  }
  else if($order_status==="Aborted")
  {
    $status=3;
  
  }
  else if($order_status==="Failure")
  {
    $status=2;
  }
  else
  {
    $status=2;
  
  }

  // print_r($decryptValues);
  // echo $status;
  // exit;      

  
    
    

            if(!isset($this->session->userdata['key']))
                        {
                            echo '<script>window.location = "'.base_url().'"</script>';
                        }
          
      					
						$key=$this->session->userdata['key'];



                          $this->registration_model->updatepaymentdetails($order_id,$status,$encResponse);
                         

             if($status==1)
             {
                   
       
		
		$data_update = array();
		$uid=$this->user_id;
		$user_details=$this->home_model->getuser_details($uid);
		$name=$user_details->user_name;
		$email=$user_details->user_email;
		$u_test=$user_details->user_selected_test;
		if($u_test=="")
		{
			$data_update['user_selected_test']=$key;
		}
		else
		{
			$data_update['user_selected_test']=$u_test.",".$key;
		}
		$where['id']=$uid;
		$id=$this->home_model->update_profile($data_update,$where);
		$test_details=$this->home_model->gettestdetails($key);
		$test_name=$test_details->test_name;
	
	
			$content="Hi Team,<br><br> A new Erollment has been done By ".$name." In ".$test_name."<br> Cheers<br><br> Team SSB GUIDE";
		
		

		


		$data_notification = array();
		$data_notification['notification_from']="Admin";
		$data_notification['notification_to']=$uid;
		$data_notification['notification_title']="Successfully Enrolled In ".$test_name;
		$data_notification['notification_Content']="Hi ".$name.", <br> You have been  Enrolled In ".$test_name." Test Series. <br> Cheers    ";
		$this->home_model->save_notification($data_notification);



		$subject="New Enrollemnt #".$name." IN ".$test_name." - ".date("d, M y h:iA");
		$res1=$this->sendmail('ndassbguide@gmail.com','SSB GUIDE',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content);
		// $res1=$this->sendmail('dhir.xcess@gmail.com','Developer',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content); //for test purpose

		$sub="Enrollment Successful In ".$test_name." At SSB GUIDE";
		$con="Hi ".$name.",<br><br> You have been successfully  Enrolled In ".$test_name.". <br> Please Call <b>7015173285</b> Or Whatsapp On <b>8572857321</b> For Any help. <br> Cheers <br><br> Team SSB GUIDE";

		$res2=$this->sendmail($email,$name,"noreply@ssbguide.com","SSB GUIDE Team",$sub,$con);
               
                       $session_data = array('enroll_payment_status' => 1,
                                              'order_id'=>$order_id,
                                               'price'=>$amount);
                      // Add user data in session
                      $this->session->set_userdata($session_data);



                             $session_data = array('key');
                      $this->session->unset_userdata($session_data);
                    
                      
                      
             }
             else
             {
               $session_data = array('enroll_payment_status' => 0,'order_id'=>$order_id,'price'=>0);
                                              // 'price'=>$amount);
                      // Add user data in session
                      $this->session->set_userdata($session_data);
                    
                
             }
            
            
             $purl=base_url()."enroll-now/?test_key=".$key;
              echo "<script>window.location='".$purl."'</script>";
         
             

}








function signup_withpay()
{

$name="";
$email="";
$dob="";
$uid="";
$pass="";
$test_key="";




if(isset($_POST['test_type']))
{
		$name=$_POST['name'];
		$email=$_POST['email'];
		$dob=$_POST['dob'];
		$uid=$_POST['uid'];
		$pass=$_POST['pass'];
		$test_key=$_POST['test_type'];


		$session_data = array();
		$session_data['name']=$name;
		$session_data['email']=$email;
		$session_data['dob']=$dob;
		$session_data['uid']=$uid;
		$session_data['pass']=$pass;
		$session_data['test_type']=$test_key;
		
		
			$this->session->set_userdata($session_data);

}
else if (isset($this->session->userdata['test_type']))
{
$name=$this->session->userdata['name'];
$email=$this->session->userdata['email'];
$dob=$this->session->userdata['dob'];
$uid=$this->session->userdata['uid'];
$pass=$this->session->userdata['pass'];
$test_key=$this->session->userdata['test_type'];

}

 $currDate = date("Y-m-d h:i");
 $session_id = md5(date("Y-m-d").$email);
	$test_details=$this->home_model->gettestdetails($test_key);
	$test_name=$test_details->test_name;
	$test_price=$test_details->test_enrollment_fee;

      $max_paymentid = $this->registration_model->getLastOrderNumber();
      if (strlen($max_paymentid->id) == 1)
        $start_char = '000'.strval($max_paymentid->id);
      else if(strlen($max_paymentid->id) == 2 )
        $start_char = '00'.strval($max_paymentid->id);
      else if(strlen($max_paymentid->id) == 3 )
        $start_char = '0'.strval($max_paymentid->id);
      else
        $start_char = strval($max_paymentid->id);
      
       $payment_number = date("ym").$start_char;
    $data=array(
                  	'pay_id'=>$payment_number,
                    'session_id'=>$session_id,
                    'user_name'=>$name,
                    'user_address'=>"N/A",
                    'user_mobile_no'=>"N/A",
                    'user_email'=>$email,
                    'paid_for'=>$test_name,
                    'paid_through'=>"SIGNUP-".$test_name,
                    'payable_amt'=>$test_price,
                    'payment_date'=>$currDate,
                    'payment_status'=>0,
                    
                );  
 $order_id = $this->registration_model->savepostpayment($data);


      $cc_data = array();
      $payment_gateway=$this->registration_model->getpayment_detail("CCAvenue");
      $cc_data['merchant_id'] = $payment_gateway->merchant_id;
      $cc_data['order_id'] = $payment_number;
      $cc_data['amount'] = $test_price;
      $cc_data['currency'] = $payment_gateway->currency;
      $cc_data['redirect_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/home/signup_paymentstatus';
      $cc_data['cancel_url'] = 'http://'.$_SERVER['SERVER_NAME'].'/home/signup_paymentstatus';
      $cc_data['language'] = 'EN';
      $cc_data['billing_name'] = $name;
      $cc_data['billing_email'] = $email;
      

   
      $working_key = $payment_gateway->working_key;
      $access_code = $payment_gateway->access_key;
        
      
      $merchant_data='';
    
      foreach ($cc_data as $key => $value){
        $merchant_data.=$key.'='.$value.'&';
      }

        $encrypted_data=encrypt($merchant_data,$working_key); // Method for encrypting the data.
   
        // $test_url=str_replace("##ENC_DATA##",$encrypted_data, $payment_gateway->test_payment_gateway);
        $test_url=str_replace("##ENC_DATA##",$encrypted_data, $payment_gateway->live_payment_gateway); //live payment 
        $test_url=str_replace("##ACCESS_CODE##",$access_code,$test_url);
        
      
    
      $res['url']=$test_url;                  
      echo json_encode($res);
}

function signup_paymentstatus()
{


 $payment_gateway=$this->registration_model->getpayment_detail("CCAvenue");
 
  $working_key = $payment_gateway->working_key;      
      

    $encResponse=$_POST["encResp"];     //This is the response sent by the CCAvenue Server
  $rcvdString=decrypt($encResponse,$working_key);   //Crypto Decryption used as per the specified working key.
  $order_status="";
  $decryptValues=explode('&', $rcvdString);
  $dataSize=sizeof($decryptValues);
  $ref_no='';
        $status='';
        $amount='';
        $order_id='';
        $currDate = date("Y-m-d H:i:s");
  for($i = 0; $i < $dataSize; $i++) 
  {
    $information=explode('=',$decryptValues[$i]);
              
    if($i==3) $order_status=$information[1];
                if($i==2)       $ref_no=$information[1];
                if($i==10)       $amount=$information[1];
                if($i==0)       $order_id=$information[1];
  }

  if($order_status==="Success")
  {
    $status=1;
    
  }
  else if($order_status==="Aborted")
  {
    $status=3;
  
  }
  else if($order_status==="Failure")
  {
    $status=2;
  }
  else
  {
    $status=2;
  
  }

  // print_r($decryptValues);
  // echo $status;
  // exit;      

  
    
    

            if(!isset($this->session->userdata['test_type']))
                        {
                            echo '<script>window.location = "'.base_url().'"</script>';
                        }
          
      					$name=$this->session->userdata['name'];
						$email=$this->session->userdata['email'];
						$dob=$this->session->userdata['dob'];
						$uid=$this->session->userdata['uid'];
						$pass=$this->session->userdata['pass'];
						$test_key=$this->session->userdata['test_type'];



                          $this->registration_model->updatepaymentdetails($order_id,$status,$encResponse);
                         

             if($status==1)
             {
                   
       
		
		$data_insert = array();
		$data_insert['user_name']=$name;
		$data_insert['user_email']=$email;
		$data_insert['user_dob']=$dob;
		$data_insert['user_id']=$uid;
		$data_insert['user_passkey']=md5($pass);
		$data_insert['user_selected_test']=$test_key;
		$test_details=$this->home_model->gettestdetails($test_key);
		$test_name=$test_details->test_name;
	
	
			$content="Hi Team,<br><br> A new Signup has been done, Please find the candidate's details below.<br><table border='1'><tr><th>Candidate Name</th><th>Email</th><th>Date Of Birth</th><th>User Id</th><th>Test Key</th><th>TEST Name</th><th>Amount Paid </th></tr><tr><td>".$data_insert['user_name']."</td><td>".$data_insert['user_email']."</td><td>".$data_insert['user_dob']."</td><td>".$data_insert['user_id']."</td><td>".$data_insert['user_selected_test']."</td><td>".$test_name."</td><td>".$amount."</td></tr></table><br> Cheers<br><br> Team SSB GUIDE";
		
		

		$id=$this->home_model->insert_signup($data_insert);


		$data_notification = array();
		$data_notification['notification_from']="Admin";
		$data_notification['notification_to']=$id;
		$data_notification['notification_title']="Welcome To SSB GUIDE";
		$data_notification['notification_Content']="Hi ".$name.", <br> You have been Signed up Successfully And Enrolled For ".$test_name." Test Series. Please Complete Your Profile And Explore Our Recommendation Section for more Enrollments.<br> Cheers    ";
		$this->home_model->save_notification($data_notification);


		$session_data = array(
	   							'user_id' => $id,
                                'user_email'=>$email,
                                'user_name'=>$name
                            );
                      // Add user data in session
                      $this->session->set_userdata($session_data);


		$subject="New Signup #".$data_insert['user_name']." - ".date("d, M y h:iA");
		$res1=$this->sendmail('ndassbguide@gmail.com','SSB GUIDE',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content);
		// $res1=$this->sendmail('dhir.xcess@gmail.com','Developer',"noreply@ssbguide.com","SSB GUIDE INFO",$subject,$content); //for test purpose

		$sub="Signup & Enrollment Successful for ".$test_name." At SSB GUIDE";
		$con="Hi ".$data_insert['user_name'].",<br><br> You have been successfully Signup & Enrolled For ".$test_name.". <br> Please Call <b>7015173285</b> Or Whatsapp On <b>8572857321</b> For Any help. <br> Cheers <br><br> Team SSB GUIDE";

		$res2=$this->sendmail($data_insert['user_email'],$data_insert['user_name'],"noreply@ssbguide.com","SSB GUIDE Team",$sub,$con);
               
                       $session_data = array('signup_payment_status' => 1,
                                              'order_id'=>$order_id,
                                               'price'=>$amount);
                      // Add user data in session
                      $this->session->set_userdata($session_data);



                             $session_data = array(
                                                  'name',
                                                  'email',
                                                  'dob',
                                                  'uid',
                                                 ' pass',
                                                  'test_type',
                                                 

                                                    
                                                    );
                      $this->session->unset_userdata($session_data);
                    
                      
                      
             }
             else
             {
               $session_data = array('signup_payment_status' => 0,'order_id'=>$order_id,'price'=>0);
                                              // 'price'=>$amount);
                      // Add user data in session
                      $this->session->set_userdata($session_data);
                    
                
             }
            
            
             $purl=base_url()."login";
              echo "<script>window.location='".$purl."'</script>";
         
             

}

function unset_signuppay()
{
	  $session_data = array('signup_payment_status' ,'order_id','price');

                      $this->session->unset_userdata($session_data);
                      $res['status']="success";
                      echo json_encode($res);
}
function unset_enrollpay()
{
	  $session_data = array('enroll_payment_status' ,'order_id','price');

                      $this->session->unset_userdata($session_data);
                      $res['status']="success";
                      echo json_encode($res);
}

	function sendmail($to,$toname,$from,$fromname,$subject,$content)
	{
			$mail = new PHPMailer;

			                              

			$mail->From = $from;
			$mail->FromName = $fromname;

			$mail->addAddress($to, $toname);

			$mail->isHTML(true);

			$mail->Subject = $subject;
			$mail->Body = $content;
			

			if(!$mail->send()) 
			{
			    $msg= "Enquiry Error: " . $mail->ErrorInfo;
			} 
			else 
			{
			    $msg ="Enquiry has been sent successfully";
			}

			return $msg;
	}

}