<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">TEST SETS/Questions- View/Edit </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title"> Question Details</h3>
            </div>
            <div class="card-body">
               <?php if($viewtype=="OBJECTIVE") { ?>
                 <div class="col-6">
              <input type="hidden" name="ques_id" id="ques_id" value="<?=$ques_id?>">
              <input type="hidden" name="ques_type" id="ques_type" value="<?=$viewtype?>">
              
                  <div class="form-group">
                    <label for="ques">Question<sup>*</sup></label>
                    <textarea class="form-control" row=10 id="ques" placeholder="Question" ><?=$question_content?></textarea> 
                  </div>
                  <div class="form-group">
                    <label for="ques_opt">Question Options <sup>*</sup></label>
                    <small><p>Note: QUESTION Options Must be sperated by "##" e.g: option1##option2##option3 etc </p></small>
                    <textarea class="form-control" row=10 id="ques_opt" placeholder="Question Options " value=""><?=$question_options?></textarea> 
                  </div>
                    <div class="form-group">
                    <label for="ques_c_opt">Question Correct Answer<sup>*</sup></label>
                    <input type="text" class="form-control" id="ques_c_opt" placeholder="Question Correct Answer" value="<?=$question_correct_option?>">
                  </div>
                   <div class="form-group">
                    <label for="ques_status">Question Status  <sup>*</sup></label>
                     <small><p>Note: ACTIVE For Activting Question And IN-ACTIVE for Deactivting Question</p></small>
                    <select class="form-control" id="ques_status">
                      <option value="" <?php if($question_status=="") {echo "Selected"; }?>> Select Question Status</option>
                      <option value="1" <?php if($question_status=="1") {echo "Selected"; }?>>ACTIVE</option>
                      <option value="0" <?php if($question_status=="0") {echo "Selected"; }?>>IN-ACTIVE</option>
                    </select>
                  </div>
                 
                <div  id="error_msg" style="color:#ff0000;display:none">
               
              </div>  
            </div>




               <?php } else { ?>


                   <div class="col-6">
              <input type="hidden" name="ques_id" id="ques_id" value="<?=$ques_id?>">
              <input type="hidden" name="ques_type" id="ques_type" value="<?=$viewtype?>">
              
                  <div class="form-group">
                    <label for="ques">Question <sup>*</sup></label>
                    <img src="<?=$question_content?>" width="500" height="500" id="ques">
                  </div>

                    <div class="form-group">
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" accept=".png, .jpg, .jpeg"  name="pic_upload" id="pic_upload" onchange="previewFile(this)">
                        <label class="custom-file-label" for="pic_upload">Choose file</label>
                      </div>
                    </div>
                  </div>
                   <div class="form-group">
                    <label for="ques_status">Question Status  <sup>*</sup></label>
                     <small><p>Note: ACTIVE For Activting Question And IN-ACTIVE for Deactivting Question</p></small>
                    <select class="form-control" id="ques_status">
                       <option value="" <?php if($question_status=="") {echo "Selected"; }?>> Select Question Status</option>
                      <option value="1" <?php if($question_status=="1") {echo "Selected"; }?>>ACTIVE</option>
                      <option value="0" <?php if($question_status=="0") {echo "Selected"; }?>>IN-ACTIVE</option>
                    </select>
                  </div>
                 
                <div  id="error_msg" style="color:#ff0000;display:none">
               
              </div>  
            </div>



               <?php } ?>
               </div>
               <?php if($viewtype=="OBJECTIVE") { ?>
                 <div class="card-footer">
              <button type="button" class="btn btn-primary"  id="btn_update" onclick="update_ques_obj()">Update </button>
                  <button type="button" class="btn btn-primary"  id="btn_update" onclick="delete_ques_obj()">Delete </button>
                  
                </div>
               <?php } else { ?>
                 <div class="card-footer">
              <button type="button" class="btn btn-primary"  id="btn_update" onclick="update_ques_app()">Update </button>
                  <button type="button" class="btn btn-primary"  id="btn_update" onclick="delete_ques_app()">Delete </button>
                  
                </div>
               <?php } ?>
               
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <?php if($viewtype=="OBJECTIVE") { ?>
    <script type="text/javascript">
        function delete_ques_obj()
            {
              var ques_id=$("#ques_id").val();
               var url="<?=base_url()?>admin_dashboard/delete_ques";
                             $.ajax({
                                    
                                     type: 'POST',   
                                     url: url,
                                        data:{cid:cid},
                                     dataType: 'json',
                                       
                                          success: function(data) 
                                              {  
                                               
                                                  if(data['status']=="success")
                                                  {
                                                    window.location=data['url'];
                                                  }
                                              }
                                            });
            }



  function update_ques_obj()
  {
    var ques=$("#ques").val();
    var ques_id=$("#ques_id").val();
    var ques_type=$("#ques_type").val();
    var ques_opt=$("#ques_opt").val();
    var ques_c_opt=$("#ques_c_opt").val();
    var ques_status=$("#ques_status").val();
   


    if(ques=="" || ques_opt=="" || ques_c_opt=="" || ques_status=="" )
    {
      $("#error_msg").html("Please  Fill The  '*' Required Fields ");
      $("#error_msg").show(0).delay(3000).hide(0);
      return false;
    }

       var url="<?=base_url()?>admin_dashboard/update_ques";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{ques_id:ques_id,ques:ques,ques_opt:ques_opt,ques_c_opt:ques_c_opt,ques_status:ques_status,ques_type:ques_type},
                         dataType: 'json',
                            beforSend:function()
                            {
                              $("#btn_update").html("Updating..");
                              $("#btn_update").removeAttr("onclick");
                            },
                              success: function(data) 
                                  {  
                                    $("#btn_update").html("Update");
                                    $("#btn_update").attr("onclick","update_ques_app()");
                                      if(data['status']=="success")
                                      {
                                        window.location.reload();
                                      }
                                  }
                                });
                            

  }


    </script>
    <?php } else { ?>
    <script type="text/javascript">
      
         function previewFile(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
       
      // $("#has_changes").val(1);
      
           $("#ques").attr("src",e.target.result);
          
           
      };
      reader.readAsDataURL(input.files[0]);
    }
  }


    function delete_ques_app()
{
  var ques_id=$("#ques_id").val();
   var url="<?=base_url()?>admin_dashboard/delete_ques";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{cid:cid},
                         dataType: 'json',
                           
                              success: function(data) 
                                  {  
                                   
                                      if(data['status']=="success")
                                      {
                                        window.location=data['url'];
                                      }
                                  }
                                });
}



  function update_ques_app()
  {
    var ques=$("#ques").attr('src');
    var ques_id=$("#ques_id").val();
    var ques_type=$("#ques_type").val();
    var ques_status=$("#ques_status").val();
   


    if(ques=="" ||  ques_status=="" )
    {
      $("#error_msg").html("Please  Fill The  '*' Required Fields ");
      $("#error_msg").show(0).delay(3000).hide(0);
      return false;
    }

       var url="<?=base_url()?>admin_dashboard/update_ques";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{ques_id:ques_id,ques:ques,ques_status:ques_status,ques_type:ques_type},
                         dataType: 'json',
                            beforSend:function()
                            {
                              $("#btn_update").html("Updating..");
                              $("#btn_update").removeAttr("onclick");
                            },
                              success: function(data) 
                                  {  
                                    $("#btn_update").html("Update");
                                    $("#btn_update").attr("onclick","update_ques_app()");
                                      if(data['status']=="success")
                                      {
                                        window.location.reload();
                                      }
                                  }
                                });
                            

  }



    </script>
    <?php } ?>