<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SSB GUIDE | Login</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
   <link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
  <link rel="apple-touch-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
</head>
<body class="hold-transition lockscreen">
<!-- Automatic element centering -->
<div class="lockscreen-wrapper">
  <div class="lockscreen-logo">
    <a href="<?=base_url()?>"><b>SSB</b>Guide</a>
  </div>
  <!-- User name -->
  <div class="lockscreen-name">Super Admin</div>
  <input type="hidden" id="uid" value="SuperAdmin">

  <!-- START LOCK SCREEN ITEM -->
  <div class="lockscreen-item">
    <!-- lockscreen image -->
    <div class="lockscreen-image">
      <img src="<?=base_url()?>assets/admin/assets/img/smile.png" alt="User Image">
    </div>
    <!-- /.lockscreen-image -->

    <!-- lockscreen credentials (contains the form) -->
    <div class="lockscreen-credentials">
      <div class="input-group">
        <input type="password" class="form-control" id="pass" placeholder="password">

        <div class="input-group-append">
          <button type="button" onclick="login()" class="btn"><i class="fa fa-arrow-right text-muted"></i></button>
        </div>
      </div>
    </div>
    <!-- /.lockscreen credentials -->

  </div>
  <!-- /.lockscreen-item -->
  <div class="help-block text-center">
    Enter your password to Login into Admin Section
  </div>
  <div class="text-center" id="error_msg" style="color:#ff0000;display:none">
    
  </div>
  <div class="lockscreen-footer text-center">
    Copyright &copy; 2018 <b><a href="http://www.ssbguide.com" class="text-black">SSB Guide</a></b><br>
    All rights reserved
  </div>
</div>
<!-- /.center -->

<!-- jQuery -->
<script src="assets/admin/assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="assets/admin/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>

<script type="text/javascript">
  
  function login()
  {
    var uid=$("#uid").val();
    var pass=$("#pass").val();
    if(pass=="")
    {
      $("#error_msg").html("Please Enter Your Password");
      $("#error_msg").show(0).delay(3000).hide(0);
     
      $("#pass").focus();
      return false;
    }

    var url="<?=base_url()?>admin_dashboard/signin";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                        data:{uid:uid,pass:pass},
                         dataType: 'json',
                         
                              success: function(data) 
                                  {        
                                    if(data['status']=="success")
                                    {
                                      window.location=data['url'];
                                    }
                                    else
                                    {
                                      $("#error_msg").html("Opps! Invalid Password");
                                      $("#error_msg").show(0).delay(3000).hide(0);
                                     
                                      $("#pass").focus();
                                      return false;
                                    }
                                  }
                                });
  }
</script>



</body>
</html>
