<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?=$desc?>">
    <meta name="author" content="Deviloper" >
    <meta name="keyword" content="<?=$desc?>">
    <title><?=$title?></title>

    <!-- Bootstrap core CSS -->
    <link href="<?=base_url()?>assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="<?=base_url()?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style-responsive.css" rel="stylesheet">
<link rel="stylesheet" href="<?=base_url()?>assets/css/theme.css" type="text/css"> </head>
   <link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
  <link rel="apple-touch-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
      .backred{
  background: #da4453;
  color:#fff;
  padding: 5px;
}

    </style>
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
           
            <!--logo start-->
            <a href="javascript:void(0)" class="logo" ><b>SSB GUIDE</b></a>

            <!--logo end-->
     

            <div class="top-menu">
                        
            	<ul class="nav pull-right top-menu">
                    
                    <li><a class="logout" data-toggle="modal" href="#myModal" id="btn_sub">Submit Test</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->

      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->

    <?php if($test_type=="OBJECTIVE") { ?> 
        <!--main content start-->
      <section id="test_sec">
          <section class="wrapper" >
          
          	<div class="row">
              <div class="col-lg-12">
                     <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-12">
              <h1 class="d-flex flex-row justify-content-center">Time: &nbsp;<b style="color:#da4453" id="timer"></b> </h1>
              <div class="row">
                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-12">
                      <input type="hidden" name="tlimit" value="<?=$tlimit?>" id="tlimit">
                      <input type="hidden" name="qlimit" value="<?=$qlimit?>" id="qlimit">
                      <input type="hidden" name="set" value="<?=$set?>" id="set">
                      <input type="hidden" name="tkey" value="<?=$tkey?>" id="tkey">
                      <input type="hidden" name="start" value="0" id="start">
                      <input type="hidden" name="end" value="1" id="end">
                       <input type="hidden" name="ques_id"  id="ques_id">
                       <input type="hidden" name="user_test_id"  id="user_test_id" value="<?=$user_test_id?>">
                      <input type="hidden" name="answer"  id="answer">
                      <input type="hidden" name="start_time"  id="start_time">
                        
                      <p class="lead d-flex flex-row justify-content-center"><b ><?=$test_type_name?></b></p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <p class="lead">Question (<span id="ques_count">1</span>/<?=$qlimit?>)</p>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <h3 contenteditable="true" class="d-flex flex-row justify-content-center">
                    <b id="question_content"></b>
                  </h3>
                  <div class="alert alert-danger" id="error_si" style="display:none;"> </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-12">
                      <ul class="list-group" id="question_options">
                      
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5">
    <div class="container">
      <div class="row">
        <!-- <div class="col-md-2">
          <a class="btn btn-primary btn-lg btn-block disabled" href="#">Next </a>
        </div> -->
        <div class="col-md-10"> </div>
        <div class="col-md-2">
          <a class="btn btn-primary btn-lg btn-block active" id="btn_next" onclick="chk_n_fetch()" href="#">Next </a>
        </div>
      </div>
    </div>
  </div>
  <div class="form-login" >
			 <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
                  <div class="modal-dialog">
                      <div class="modal-content" style="position:absolute ">
                          <div class="modal-header" style="background-color: #ffd777;display:block">
                              <center>
                              <h3 class="modal-title">Do You Want to Submit?</h3>
                           </center>
                          </div>
                          <div class="modal-body">
                            <center>
                               <button data-dismiss="modal" class="btn btn-theme04" style="font-size:1.5rem" type="button">No</button>
                              <button class="btn btn-theme05" data-dismiss="modal" onclick="submittest()" style="font-size:1.5rem" type="button">Yes</button>
                            </center>
                          </div>
                          
                      </div>
                  </div>
              </div>
            </div>
          </div>
        </div>
		</section>
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
   <?php } else if($test_type=="APPERCEPTION") { ?> 

 <section id="test_sec">
          <section class="wrapper" id="mysec">
          
            <div class="row">
              <div class="col-lg-12">
                     <div class="py-5">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <div class="row">
            <div class="col-md-12">
              <h1 class="d-flex flex-row justify-content-center">Time: &nbsp;<b style="color:#da4453" id="timer"></b> </h1>
              <div class="row">
                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-12">
                      <input type="hidden" name="tlimit" value="<?=$tlimit?>" id="tlimit">
                      <input type="hidden" name="qlimit" value="<?=$qlimit?>" id="qlimit">
                      <input type="hidden" name="set" value="<?=$set?>" id="set">
                      <input type="hidden" name="tkey" value="<?=$tkey?>" id="tkey">
                      <input type="hidden" name="start" value="0" id="start">
                      <input type="hidden" name="end" value="1" id="end">
                       <input type="hidden" name="ques_id"  id="ques_id">
                       <input type="hidden" name="user_test_id"  id="user_test_id" value="<?=$user_test_id?>">
                      <input type="hidden" name="answer"  id="answer">
                      <input type="hidden" name="start_time"  id="start_time">
                        
                      <p class="lead d-flex flex-row justify-content-center"><b ><?=$test_type_name?></b></p>
                    </div>
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12">
                  <p class="lead">Question (<span id="ques_count">1</span>/<?=$qlimit?>)</p>
                </div>
              </div>
              <div class="row" id="ques_box" >

                <div class="col-md-12">
                  <h3 contenteditable="true" class="d-flex flex-row justify-content-center">
                    <center ><p class="d-flex flex-row justify-content-center">After : &nbsp;<b style="color:#da4453" id="qtimer"></b>&nbsp; Question Will disappear. </p><img id="question_content" src="" style="width:80%;height:80%" ></center>
                  </h3>
                  
                </div>
              </div>
              <div class="row" id="answer_box" style="display: none;">
                <div class="col-md-12">
                  <div class="row">
                    <div class="col-md-12">
                      <ul class="list-group" >
                        <li><div class="alert alert-danger" id="error_si" style="display:none;"> </div></li>
                       <li class="list-group-item d-flex justify-content-between align-items-center">
                        
                        <textarea class="form-control"  rows="15" id="textanswer" style="font-size: 12pt"  placeholder="Your answer" required="required"></textarea>
                      </li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>


            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="py-5" id="next_btn" style="display:none">
    <div class="container">
      <div class="row">
        <!-- <div class="col-md-2">
          <a class="btn btn-primary btn-lg btn-block disabled" href="#">Next </a>
        </div> -->
        <div class="col-md-10"> </div>
        <div class="col-md-2">
          <a class="btn btn-primary btn-lg btn-block active" id="btn_next" onclick="chk_n_fetch()" href="#">Next </a>
        </div>
      </div>
    </div>
  </div>
  <div class="form-login" >
       <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
                  <div class="modal-dialog">
                      <div class="modal-content" style="position:absolute ">
                          <div class="modal-header" style="background-color: #ffd777;display:block">
                              <center>
                              <h3 class="modal-title">Do You Want to Submit?</h3>
                           </center>
                          </div>
                          <div class="modal-body">
                            <center>
                               <button data-dismiss="modal" class="btn btn-theme04" style="font-size:1.5rem" type="button">No</button>
                              <button class="btn btn-theme05" onclick="submittest()" data-dismiss="modal" style="font-size:1.5rem" type="button">Yes</button>
                            </center>
                          </div>
                          
                      </div>
                  </div>
              </div>
            </div>
            </div>
        </div>
    </section>
      </section><!-- /MAIN CONTENT -->










   <?php } ?>
   <section  id="thank_you" style="display:none;">
          <section class="wrapper">
          
            <div class="row">
              <div class="col-lg-12">
  <div class="container">
                            <div class="container" >
            <div class="form-login ">
                         <h2 class="form-login-heading">Thank You</h2>
                          <div class="login-wrap">
                        <center>
                     <h6 style="color:#2ecc71;"> Your Test has Been Submitted Successful</h6> 
                   <h6 >Please Go to Your <a href="<?=base_url()?>dashboard">Dashboard</a> To See Your Result.</h6>   
                     
                    </center>
                    </div>
                    </div>
                    </div>
                    </div>
                  </div>
                </div>
              </section>
            </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?=base_url()?>assets/js/jquery.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="<?=base_url()?>assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.scrollTo.min.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="<?=base_url()?>assets/js/common-scripts.js"></script>
    <?php if($test_type=="OBJECTIVE") { ?> 
    <!--script for this page-->
<script type="text/javascript">

  var startlimit =$("#start").val();
  var endlimit =$("#end").val();
  var qlimit=$("#qlimit").val();
  var setid=$("#set").val();
  var remainques=qlimit;
    $(document).ready(function(){








    $("body").on("contextmenu",function(e){
        return false;
    });
    $(document).on("keydown", keydown);
    $(document).on("keyup", keyup);
     var timeout = $("#tlimit").val()*60;
    display = document.querySelector('#timer');
    startTimer(timeout, display);
    getquestion();

});






// refresh block
    var ctrlKeyDown = false;

function keydown(e) { 

    if ((e.which || e.keyCode) == 116 || ((e.which || e.keyCode) == 82 && ctrlKeyDown)) {
        // Pressing F5 or Ctrl+R
        e.preventDefault();
    } else if ((e.which || e.keyCode) == 17) {
        // Pressing  only Ctrl
        ctrlKeyDown = true;
    }
};

function keyup(e){
    // Key up Ctrl
    if ((e.which || e.keyCode) == 17) 
        ctrlKeyDown = false;
};


// refresh block


function chk_n_fetch()
{
  var is_checked=$('input:radio[name="optionsRadios"]').is(":checked");
  
  if(!is_checked)
  {
    $("#error_si").html("Skipping Question...");
    $("#error_si").show(0).delay(3000).hide(0);
    $("#answer").val("");
  }
  else
  {
    var radiovalue= document.querySelector('input[name="optionsRadios"]:checked').value;
    $("#answer").val(radiovalue);
  }
  getquestion();
}

function getquestion()
{
  var is_first;
  var ques_id=$("#ques_id").val();
  var answer=$("#answer").val();
  if(startlimit==0)
  {
    is_first=1;
  }
  else
  {
    is_first=0;

  }
   var url="<?=base_url()?>home/getquestion";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{is_first:is_first,setid:setid,ques_id:ques_id,answer:answer,start:startlimit,end:endlimit,qlimit:qlimit},
                         dataType: 'json',
                              beforeSend: function()
                              {
                                $("#btn_next").html("Please Wait...");
                              },
                              success: function(data) 
                                  {        
                                    $("#btn_next").html("Next");
                                    if(data['status']=="OK")
                                    {
                                      $("#question_content").empty();
                                    $("#question_content").html(data['content']);

                                    $("#question_options").empty();
                                    $("#question_options").html(data['options']);
                                     $("#ques_id").val(data['id']);
                                    $("#answer").val("");
                                    
                                    startlimit=parseInt(startlimit)+1;
                                    $("#ques_count").html(startlimit);
                                    remainques=remainques-1;
                                    if(remainques<0)
                                    {
                                      $("#btn_next").removeAttr("onclick");
                                      $("#btn_next").attr("onclick","submittest()");
                                      $("#btn_next").html("Submit");
                                    }
                                    }
                                    else
                                    {
                                      $("#btn_next").removeAttr("onclick");
                                      $("#btn_next").attr("onclick","submittest()");
                                      $("#btn_next").html("Submit");
                                    }
                                    
                                  }
                                });


}
function submittest()
{
  var start_time=$("#start_time").val();
  var test_id=$("#user_test_id").val();
 var end_time=Date.now();
 var diff= ((end_time - start_time) / 1000)/60;

 var url="<?=base_url()?>home/submittest";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                         data:{time:diff,test_id:test_id},
                          dataType: 'json',
                            beforeSend: function()
                              {
                                $("#btn_next").html("Submitting...");
                                $("#btn_next").removeAttr("onclick");
                                      
                              },
                              success: function(data) 
                                  {
                                    $("#btn_next").attr("onclick","submittest()");
                                    $("#btn_next").html("Submit");
                                    $("#test_sec").hide();
                                    $("#btn_sub").hide();
                                    $("#thank_you").show();
                                    
                                  }
                                });
}

    function startTimer(duration, display) {
    var start = Date.now(),
        diff,
        minutes,
        hours,
        seconds;
        var finish=0;
        $("#start_time").val(start);
    function timer() {
        // get the number of seconds that have elapsed since 
        // startTimer() was called
        if(!finish)
        {
            diff = duration - (((Date.now() - start) / 1000) | 0);

        // does the same job as parseInt truncates the float
        hours = (diff / 3600) | 0;
        minutes = (diff % 3600 /60 ) | 0;
        seconds = (diff % 60) | 0;
         hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = hours + ":" + minutes + ":" + seconds; 

        if (diff <= 0) {
            // add one second so that the count down starts at the full duration
            // example 05:00 not 04:59
                finish=1;
               submittest();
        }  
        }
        
    };
    // we don't want to wait a full second before the timer starts
    timer();
    setInterval(timer, 1000);
}
</script>
  <?php } else if($test_type=="APPERCEPTION") { ?> 

<script type="text/javascript">
  

  var startlimit =$("#start").val();
  var endlimit =$("#end").val();
  var qlimit=$("#qlimit").val();
  var setid=$("#set").val();
  var remainques=qlimit;
    $(document).ready(function(){

    $("body").on("contextmenu",function(e){
        return false;
    });
    $(document).on("keydown", keydown);
    $(document).on("keyup", keyup);
     var timeout = $("#tlimit").val()*60;
    display = document.querySelector('#timer');
    startTimer(timeout, display);
    getquestion();

});






// refresh block
    var ctrlKeyDown = false;

function keydown(e) { 

    if ((e.which || e.keyCode) == 116 || ((e.which || e.keyCode) == 82 && ctrlKeyDown)) {
        // Pressing F5 or Ctrl+R
        e.preventDefault();
    } else if ((e.which || e.keyCode) == 17) {
        // Pressing  only Ctrl
        ctrlKeyDown = true;
    }
};

function keyup(e){
    // Key up Ctrl
    if ((e.which || e.keyCode) == 17) 
        ctrlKeyDown = false;
};


// refresh block


function chk_n_fetch()
{
  var answer_text=document.getElementById("textanswer").value;
  
  if(answer_text=="")
  {
    $("#error_si").html("Skipping Question...");
    $("#error_si").show(0).delay(3000).hide(0);
    $("#answer").val("");
  }
  else
  {
    
    $("#answer").val(answer_text);
  }
   getquestion();
}

function getquestion()
{
  var is_first;
  var ques_id=$("#ques_id").val();
  var answer=$("#answer").val();
  if(startlimit==0)
  {
    is_first=1;
  }
  else
  {
    is_first=0;

  }
   var url="<?=base_url()?>home/getssbquestion";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{is_first:is_first,setid:setid,ques_id:ques_id,answer:answer,start:startlimit,end:endlimit,qlimit:qlimit},
                         dataType: 'json',
                              beforeSend: function()
                              {
                                $("#btn_next").html("Please Wait...");
                              },
                              success: function(data) 
                                  {        
                                    $("#btn_next").html("Next");
                                    if(data['status']=="OK")
                                    {

                                        var timeout = 30;
                                        display = document.querySelector('#qtimer');
                                        startquesTimer(timeout, display);

                                      $("#question_content").empty();
                                    $("#question_content").attr("src",data['img']);

                                    // $("#question_options").empty();
                                    // $("#question_options").html(data['options']);
                                     $("#ques_id").val(data['id']);
                                    $("#answer").val("");
                                    $("#textanswer").val("");
                                    $("#answer_box").hide();
                                     $("#next_btn").hide();
                                     $("#ques_box").show();
                                    
                                    startlimit=parseInt(startlimit)+1;
                                    $("#ques_count").html(startlimit);
                                    remainques=remainques-1;
                                    if(remainques<0)
                                    {
                                      $("#btn_next").removeAttr("onclick");
                                      $("#btn_next").attr("onclick","submittest()");
                                      $("#btn_next").html("Submit");
                                    }
                                    }
                                    else
                                    {
                                      $("#btn_next").removeAttr("onclick");
                                      $("#btn_next").attr("onclick","submittest()");
                                      $("#btn_next").html("Submit");
                                    }
                                    
                                  }
                                });


}
function submittest()
{
  var start_time=$("#start_time").val();
  var test_id=$("#user_test_id").val();
 var end_time=Date.now();
 var diff= ((end_time - start_time) / 1000)/60;

 var url="<?=base_url()?>home/ssbsubmittest";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                         data:{time:diff,test_id:test_id},
                          dataType: 'json',
                            beforeSend: function()
                              {
                                $("#btn_next").html("Submitting...");
                                $("#btn_next").removeAttr("onclick");
                                      
                              },
                              success: function(data) 
                                  {
                                    $("#btn_next").attr("onclick","submittest()");
                                    $("#btn_next").html("Submit");
                                    $("#test_sec").hide();
                                    $("#btn_sub").hide();
                                    $("#thank_you").show();
                                    
                                  }
                                });
}

    function startTimer(duration, display) {
    var start = Date.now(),
        diff,
        minutes,
        hours,
        seconds;
        var finish=0;
        $("#start_time").val(start);
    function timer() {
        // get the number of seconds that have elapsed since 
        // startTimer() was called
        if(!finish)
        {
            diff = duration - (((Date.now() - start) / 1000) | 0);

        // does the same job as parseInt truncates the float
        hours = (diff / 3600) | 0;
        minutes = (diff % 3600 /60 ) | 0;
        seconds = (diff % 60) | 0;
         hours = hours < 10 ? "0" + hours : hours;
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = hours + ":" + minutes + ":" + seconds; 

        if (diff <= 0) {
            // add one second so that the count down starts at the full duration
            // example 05:00 not 04:59
                finish=1;
               submittest();
        }  
        }
        
    };
    // we don't want to wait a full second before the timer starts
    timer();
    setInterval(timer, 1000);
}





    function startquesTimer(duration, display) {
    var start = Date.now(),
        diff,
        minutes,
        hours,
        seconds;
        var finish=0;
        
    function qtimer() {
        // get the number of seconds that have elapsed since 
        // startTimer() was called
        if(!finish)
        {
            diff = duration - (((Date.now() - start) / 1000) | 0);

        // does the same job as parseInt truncates the float
      
        minutes = (diff % 3600 /60 ) | 0;
        seconds = (diff % 60) | 0;
         
        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.textContent = minutes + ":" + seconds; 

        if (diff <= 0) {
            // add one second so that the count down starts at the full duration
            // example 05:00 not 04:59
                finish=1;
               $("#answer_box").show();
               $("#next_btn").show();
               $("#ques_box").hide();
        }  
        }
        
    };
    // we don't want to wait a full second before the timer starts
    qtimer();
    setInterval(qtimer, 1000);
}
</script>

   <?php } ?>
  </body>
</html>
