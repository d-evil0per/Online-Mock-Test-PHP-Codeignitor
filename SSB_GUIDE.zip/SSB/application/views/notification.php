 <section id="main-content">
          <section class="wrapper site-min-height">
          
<style type="text/css">
  .alert-white { border-color: #d9d9d9;background: #fff;color: #a9a9a9; }
.alert-info-alt { border-color: #B4E1E4;background: #81c7e1;color: #fff; }
.alert-danger-alt { border-color: #B63E5A;background: #E26868;color: #fff; }
.alert-warning-alt { border-color: #F3F3EB;background: #E9CEAC;color: #fff; }
.alert-success-alt { border-color: #19B99A;background: #20A286;color: #fff; }
.glyphicon { margin-right:10px; }
.alert a {color: gold;}

</style>



<div class="container">
    <div class="row">
       <h3>Notifications</h3>
        

          <?php if($notifications->num_rows()>0) { ?>
          <?php foreach ($notifications->result() as $nval) { ?>
          <div class="col-md-3">
            <div class="alert alert-white alert-dismissable">
              
                 
                 <center>
                  <span class="small mt"><?=date("d M Y h:iA",strtotime($nval->notification_timestamp))?></span><br>
                  <span class="color-red"><strong><?=$nval->notification_from?></strong></span><br> 
                   <span ><?=$nval->notification_title?>,<?=$nval->notification_content?></span>
                 </center> 
                 
                 </div>
                </div>
               <?php } ?>
              <?php } else { ?>
              <div class="col-md-3">
              <div class="alert alert-white alert-dismissable">
              <div class="row">
               <div class="col-md-12">
                 <span >No new Notifications</span>
                 </div>
                 
                </div>
              
              </div>
               </div>
              <?php } ?>
          

       
    </div>
</div>

  
      
    </section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->