
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">USER SSB ANSWER SUBMIT DETAILS </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title">SSB ANSWERS </h3>
              

            </div>
            <div class="card-body">
             <div class="row">

             	<div class="col-12">
             		
             		<div class="row">
             			<div class="col-8">
             			<!-- 	<div class="form-group">
                    <label for="ques_status">Question Number  <sup>*</sup></label>
                     <small><p>Note: ACTIVE For Activting Question And IN-ACTIVE for Deactivting Question</p></small>
                    <select class="form-control" id="ques_status">
                       <option value="" > Select Question Status</option>
                      <option value="1" >ACTIVE</option>
                      <option value="0" >IN-ACTIVE</option>
                    </select>
                  </div>
                  	<div class="form-group">
                    <label for="u_score">Your Remarks <sup>*</sup></label>
                    <input type="number" class="form-control" min="0" id="u_score" placeholder="ADD Score Here" >
                  </div>
                  <div class="form-group">
                    <button type="button" class="btn btn-primary"  id="btn_update" >Update Remarks </button>
						
             			
                  </div> -->
                  <?php if($test_status==0)
                  { ?>
                  		<div class="form-group">
             					<input type="hidden" id="tid" value="<?=$test_id?>">
                    <label for="u_score">Declare Total Score (in Percentage) <sup>*</sup></label>
                    <input type="number" class="form-control" min="0" id="u_score" placeholder="ADD Score Here" >
                  </div>
                  	<div class="form-group">
                    <button type="button" class="btn btn-primary"  id="btn_update" onclick="update()" >Update Score </button>
						
             			
                  </div>

                 <?php } ?>
             			
                  <label for="u_score">Download answer as pdf<sup>*</sup></label>
             			<button type="button" class="btn btn-success"  id="btn_download" ><i class="fa fa-download"></i></button>
             			
             		
             			</div>
             			
             		
             		</div>
             		<div class="row">
             			<div class="col-12" id="content">
             				<center style="border-bottom: 1px solid #d9d9d9;margin-bottom: 10px">
             					<h4><?=$user_name?></h4>
             					<h5><?=$test_name?></h5>
             					<h6>Test ID : <?=$test_id?></h6>
             					<p><?=date("d M y h:iA",strtotime($test_time))?></p>

             				</center>


             			<?php foreach ($ssb_answers_det->result() as $ssa) { ?> 
             			
             			<div  style="border-bottom: 1px solid #d9d9d9;margin-bottom: 10px;padding:10px;display: flex;flex-wrap: wrap;margin-right: -7.5px;margin-left: -7.5px;">
             					
             			<div  style="border-right: 1px solid #d9d9d9;flex: 0 0 40%;max-width: 40%;position: relative;width: 100%;min-height: 1px;padding-right: 7.5px;padding-left: 7.5px;" ><img src="<?=$ssa->question_content?>" width="200" height="200"></div>
             			<div style="flex: 0 0 50%;max-width: 50%;position: relative;width: 100%;min-height: 1px;padding-right: 7.5px;padding-left: 7.5px;">
             				
             				<?php if($ssa->user_answer==""){ echo "Not Answered"; }else { echo $ssa->user_answer; } ?>
             			</div>
             		
             		</div>
             			
             		<?php } ?>
             		
             		</div>
             	</div>
             	</div>
             </div> 
             
            </div>
             <div class="card-footer">
              
                
                  
                </div>
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>



    <!-- /.content -->
     </div>











<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="http://cdnjs.cloudflare.com/ajax/libs/jspdf/0.9.0rc1/jspdf.min.js"></script>
<script type="text/javascript" src="<?=base_url()?>assets/js/html2canvas.js"></script>
<script type="text/javascript">
// var doc = new jsPDF();
// var specialElementHandlers = {
// '#editor': function (element, renderer) {
// return true;
// }
// };

$(document).ready(function() {
$('#btn_download').click(function () {
var divContents = $("#content").html();
            var printWindow = window.open('', '', 'height=400,width=800');
            printWindow.document.write('<html><head><title>DIV Contents</title>');
            printWindow.document.write('</head><body >');
            printWindow.document.write(divContents);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
            printWindow.print();

	
// doc.fromHTML($('#content').html(), 15, 15, {
// 'width': 170,
// 'elementHandlers': specialElementHandlers
// });
// doc.save('sample-content.pdf');
});






});

function update() {

	var test_id=$("#tid").val();
	var score=$("#u_score").val();
	if(score=="")
	{
		return false;
	}

	var url ="<?=base_url()?>admin_dashboard/update_score";
 $.ajax({
                                    
                                     type: 'POST',   
                                     url: url,
                                        data:{tid:test_id,score:score},
                                     dataType: 'json',
                                       
                                          success: function(data) 
                                              {  
                                               
                                                  if(data['status']=="success")
                                                  {
                                                    window.location.reload();
                                                  }
                                              }
                                            });


	}

</script>