
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">USER SSB ANSWER SUBMIT DETAILS </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title">SSB ANSWER SUBMISSIONS</h3>
            </div>
            <div class="card-body">
              <div class="col-12" style="overflow-x:auto">
                
              <table id="regist_data_table" class="table table-bordered table-striped" style="font-size: .7em;">
                <thead>
                <tr>
                      <th>ID</th>
                      <th>USER NAME</th>
                      <th>TEST NAME</th>
                      <th>RESULT STATUS</th>
                      <th>TIME TAKEN TO COMPLETE</th>
                      <th>TEST SCORE</th>
                      <th>TEST TIME</th>
                      <th>ACTION</th>
                      
                    </tr>
                </thead>
                <tbody>
                  
                    <?php foreach ($ssb_us_det->result() as $ltrac) { ?>
                    <tr>
                      <td><?=$ltrac->id?></td>
                      <td><?=$ltrac->user_name?></td>
                      <td><?=$ltrac->test_type_name?></td>
                       <?php if($ltrac->test_status==1) { ?>
                         <td><span class="badge badge-success">RESULT DECLARED</span></td>
                         
                         <?php } else { ?>
                         <td><span class="badge badge-warning">RESULT PENDING</span></td>
                         <?php } ?>
                      <td><?=round($ltrac->test_time_taken)?> Mins</td>
                      <td><?php if($ltrac->test_score=="") { echo "Not Available"; } else { echo $ltrac->test_score; } ?></td>
                     
                      
                      <td>
                        <?=date("d M y h:iA",strtotime($ltrac->test_timestamp))?>
                      </td>
                       <td><a href="<?=base_url()?>admin/ssb-answers/?uid=<?=$ltrac->user_id?>&test_id=<?=$ltrac->id?>"> VIEW </a></td>
                    </tr>
                    <?php } ?>
                    
                </tbody>
                <tfoot>
              <tr>
                     <th>ID</th>
                      <th>USER NAME</th>
                      <th>TEST NAME</th>
                      <th>TEST STATUS</th>
                      <th>TIME TAKEN TO COMPLETE</th>
                      <th>TEST SCORE</th>
                      <th>TEST TIME</th>
                      <th>ACTION</th>
                    </tr>
                </tfoot>
              </table>
              
            </div>
            </div>
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>



    <!-- /.content -->
     </div>
          <script>
  $(function () {
    
    $('#regist_data_table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
