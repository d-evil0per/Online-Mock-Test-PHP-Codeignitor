<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="Deviloper" >
    <meta name="keyword" content="SSB, NDA, CDS ,AFCAT, Online mocktest, online Exam ">

    <title>SSB GUIDE Login portal</title>

    <!-- Bootstrap core CSS -->
    <link href="<?=base_url()?>assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="<?=base_url()?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style-responsive.css" rel="stylesheet">
      <link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
  <link rel="apple-touch-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
    <style type="text/css">
    .overlay{
				background-color:rgba(0,0,0,0.7);
				z-index:-1;
				position:fixed;
				top:0;
				left:0;
				width:100%;
				height:100%;    
    }
    </style>
      <style type="text/css">

  .color-white{
    color:#fff;
  }
</style>

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>

  <body>

      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
  <header class="header" style="z-index:1039;position: absolute;margin:10px;">
             
            <!--logo start-->
            <p class="centered "><a href="javascript:void(0)"><img src="<?=base_url()?>assets/img/SSB_GUIDE.png" width="60"></a></p>
             <h5 class="centered" ><a  href="javascript:void(0)" class="logo01"><b>SSB Guide</b></a></h5>
            <!--logo end-->
            
           
        </header>
	<div class="overlay"> </div>
    <?php if(!isset($this->session->userdata['signup_payment_status'])) { ?>
	  <div id="login-page" style="z-index:1030">
	  	<div class="container" id="login">
	  	
		      <div class="form-login" >
		      
		         <h2 class="form-login-heading">sign in now</h2>

		        <div class="login-wrap">
                    <div class="alert alert-danger" id="error_si" style="display:none;"> </div>
		            <input type="text" class="form-control" placeholder="User ID" id="signin_userid" autofocus>
		            <br>
		            <input type="password" class="form-control" placeholder="Password" id="signin_pass">
		            <label class="checkbox">
		                <span class="pull-right">
		                    <a data-toggle="modal" href="#myModal"> Forgot Password?</a>
		
		                </span>
		            </label>
		            <button class="btn btn-theme05 btn-block" href="javascript:void(0)" onclick="signin()" type="button"><i class="fa fa-lock"></i> SIGN IN</button>
		            <hr>
		            
		            
		            <div class="registration">
		                Don't have an account yet?<br/>
		                <a class="" href="javascript:void(0)" onclick="toggle_loginform('login','signup')">
		                    Create an account
		                </a>
		                <h6> or </h6>
		                <a class="" href="<?=base_url()?>registration">
		                    Register For Offline Classes
		                </a>

		            </div>
		
		        </div>
			
		     
		        

					
		          <!-- Modal -->
		          <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
		              <div class="modal-dialog">
		                  <div class="modal-content">
		                      <div class="modal-header">
		                          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		                          <h4 class="modal-title">Forgot Password ?</h4>
		                      </div>
		                      <div class="modal-body">
		                          <p>Enter your e-mail address below to reset your password.</p>
		                          <input type="text" name="email" placeholder="Email" id="f_pass" autocomplete="off" class="form-control placeholder-no-fix">
		                      <div class="alert alert-danger" id="error_fp" style="display:none;"> </div>
		                      </div>
		                      <div class="modal-footer">
		                          <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
		                          <button class="btn btn-theme" onclick="forgetpass()" type="button">Submit</button>
		                      </div>
		                  </div>
		              </div>
		          </div>
		          <!-- modal -->
		
		      </div>	  	
	  	</div>
	  	</div>
	  	
	  	<div class="container" id="signup" style="display:none">
	  		
					  
					  
		         
		         	
		         		<div class="form-login" id="signup_form">
		         		 <h2 class="form-login-heading">Sign Up Now</h2>
		         		  <div class="login-wrap">
		         		  	<div class="alert alert-danger" id="error_pd" style="display:none;"> </div>
		        		<input type="text" class="form-control" placeholder="Name" id="signup_name" autofocus required="required">
						<br>
						 <input type="email" class="form-control" placeholder="Email" onblur="chkemail(this)" id="signup_email"  required="required" >
		            <br>
		             <input type="date" class="form-control" max="<?=date('Y-m-d')?>" placeholder="Date of Birth" id="signup_dob"  required="required" >
		            <br>
		            <input type="text" class="form-control" placeholder="User ID" id="signup_uid" onblur="chkuid(this)" required="required">
		            <br>
		            <input type="password" class="form-control" placeholder="Password" id="signup_pass"  required="required">
		            <br>
		         	<select class="form-control" placeholder="Test Type" id="signup_ttype" onchange="gettestdetails(this)" required="required">
			         <option value="">Select Your Test Type</option>	
			         <?php foreach ($test_series->result() as $test) { ?>
			         <option value="<?=$test->test_key?>"><?=$test->test_name?></option>	
			        
						<?php } ?>	
 						</select>
		            <br>
		            <span class="btn btn-theme05 btn-block"  onclick="switchtopay()"><i class="fa fa-arrow-right"></i> <b>Proceed</b></span>
		            <hr>
		            <div class="registration">
		                Already has an account?<br/>
		                <a href="javascript:void(0)" onclick="toggle_loginform('signup','login')">
		                   Sign In
		                </a>
		                  <h6> or </h6>
		                <a class="" href="<?=base_url()?>registration">
		                    Register For Offline Classes
		                </a>

		            </div>
		            
		           
		
		        </div>
		        </div>

		        <div class="form-login " id="signup_pay" style="display: none">
		         		 <h2 class="form-login-heading"><i class="fa fa-credit-card"></i> Pay To Sign Up</h2>
		         		  <div class="login-wrap">
		         		  	<center> 
		         		  	  <span><b>Enrollment Fee:</b></span>
					           <br>
					           <span>Pay <i class="fa fa-rupee"></i> <b id="test_enr_fee">1000</b> As an Enrollment Fee for <b id="test_name">NDA</b> Test Series</span>
		         		 		<h6> or </h6>
		         		 		 <span><label>
                          <input type="checkbox" name="checkbox_option" onclick="alter_signup_fun()" id="reg_but_pay_later" >
                          Signup and Enroll Later
                        </label></span>
		           		    </center>       
		            <a class="btn btn-theme05 btn-block" href="javascript:void(0)" id="btn_signup" onclick="signup('WITHPAY')"><i class="fa fa-check"></i> <b>Pay & Signup</b></a>
		           
		
		        </div>
		        </div>


		         
		         	
		        
		      
					</div>
	  	
	  	<?php } else { ?>

                    <?php if($this->session->userdata['signup_payment_status']) { ?>    
                    <div class="container" id="thank_you">
                            <div class="container" >
            <div class="form-login ">
                         <h2 class="form-login-heading">Thank You</h2>
                          <div class="login-wrap">
                        <center>
                     <h6 style="color:#2ecc71;"><i class="fa fa-check-circle"></i> Payment Successful</h6> 
                   <h6 >You have been Successfully Signed UP! </h6>   
                     
                    </center>
                    </div>
                    </div>
                    </div>
                    </div>

                    <?php } else { ?>
                        <div class="container">
                            <div class="container" >
            <div class="form-login ">
                         <h2 class="form-login-heading backcolor-red">Sorry</h2>
                          <div class="login-wrap">
                        <center>
                     <h6 style="color:#da4453;"><i class="fa fa-exclamation-triangle"></i> Payment Failed!</h6> 

                   <h6 >We did not receive the payment as the transaction wasn't successful. We request you retry. Please contact your bank in case your account was debited and you still see this message.</h6>  

                  
                    <a class="btn btn-theme05 btn-block" href="javascript:void(0)" id="reg_retry_btn" onclick="retrypayment()"><i class="fa fa-check"></i> <b>Retry Payment</b></a>
                    </center>
                    </div>
                    </div>
                    </div>
                    </div>


                    <?php } } ?>
	 

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?=base_url()?>assets/js/jquery.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>

    <!--BACKSTRETCH-->
    <!-- You can use an image of whatever size. This script will stretch to fit in any screen size.-->
    <script type="text/javascript" src="<?=base_url()?>assets/js/jquery.backstretch.min.js"></script>
     <?php if(isset($this->session->userdata['signup_payment_status'])) { ?> 
    <script type="text/javascript">
             setTimeout(function()
             {
               var url="<?=base_url()?>home/unset_signuppay";
               $.ajax({
                        type: 'POST',   
                        url: url,
                        dataType:"JSON",
                        success:function(data)
                        {
                            window.location.reload();
                        }
                     });

               },30000);

    </script>
    <?php } ?>

    <script>
        $.backstretch("<?=base_url()?>assets/img/SSB_BG.JPG", {speed: 500});
        function toggle_loginform(element,oelement)
        {
        	$("#"+element).hide(500);
        	$("#"+oelement).show(500);
        }

        function gettestdetails(element)
        {
        	var value=$(element).val();
        	if(value=="")
        	{
        		$("#error_pd").html("<b>Opps!</b> Please Select Your Test Type.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$(element).focus();
        				return false;
        	}

        	var url="<?=base_url()?>home/gettestdetails";
               $.ajax({
                        type: 'POST',   
                        url: url,
                        data:{value:value},
                        dataType:"JSON",
                        success:function(data)
                        {
                            if(data['status']=="success")
                            {
                            	$("#test_enr_fee").html(data['price']);
                            	$("#test_name").html(data['name']);
                            }
                        }
                     });



        }

           function chkemail(element)
        {
            var value=$(element).val();
            if(value=="")
            {
              
                        return false;
            }

            var url="<?=base_url()?>home/chkemail";
               $.ajax({
                        type: 'POST',   
                        url: url,
                        data:{value:value},
                        dataType:"JSON",
                        success:function(data)
                        {
                            if(data['status']=="failure")
                            {
                                $("#error_pd").html("<b>Opps!</b>This Email ID already exists.");
                                $("#error_pd").show(0).delay(3000).hide(0);
                                $("#signup_email").focus();
                                $("#signup_email").val("");
                                return false;
                            }
                        }
                     });
        }

        function chkuid(element)
        {
        	var value=$(element).val();
        	if(value=="")
        	{
        	
        				return false;
        	}

        	var url="<?=base_url()?>home/chkuid";
               $.ajax({
                        type: 'POST',   
                        url: url,
                        data:{value:value},
                        dataType:"JSON",
                        success:function(data)
                        {
                            if(data['status']=="failure")
                            {
                            	$("#error_pd").html("<b>Opps!</b>This User ID already exists.");
		        				$("#error_pd").show(0).delay(3000).hide(0);
		        				$("#signup_uid").focus();
		        				$("#signup_uid").val("");
		        				return false;
                            }
                        }
                     });
        }
        function alter_signup_fun()
        {
        	var check=document.getElementById('reg_but_pay_later').checked;
        	if(check)
        	{
        		$("#btn_signup").html('<i class="fa fa-check"></i> <b>Signup</b>');
        		$("#btn_signup").attr('onclick',"signup('WITHOUTPAY')");
        	}
        	else
        	{
        		$("#btn_signup").html('<i class="fa fa-check"></i> <b>Pay & Signup</b>');
        		$("#btn_signup").attr('onclick',"signup('WITHPAY')");
        	}
        }

         function switchtopay()
        {

        	var name=$("#signup_name").val();
        			if(name=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Name is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#signup_name").focus();
        				return false;
        			}
        			var email=$("#signup_email").val();
        				if(email=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Email ID is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#signup_email").focus();
        				return false;
        			}
        			var emailReg = /^[\w._-]+[+]?[\w._-]+@[\w.-]+\.[a-zA-Z]{2,6}$/;
        			if(!(emailReg.test(email)))
        			{
        				$("#error_pd").html("<b>Opps!</b> Your Valid Email ID is Required.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#signup_email").val("");
        				$("#signup_email").focus();
        				return false;
        			}
        			var dob=$("#signup_dob").val();
        				if(dob=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Please Enter Your Date Of Birth.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#signup_dob").focus();
        				return false;
        			}
        			
					     
						 var uid=$("#signup_uid").val();
        				if(uid=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Please Enter Your User ID.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#signup_uid").focus();
        				return false;
        			} 
        			var pass=$("#signup_pass").val();
        				if(pass=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Please Enter Your Password.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#signup_pass").focus();
        				return false;
        			}

        				var test_type=$("#signup_ttype").val();
        				if(test_type=="")
        			{
        				$("#error_pd").html("<b>Opps!</b> Please Select Your Test.");
        				$("#error_pd").show(0).delay(3000).hide(0);
        				$("#signup_ttype").focus();
        				return false;
        			}


        	$("#signup_form").fadeOut(500);
        	$("#signup_pay").fadeIn(1000);
        }

         function toggle_pay(element,other_element)
        {
        	$("#"+element).hide(500);
        	$("#"+other_element).show(500);
        }


        function signup(type)
        {
        	var name=$("#signup_name").val();
        	var email=$("#signup_email").val();
        	var dob=$("#signup_dob").val();
        	 var uid=$("#signup_uid").val();
        	 var pass=$("#signup_pass").val();
        	 var test_type=$("#signup_ttype").val();
			        if(type=="WITHPAY")
			        {
			        	 var url="<?=base_url()?>home/signup_withpay";
			        }
			        else
			        {
			        	 var url="<?=base_url()?>home/signup_withoutpay";
			        }

	               $.ajax({
	                        type: 'POST',   
	                        url: url,
	                        data:{name:name,email:email,dob:dob,uid:uid,pass:pass,test_type:test_type},
	                        dataType:"JSON",
	                        success:function(data)
	                        {
	                         window.location = data['url'];
	                        }
	                     });

        }

        function retrypayment()
            {
                var url="<?=base_url()?>home/signup_withpay";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                        
                         dataType: 'json',
                                beforeSend:function()
                                    {
                                         ajaxInProgress = true;
                                         $("#reg_retry_btn").html(" <i class='fa fa-check'> <b> Retrying...</b>");
                                         
                                          $("#reg_retry_btn").removeAttr("onclick");
                                    },
                              success: function(data) 
                                  {        
                                     ajaxInProgress = false;
                                    $("#reg_retry_btn").html(" <i class='fa fa-check'> <b>Retry Payment</b>");
                                    
                                  $("#reg_retry_btn").attr("onclick","retrypayment()");
                                                window.location = data['url'];
                                    }
                         });
            }



            function signin()
            {
                var userid=$("#signin_userid").val();
                var pass=$("#signin_pass").val();
                if(userid=="")
                {
                    $("#error_si").html("<b>Opps!</b> Please Enter Your User ID.");
                        $("#error_si").show(0).delay(3000).hide(0);
                        $("#signin_userid").focus();
                        return false;
                }
                if(pass=="")
                {
                     $("#error_si").html("<b>Opps!</b> Please Enter Your Password.");
                        $("#error_si").show(0).delay(3000).hide(0);
                        $("#signin_pass").focus();
                        return false;
                }

                   var url="<?=base_url()?>home/signin";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{userid:userid,pass:pass},
                         dataType: 'json',
                         
                              success: function(data) 
                                  {        
                                    if(data['status']=="success")
                                    {
                                                window.location.reload();
                                    }
                                    else
                                    {
                                        $("#error_si").html("<b>Opps!</b>User ID OR Password Is INCORRECT!!");
                                         $("#error_si").show(0).delay(3000).hide(0);
                                        $("#signin_userid").focus();
                                        $("#signin_userid").val("");
                                        $("#signin_pass").val("");

                                        
                                    }
                                    }
                         });



            }

            function forgetpass()
            {
                var email=$("#f_pass").val();
                if(email=="")
                {
                    $("#error_fp").html("<b>Opps!</b> Email ID Is INCORRECT!!");
                     $("#error_fp").show(0).delay(3000).hide(0);
                     $("#f_pass").focus();
                     return false;

                }

                var emailReg = /^[\w._-]+[+]?[\w._-]+@[\w.-]+\.[a-zA-Z]{2,6}$/;
                    if(!(emailReg.test(email)))
                    {
                        $("#error_fp").html("<b>Opps!</b> Your Valid Email ID is Required.");
                        $("#error_fp").show(0).delay(3000).hide(0);
                        $("#f_pass").val("");
                        $("#f_pass").focus();
                        return false;
                    }

                    var url="<?=base_url()?>home/forgetpass";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{email:email},
                         dataType: 'json',
                         
                              success: function(data) 
                                  {        
                                    if(data['status']=="success")
                                    {
                                         $("#error_fp").removeClass("alert-danger");
                                    $("#error_fp").addClass("alert-success");
                                     $("#error_fp").html("<b>Success</b> A Temporary Password Is SENT to "+email);
                                     $("#error_fp").show(0).delay(3000).hide(0);
                                     setTimeout(function(){window.location.reload();},3000);
                                    }
                                    else
                                    {
                                        $("#error_fp").html("<b>Opps!!</b> Your Are Not Signed Up Yet.");
                                     $("#error_fp").show(0).delay(3000).hide(0);
                                    }
                                   
                                    }
                         });

            }




    </script>


  </body>
</html>
