<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>SSB GUIDE | Admin Dashboard </title>

  <!-- Font Awesome Icons -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/assets/plugins/font-awesome/css/font-awesome.min.css">
  <!-- DataTables -->

    <link rel="stylesheet" href="<?=base_url()?>assets/admin/assets/plugins/datatables/jquery.dataTables.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/assets/dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>assets/admin/assets/img/SSB_GUIDE.png">
  <link rel="apple-touch-icon" href="<?=base_url()?>assets/admin/assets/img/SSB_GUIDE.png">
  <script src="<?=base_url()?>assets/admin/assets/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap -->
<script src="<?=base_url()?>assets/admin/assets/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?=base_url()?>assets/admin/assets/plugins/datatables/jquery.dataTables.min.js"></script>
<!-- <script src="<?=base_url()?>assets/admin/assets/plugins/datatables/dataTables.bootstrap.min.js"></script> -->
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand bg-white navbar-light border-bottom">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#"><i class="fa fa-bars"></i></a>
      </li>
      <li class="nav-item d-none d-sm-inline-block">
        <a href="<?=base_url()?>admin_dashboard/logout" class="nav-link">Logout</a>
      </li>
    
    </ul>


    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
     
   
      <li class="nav-item">
        <a class="nav-link" data-widget="control-sidebar" data-slide="true" href="#"><i
            class="fa fa-th-large"></i></a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="http://www.ssbguide.com" class="brand-link">
      <img src="<?=base_url()?>assets/admin/assets/img/SSB_GUIDE.png" alt="SSB GUIDE ADMIN" class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">SSB GUIDE ADMIN</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="<?=base_url()?>assets/admin/assets/img/smile.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="javascript:void(0)" class="d-block">Super Admin</a>
        </div>
      </div>

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item has-treeview menu-open">
            
            <?php if($this->uri->segment(1)=="admin" && $this->uri->segment(2)=="") { ?>
            <a href="<?=base_url()?>admin" class="nav-link active">
              <?php } else { ?>
              <a href="<?=base_url()?>admin" class="nav-link">
              <?php } ?>
              <i class="nav-icon fa fa-dashboard"></i>
              <p>
                Dashboard
                
              </p>
            </a>
           
          </li>
            <li class="nav-item has-treeview">
            <?php if($this->uri->segment(2)=="registration-details" ) { ?>
            <a href="javascript:void(0)" class="nav-link active">
              <?php } else { ?>
              <a href="javascript:void(0)" class="nav-link">
              <?php } ?>
              <i class="nav-icon fa fa-list-ul"></i>
              <p>
                Registration Details
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
            
              <a href="<?=base_url()?>admin/registration-details/?type=rd-view-edit" class="nav-link">
              
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>View/Edit</p>
                </a>
              </li>
              <li class="nav-item">
              
              <a href="<?=base_url()?>admin/registration-details/?type=rd-add" class="nav-link">
              
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>ADD</p>
                </a>
              </li>
              
            </ul>
          </li>
           <li class="nav-item has-treeview">
              <?php if($this->uri->segment(2)=="test-series" ) { ?>
            <a href="javascript:void(0)" class="nav-link active">
              <?php } else { ?>
              <a href="javascript:void(0)" class="nav-link">
              <?php } ?>
              <i class="nav-icon fa fa-list-ul"></i>
              <p>
                Test Series
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
               
              <a href="<?=base_url()?>admin/test-series/?type=ts-view-edit" class="nav-link">
              
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>View/Edit</p>
                </a>
              </li>
              <li class="nav-item">
                 
              <a href="<?=base_url()?>admin/test-series/?type=ts-add" class="nav-link">
             
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>ADD</p>
                </a>
              </li>
              
            </ul>
          </li>

           <li class="nav-item has-treeview">
             <?php if($this->uri->segment(2)=="ques-set"  ) { ?>
            <a href="javascript:void(0)" class="nav-link active">
              <?php } else { ?>
              <a href="javascript:void(0)" class="nav-link">
              <?php } ?>
              <i class="nav-icon fa fa-list-ul"></i>
              <p>
                Question Set
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                
              <a href="<?=base_url()?>admin/set-det" class="nav-link">
             
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>View/Edit</p>
                </a>
              </li>
              <li class="nav-item">
                  
              <a href="<?=base_url()?>admin/set-det/sd-add" class="nav-link">
              
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>ADD</p>
                </a>
              </li>
              
            </ul>
          </li>

           <li class="nav-item has-treeview">
              <?php if($this->uri->segment(2)=="users" ) { ?>
            <a href="javascript:void(0)" class="nav-link active">
              <?php } else { ?>
              <a href="javascript:void(0)" class="nav-link">
              <?php } ?>
              <i class="nav-icon fa fa-users"></i>
              <p>
                Users
                <i class="right fa fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
              
              <a href="<?=base_url()?>admin/users/?type=omt-users" class="nav-link">
              
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Online Mock Test</p>
                </a>
              </li>
              <li class="nav-item">
                
              <a href="<?=base_url()?>admin/users/?type=ocr-users" class="nav-link">
              
                  <i class="fa fa-circle-o nav-icon"></i>
                  <p>Offline Registeration</p>
                </a>
              </li>
             
            </ul>
          </li>


          <li class="nav-item has-treeview menu-open">
           <?php if($this->uri->segment(2)=="ssb-us") { ?>
            <a href="<?=base_url()?>admin/ssb-us" class="nav-link active">
              <?php } else { ?>
              <a href="<?=base_url()?>admin/ssb-us" class="nav-link">
              <?php } ?>
             <i class="nav-icon fa fa-check"></i>
              <p>
                SSB User Submissions
               </p>
            </a>
          </li>
           <li class="nav-item has-treeview menu-open">
            <?php if($this->uri->segment(2)=="trans-det") { ?>
            <a href="<?=base_url()?>admin/trans-det" class="nav-link active">
              <?php } else { ?>
              <a href="<?=base_url()?>admin/trans-det" class="nav-link">
              <?php } ?>
             <i class="nav-icon fa fa-credit-card"></i>
              <p>
                Transaction Details
               </p>
            </a>
          </li>
           <li class="nav-item has-treeview menu-open">
           
              <a href="<?=base_url()?>admin_dashboard/logout" class="nav-link">
              
             <i class="nav-icon fa fa-lock"></i>
              <p>
                Log Out
               </p>
            </a>
          </li>
       <!--     <li class="nav-item has-treeview menu-open">
          <?php if($this->uri->segment(2)=="send-note") { ?>
            <a href="<?=base_url()?>admin/send-note" class="nav-link active">
              <?php } else { ?>
              <a href="<?=base_url()?>admin/send-note" class="nav-link">
              <?php } ?>
             <i class="nav-icon fa fa-bell"></i>
              <p>
                Send Notification
               </p>
            </a>
          </li>
          <li class="nav-item has-treeview menu-open">
           <?php if($this->uri->segment(2)=="send-mail") { ?>
            <a href="<?=base_url()?>admin/send-mail" class="nav-link active">
              <?php } else { ?>
              <a href="<?=base_url()?>admin/send-mail" class="nav-link">
              <?php } ?>
             <i class="nav-icon fa fa-envelope"></i>
              <p>
                Send Email
               </p>
            </a>
          </li> -->
          <li>
              <div class="col-md-12" >
            <!-- Widget: user widget style 1 -->
            <div class="card card-widget widget-user" style="background-color:transparent;color:#fff;box-shadow:none;margin-bottom: none;">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header bg-info-active">
                <center>
                   <h3 class="widget-user-username">Rahul Dubey</h3>
                <h5 class="widget-user-desc"><a href="http://d-eviloper.co.in">D-eviloper.co.in</a></h5>
                </center>
               
                <br>
              </div>
              <div class="widget-user-image" style="margin-top:20px">
                <img class="img-circle" style="border:none;" src="<?=base_url()?>assets/admin/assets/img/me-illustrator2.png" alt="User Avatar">
              
            </div>
              
              <div class="card-footer" style="background-color:transparent;">
                
                
                <div class="row">
                  <div class="col-sm-12">
                    <div class="description-block">
                      <h5 class="description-header">Contact Me</h5>
                      <span ><small>dhir.kashayup@gmail.com</small></span>
                        <h6 ><small>+91-9739622411</small></h6>
                    </div>
                    <!-- /.description-block -->
                  </div>
                 
                </div>
                <!-- /.row -->
              </div>
            </div>
            <!-- /.widget-user -->
          </div>
          </li>
          
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>