<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">USER DETAILS </h1>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
 <?php if($viewtype=="ONLINE") { ?>
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title">ONLINE MOCK TEST USERS</h3>
            </div>
            <div class="card-body">
              <div class="col-12" style="overflow-x:auto">
                
              <table id="regist_data_table" class="table table-bordered table-striped" style="font-size: .7em;">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>USER PROFILE PIC</th>
                  <th>USER NAME</th>
                   <th>USER ID</th>
                  <th>USER EMAIL</th>
                  <th>USER MOBILE</th>
                  <th>USER DOB</th>
                  <th>USER ABOUT</th>
                 
                  <th>USER LOCATION</th>
                  
                  <th>USER GENDER</th>
                  
                  <th>USER SELECTED TEST</th>
                  <th>USER SIGNUP On</th>
                  
                </tr>
                </thead>
                <tbody>
                    <?php foreach ($user_det->result() as $regkey) { ?>
                 <tr>
                  <td><?=$regkey->id?></td>
                  <td><?php if($regkey->user_profile_pic==""){ echo "Not Available"; }else{ echo '<img src="'.$regkey->user_profile_pic.'" width="50" height="50">'; } ?></td>
                  <td><?=$regkey->user_name?></td>
                  <td><?=$regkey->user_id?></td>
                  <td><?=$regkey->user_email?></td>
                  <td><?php if($regkey->user_mobile==""){ echo "Not Available"; }else{ echo $regkey->user_mobile; } ?></td>
                  <td><?=$regkey->user_dob?></td>
                  
                  <td><?php if($regkey->user_about==""){ echo "Not Available"; }else{ echo $regkey->user_about; } ?></td>
                  <td><?php if($regkey->user_location==""){ echo "Not Available"; }else{ echo $regkey->user_location; } ?></td>
                  
                  <td><?php if($regkey->user_gender){ echo "Not Available"; }else{ echo $regkey->user_gender; } ?></td>
                  <?php 
                  $selected_test=explode(",",$regkey->user_selected_test);
                  $this->load->model("admin_dashboard_model");
                  $tname="";
                  foreach ($selected_test as $st) {
                    $ts_det=$this->admin_dashboard_model->gettest_series_bykey($st);
                    if($tname=="")
                    {
                      $tname=$ts_det->test_name;
                    }
                    else
                    {
                     $tname.=",".$ts_det->test_name; 
                    }
                  }


                  ?>
                  <td><?=$tname?></td>
                  <td><?=$regkey->user_profile_created_date?></td>
                 
                 </tr>
              <?php } ?>
                </tbody>
                <tfoot>
                <tr>
                    <th>ID</th>
                  <th>USER PROFILE PIC</th>
                  <th>USER NAME</th>
                   <th>USER ID</th>
                  <th>USER EMAIL</th>
                  <th>USER MOBILE</th>
                  <th>USER DOB</th>
                  <th>USER ABOUT</th>
                 
                  <th>USER LOCATION</th>
                 
                  <th>USER GENDER</th>
                  
                  <th>USER SELECTED TEST</th>
                  <th>USER SIGNUP On</th>
                </tr>
                </tfoot>
              </table>
              
            </div>
            </div>
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>

<?php } else { ?>
   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <div class="card">
            <div class="card-header">
              <h3 class="card-title">OFFLINE CLASS REGISTRATIONS</h3>
              
            </div>
            <div class="card-body">
              <div class="col-12" style="overflow-x:auto">
                
              <table id="regist_data_table" class="table table-bordered table-striped" style="font-size: .7em;">
                <thead>
                <tr>
                  <th>Registration Id</th>
                  <th>Candidate Name</th>
                   <th>Father's Name</th>
                  <th>Qualifications </th>
                
                  <th>Address</th>
                  <th>Candidate Mobile</th>
                  <th>Father's Mobile</th>
                  <th>Candidate Email</th>
                  <th>Course Name</th>
                  <th>SSB Type Of Entry</th>
                  <th>SSB Previous Experience</th>
                  <th>Course Commencement Date</th>
                  <th>Paid Amount</th>
                  <th>Due Amount </th>
                  <th>Registration Date</th>
                </tr>
                </thead>
                <tbody>
                
                     <?php foreach ($user_det->result() as $regkey) { ?> 
                 <tr>
                  <td><?=$regkey->registration_id?></td>
                  <td><?=$regkey->name?></td>
                  <td><?=$regkey->father_name?></td>
                  <td><?=$regkey->qualification?></td>
                  
                  <td><?=$regkey->address?></td>
                  
                  <td><?=$regkey->mobile_no?></td>
                  <td><?=$regkey->f_mobile_no?></td>
                  <td><?=$regkey->email_id?></td>
                  <td><?=$regkey->course_name?></td>
                  <td><?php if($regkey->ssb_type_of_entry==""){ echo "Not Available"; }else{ echo $regkey->ssb_type_of_entry; } ?></td>
                  <td><?php if($regkey->ssb_previous_experience==""){ echo "Not Available"; }else{ echo $regkey->ssb_previous_experience; } ?></td>
                  <td><?=$regkey->course_commencement_date?></td>
                  <td><i class="fa fa-rupee"></i><?=$regkey->paid_amount?></td>
                  <td><i class="fa fa-rupee"></i><?=$regkey->due_amount?></td>
                  <td><?=$regkey->registration_date?></td>

                  
                 </tr>
              <?php } ?>
                </tbody>
                <tfoot>
               <tr>
                  <th>Registration Id</th>
                  <th>Candidate Name</th>
                   <th>Father's Name</th>
                  <th>Qualifications </th>
                
                  <th>Address</th>
                  <th>Candidate Mobile</th>
                  <th>Father's Mobile</th>
                  <th>Candidate Email</th>
                  <th>Course Name</th>
                  <th>SSB Type Of Entry</th>
                  <th>SSB Previous Experience</th>
                  <th>Course Commencement Date</th>
                  <th>Paid Amount</th>
                  <th>Due Amount </th>
                  <th>Registration Date</th>
                </tr>
                </tfoot>
              </table>
              
            </div>
            </div>
          
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
<?php } ?>

    <!-- /.content -->
     </div>
          <script>
  $(function () {
    
    $('#regist_data_table').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": false
    });
  });
</script>
