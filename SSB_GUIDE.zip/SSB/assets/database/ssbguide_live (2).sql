-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 01, 2018 at 07:11 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 5.6.36

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ssbguide_live`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_credentials`
--

CREATE TABLE `admin_credentials` (
  `id` int(11) NOT NULL,
  `admin_user_id` text NOT NULL,
  `admin_pass` text NOT NULL,
  `admin_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_credentials`
--

INSERT INTO `admin_credentials` (`id`, `admin_user_id`, `admin_pass`, `admin_timestamp`) VALUES
(1, 'SuperAdmin', 'ssbguide@admin123$', '2018-05-19 21:29:32');

-- --------------------------------------------------------

--
-- Table structure for table `payment_credentials`
--

CREATE TABLE `payment_credentials` (
  `id` int(11) NOT NULL,
  `gateway_name` varchar(100) DEFAULT NULL,
  `test_payment_gateway` text,
  `live_payment_gateway` text,
  `working_key` text,
  `access_key` text,
  `merchant_id` bigint(20) DEFAULT NULL,
  `currency` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_credentials`
--

INSERT INTO `payment_credentials` (`id`, `gateway_name`, `test_payment_gateway`, `live_payment_gateway`, `working_key`, `access_key`, `merchant_id`, `currency`) VALUES
(1, 'CCAvenue', 'https://test.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest=##ENC_DATA##&access_code=##ACCESS_CODE##', 'https://secure.ccavenue.com/transaction/transaction.do?command=initiateTransaction&encRequest=##ENC_DATA##&access_code=##ACCESS_CODE##   ', 'CB335222E02CF5E30AE8C5F45C5C63AE', 'AVPC77FE84AK77CPKA', 175531, 'INR');

-- --------------------------------------------------------

--
-- Table structure for table `payment_details`
--

CREATE TABLE `payment_details` (
  `id` int(11) NOT NULL,
  `pay_id` varchar(20) NOT NULL,
  `session_id` text,
  `user_name` varchar(50) DEFAULT NULL,
  `user_address` text,
  `user_mobile_no` varchar(10) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `paid_through` varchar(20) DEFAULT NULL,
  `paid_for` varchar(30) DEFAULT NULL,
  `payable_amt` bigint(20) NOT NULL,
  `payment_date` datetime NOT NULL,
  `payment_status` tinyint(4) NOT NULL DEFAULT '0',
  `payment_response` text,
  `payment_update_date` datetime DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_details`
--

INSERT INTO `payment_details` (`id`, `pay_id`, `session_id`, `user_name`, `user_address`, `user_mobile_no`, `user_email`, `paid_through`, `paid_for`, `payable_amt`, `payment_date`, `payment_status`, `payment_response`, `payment_update_date`) VALUES
(1, '18050001', '854dbf14d83925798ec3c4dc64fec67d', 'Rahul Dubey', 'VVS Residency,Siddapura,Whitefield,Bengaluru,Karnataka,India,560066', '9876543210', 'dhir.xcess@gmail.com', 'REGISTRATION', 'Super 30 – NDA', 1000, '2018-05-10 10:36:00', 1, NULL, '2018-05-08 00:00:00'),
(2, '18050002', NULL, 'kali charan', 'N/A', 'N/A', 'kalicharan@kc.com', 'SIGNUP-NDA', 'NDA', 300, '2018-05-17 10:35:00', 0, NULL, NULL),
(3, '18050003', 'b0131bdc1687865cbbe4d8d769dd7689', 'Rahul Dubey', 'bengalore', '9876543210', 'dhir.xcess@gmail.com', 'Enrollment-AFCAT', 'AFCAT', 300, '2018-05-18 04:57:00', 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `registration_details`
--

CREATE TABLE `registration_details` (
  `course_id` int(11) NOT NULL,
  `course_name` text,
  `course_duration` int(3) DEFAULT NULL,
  `type_of_entry` text,
  `previous_experience` text,
  `course_commencement_date` text,
  `fee_amount` text,
  `registration_fee` int(4) DEFAULT NULL,
  `created_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration_details`
--

INSERT INTO `registration_details` (`course_id`, `course_name`, `course_duration`, `type_of_entry`, `previous_experience`, `course_commencement_date`, `fee_amount`, `registration_fee`, `created_timestamp`) VALUES
(1, 'Super 30 – NDA', 45, '', '', '2018-06-01', '30000', 1000, '2018-04-29 06:21:14'),
(2, 'Super 30 – CDS', 45, '', '', '2018-06-01', '30000', 1000, '2018-04-29 06:21:14'),
(3, 'Super 30 – AFCAT', 45, NULL, NULL, '2018-06-01', '30000', 1000, '2018-04-29 06:21:14'),
(4, 'Super 30 – SSB', 15, 'Technical,Written,NCC,Others', 'Fresher,Screenout,Repeater', '2018-06-01,2018-06-16,2018-07-01', '15000', 1000, '2018-04-29 06:21:14');

-- --------------------------------------------------------

--
-- Table structure for table `registration_enquiry`
--

CREATE TABLE `registration_enquiry` (
  `registration_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `father_name` varchar(100) DEFAULT NULL,
  `qualification` varchar(100) DEFAULT NULL,
  `address` text,
  `mobile_no` varchar(10) DEFAULT NULL,
  `f_mobile_no` varchar(10) DEFAULT NULL,
  `email_id` varchar(100) DEFAULT NULL,
  `course_id` int(10) DEFAULT NULL,
  `course_name` varchar(100) DEFAULT NULL,
  `ssb_type_of_entry` varchar(100) DEFAULT NULL,
  `ssb_previous_experience` varchar(100) DEFAULT NULL,
  `course_commencement_date` date DEFAULT NULL,
  `paid_amount` int(10) DEFAULT NULL,
  `due_amount` int(10) DEFAULT NULL,
  `registration_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration_enquiry`
--

INSERT INTO `registration_enquiry` (`registration_id`, `name`, `father_name`, `qualification`, `address`, `mobile_no`, `f_mobile_no`, `email_id`, `course_id`, `course_name`, `ssb_type_of_entry`, `ssb_previous_experience`, `course_commencement_date`, `paid_amount`, `due_amount`, `registration_date`) VALUES
(3, 'Rahul Dubey', 'Rn Dubey', 'Graduation', 'Bengalore', '9876543210', '9876543210', 'dhir.xcess@gmail.com', 4, 'Super 30 – SSB', 'Technical', 'Fresher', '2018-06-01', 1000, 14000, '2018-04-29 14:28:15'),
(2, 'Rahul Dubey', 'Rn Dubey', 'Graduation', 'Bengalore', '9876543210', '9876543210', 'dhir.yo@facebook.com', 4, 'Super 30 – SSB', 'Technical', 'Fresher', '2018-06-01', 1000, 14000, '2018-04-29 13:57:29'),
(4, 'Rahul Dubey', 'Rn Dubey', 'Graduation', 'Bengalore', '9876543210', '9876543210', 'dhir.xcess@gmail.com', 4, 'Super 30 – SSB', 'Technical', 'Fresher', '2018-06-01', 1000, 14000, '2018-04-29 14:29:05'),
(5, 'Rahul Dubey', 'R.N Dubey', 'Graduation', 'Bengalore', '9876543210', '9876543210', 'dhir.xcess@gmail.com', 4, 'Super 30 – SSB', 'Technical', 'Fresher', '2018-06-01', 1000, 14000, '2018-04-29 14:32:23'),
(6, 'Rahul Dubey', 'R.N Dubey', 'Graduation', 'Bengalore', '9876543210', '9876543210', 'dhir.xcess@gmail.com', 4, 'Super 30 – SSB', 'Technical', 'Fresher', '2018-06-01', 1000, 14000, '2018-04-29 14:32:43');

-- --------------------------------------------------------

--
-- Table structure for table `test_categories`
--

CREATE TABLE `test_categories` (
  `id` int(11) NOT NULL,
  `test_series_key` text,
  `category_name` text,
  `category_question_limit` int(5) DEFAULT NULL,
  `category_time_limit` int(10) DEFAULT NULL,
  `category_full_marks` int(4) DEFAULT NULL,
  `category_marks_per_ques` int(2) DEFAULT NULL,
  `category_negative_marks` double DEFAULT NULL,
  `category_status` tinyint(4) NOT NULL DEFAULT '1',
  `category_created_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_categories`
--

INSERT INTO `test_categories` (`id`, `test_series_key`, `category_name`, `category_question_limit`, `category_time_limit`, `category_full_marks`, `category_marks_per_ques`, `category_negative_marks`, `category_status`, `category_created_timestamp`) VALUES
(1, 'a83402fc91ca54f362c09c927eafa1ba', 'Mathematics', 120, 90, 300, 3, 0.833, 1, '2018-05-14 15:02:09'),
(2, 'a83402fc91ca54f362c09c927eafa1ba', 'General Studies', 150, 90, 600, 4, 1.33, 1, '2018-05-14 15:02:09'),
(3, 'b1da7839edd4969a1aaa4435721a149c', 'Mathematics', 100, 120, 100, 1, 0.33, 1, '2018-05-14 15:02:09'),
(4, 'b1da7839edd4969a1aaa4435721a149c', 'General Knowledge', 100, 120, 100, 1, 0.33, 1, '2018-05-14 15:02:09'),
(5, 'b1da7839edd4969a1aaa4435721a149c', 'English', 100, 120, 100, 1, 0.33, 1, '2018-05-14 15:02:09'),
(6, 'da1bd1670915b7010636332b654c685f', 'General Awareness', 11, 30, 31, 3, 1, 1, '2018-05-14 15:02:09'),
(7, 'da1bd1670915b7010636332b654c685f', 'Verbal Ability', 5, 30, 15, 3, 1, 1, '2018-05-14 15:02:09'),
(8, 'da1bd1670915b7010636332b654c685f', 'Numerical Ability', 10, 30, 30, 3, 1, 1, '2018-05-14 15:02:09'),
(9, 'da1bd1670915b7010636332b654c685f', 'Reasoning & Military Aptitude Test', 8, 30, 24, 3, 1, 1, '2018-05-14 15:02:09'),
(10, 'e7b26d653c8b64a48bef062ac0b67374', 'TAT', 12, 120, 120, 10, 0, 1, '2018-05-14 15:02:09');

-- --------------------------------------------------------

--
-- Table structure for table `test_scores`
--

CREATE TABLE `test_scores` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `test_type_name` varchar(100) NOT NULL,
  `test_type_key` text NOT NULL,
  `test_score` bigint(20) DEFAULT NULL COMMENT 'in percentage',
  `test_time_taken` varchar(100) DEFAULT NULL,
  `test_status` tinyint(4) NOT NULL DEFAULT '0',
  `is_ssb` tinyint(4) NOT NULL DEFAULT '0',
  `test_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_scores`
--

INSERT INTO `test_scores` (`id`, `user_id`, `test_type_name`, `test_type_key`, `test_score`, `test_time_taken`, `test_status`, `is_ssb`, `test_timestamp`) VALUES
(1, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-18 22:36:06'),
(2, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 30, '1.0676999999999999', 1, 0, '2018-05-18 22:36:21'),
(3, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 14:35:04'),
(4, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 14:36:01'),
(5, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 14:36:06'),
(6, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 14:37:42'),
(7, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 90, '0.5971833333333334', 1, 0, '2018-05-19 14:38:26'),
(8, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 50, '0.49585', 1, 0, '2018-05-19 14:42:55'),
(9, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 40, '0.44886666666666664', 1, 0, '2018-05-19 14:46:58'),
(10, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 14:49:04'),
(11, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 100, '0.40841666666666665', 1, 0, '2018-05-19 14:49:29'),
(12, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '1.37555', 1, 0, '2018-05-19 14:51:25'),
(13, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0.052566666666666664', 1, 0, '2018-05-19 14:55:01'),
(14, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0.047683333333333335', 1, 0, '2018-05-19 14:57:00'),
(15, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 14:58:23'),
(16, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 14:59:07'),
(17, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 14:59:40'),
(18, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:00:13'),
(19, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:00:48'),
(20, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:01:22'),
(21, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:02:11'),
(22, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:02:19'),
(23, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:04:10'),
(24, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:12:18'),
(25, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:12:44'),
(26, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:13:28'),
(27, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:14:22'),
(28, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:19:14'),
(29, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:19:43'),
(30, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:20:34'),
(31, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:21:29'),
(32, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:23:04'),
(33, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:23:42'),
(34, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:25:25'),
(35, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:25:49'),
(36, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:27:17'),
(37, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:31:51'),
(38, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:33:13'),
(39, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:34:53'),
(40, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:37:38'),
(41, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:39:26'),
(42, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 15:40:40'),
(43, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0', 1, 0, '2018-05-19 16:07:58'),
(44, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0.07026666666666667', 1, 0, '2018-05-19 16:08:23'),
(45, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:28:41'),
(46, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:34:25'),
(47, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:35:42'),
(48, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:36:40'),
(49, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:38:49'),
(50, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:42:35'),
(51, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:43:24'),
(52, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:43:54'),
(53, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 16:47:24'),
(54, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 0, '0', 1, 1, '2018-05-19 17:05:16'),
(55, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 78, '0', 1, 1, '2018-05-19 17:55:29'),
(56, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', 76, '0', 1, 1, '2018-05-19 17:58:49'),
(57, 2, 'NDA', 'a83402fc91ca54f362c09c927eafa1ba', 0, '0.20375', 1, 0, '2018-06-21 09:26:09'),
(58, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', NULL, '0.1023', 0, 1, '2018-06-22 08:48:12'),
(59, 2, 'SSB', 'e7b26d653c8b64a48bef062ac0b67374', NULL, NULL, 0, 1, '2018-06-22 08:48:29');

-- --------------------------------------------------------

--
-- Table structure for table `test_series`
--

CREATE TABLE `test_series` (
  `id` int(11) NOT NULL,
  `test_key` text NOT NULL,
  `test_name` varchar(100) NOT NULL,
  `test_description` text,
  `test_instructions` text,
  `test_img_url` text,
  `test_time_limit` bigint(20) NOT NULL,
  `test_type` varchar(100) DEFAULT NULL,
  `test_status` tinyint(1) NOT NULL DEFAULT '1',
  `test_enrollment_fee` bigint(20) DEFAULT NULL,
  `test_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_series`
--

INSERT INTO `test_series` (`id`, `test_key`, `test_name`, `test_description`, `test_instructions`, `test_img_url`, `test_time_limit`, `test_type`, `test_status`, `test_enrollment_fee`, `test_timestamp`) VALUES
(1, 'a83402fc91ca54f362c09c927eafa1ba', 'NDA', 'It includes two parts Mathematics and English & General Studies .Test will be of 900 marks 300 for Mathematics and 600 for General Studies .There are 120 questions in Mathematics and each question consist of 2.5 Marks so the negative mark per question is 0.833. And In General Studies there are 150 Questions and Each question consist of 4 Marks so negative marks for each question is 1.33 .', '<b>Test Contains Two Categories: </b><br>\n1. Mathematics (120 Questions 2.5 Marks Each, Total Marks 300 ).<br>\n2. English & Genral Studies (150 Questions 4 Marks Each,Total Marks 600 )<br>\n<br>\n<b>Time Limits: (3 Hrs) </b><br>\n1.Mathematics (1.5 Hrs)<br>\n2.English & General Studies (1.5 Hrs)<br>\n<b>Negative Marks : </b>\n<br>\n1.Mathematics (0.833 per wrong answer).\n<br>\n2. English & General Studies (1.33 per wrong answer)\n<br>\n\n<b> Note: </b> \n<br>\nSubmit Test After Completion. And If Time run Out Test Will Get Auto Submitted.\n\n\n', 'http://localhost/SSB/assets/admin/uploads/test_series/342640f16991ef76a20c4c644b08552f.jpeg', 180, 'OBJECTIVE', 1, 300, '2018-05-14 12:57:53'),
(2, 'b1da7839edd4969a1aaa4435721a149c', 'CDS', 'There are 100 MCQs in each of the three sections. Questions will be asked from Mathematics, GK and English.The total time allotted for each paper is 2 hours. Marks allotted to each section is 100 marks. Negative marking is applicable in the CDS 2018. One-third mark will be deducted for each incorrect response ', '<b>Test Contains Three Categories: </b><br>\r\n1. Mathematics (100 Questions 1 Marks Each, Total Marks 100 ).<br>\r\n2. English (100 Questions 1 Marks Each, Total Marks 100 ).<br>\r\n3. Genral Knowledge (100 Questions 1 Marks Each, Total Marks 100 ).<br>\r\n<br>\r\n<b>Time Limits: (6 Hrs) </b><br>\r\n1.Mathematics (2 Hrs)<br>\r\n2.English (2 Hrs)<br>\r\n3 General Knowledge (2 Hrs)<br>\r\n<b>Negative Marks : </b>\r\n<br>\r\n1.Mathematics (0.333 per wrong answer).\r\n<br>\r\n2. English (0.333 per wrong answer)\r\n<br>\r\n3. General Knowledge (0.333 per wrong answer)\r\n<br>\r\n\r\n<b> Note: </b> \r\n<br>\r\nSubmit Test After Completion. And If Time run Out Test Will Get Auto Submitted.\r\n\r\n\r\n', 'http://localhost/SSB/assets/img/cds.jpg', 360, 'OBJECTIVE', 1, 300, '2018-05-14 12:57:53'),
(3, 'da1bd1670915b7010636332b654c685f', 'AFCAT', 'There will be Multiply Choice Based Questions of 3 marks each. The candidates will be penalized in the form of deduction of 1 marks for every wrong answers attempted by them. Three wrong answers will take away one correct answer.', '<b>Test Contains Four Categories: </b><br>\r\n1. General Awareness (11 Questions 3 Or 1 Marks Each, Total Marks 31 ).<br>\r\n2. Verbal Ability (5 Questions 3 Marks Each, Total Marks 15 ).<br>\r\n3.Numerical Ability(10 Questions 3 Marks Each, Total Marks 30 ).<br>\r\n4.Reasoning & Military Aptitude Test(8 Questions 3 Marks Each, Total Marks 24 ).<br>\r\n<br>\r\n<b>Time Limits: (2 Hrs) </b><br>\r\n1.General Awareness (0.5 Hrs)<br>\r\n2.Verbal Ability (0.5 Hrs)<br>\r\n3.Numerical Ability (0.5 Hrs)<br>\r\n4.Reasoning & Military Aptitude Test (0.5 Hrs)<br>\r\n<b>Negative Marks : </b>\r\n<br>\r\nhe candidates will be penalized in the form of deduction of 1 marks for every wrong answers attempted by them. Three wrong answers will take away one correct answer.\r\n<br>\r\n\r\n<b> Note: </b> \r\n<br>\r\nSubmit Test After Completion. And If Time run Out Test Will Get Auto Submitted.\r\n\r\n\r\n', 'http://localhost/SSB/assets/img/AFCAT_New.png', 120, 'OBJECTIVE', 1, 300, '2018-05-14 12:57:53'),
(4, 'e7b26d653c8b64a48bef062ac0b67374', 'SSB', 'A set of 12 pictures is generally used including one blank slide. A slide of each picture is shown on a screen with the help of a magic lantern for half a minute and the candidates are required to write a story based on the picture in a period of four minutes in the particular space provided on the answer sheet.', 'A set of 12 pictures is generally used including one blank slide. A slide of each picture is shown on a screen with the help of a magic lantern for half a minute and the candidates are required to write a story based on the picture in a period of four minutes in the particular space provided on the answer sheet.\n\n<b> Note: </b> \n<br>\nSubmit Test After Completion. And If Time run Out Test Will Get Auto Submitted.\n\n\n', 'http://localhost/SSB/assets/img/ssb.jpg', 120, 'APPERCEPTION', 1, 500, '2018-05-14 12:57:53');

-- --------------------------------------------------------

--
-- Table structure for table `test_sets`
--

CREATE TABLE `test_sets` (
  `set_id` int(11) NOT NULL,
  `test_set_for` text NOT NULL,
  `test_set_name` varchar(100) DEFAULT NULL,
  `test_set_status` tinyint(4) NOT NULL DEFAULT '1',
  `test_set_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_sets`
--

INSERT INTO `test_sets` (`set_id`, `test_set_for`, `test_set_name`, `test_set_status`, `test_set_timestamp`) VALUES
(1, 'a83402fc91ca54f362c09c927eafa1ba', 'SET 1', 1, '2018-05-18 16:52:35'),
(2, 'a83402fc91ca54f362c09c927eafa1ba', 'SET 2', 1, '2018-05-18 16:52:44'),
(3, 'e7b26d653c8b64a48bef062ac0b67374', 'SSB SET 1', 1, '2018-05-18 16:52:44'),
(5, 'b1da7839edd4969a1aaa4435721a149c', 'CDS SET 1', 1, '2018-05-20 23:41:40'),
(6, 'da1bd1670915b7010636332b654c685f', 'AFCAT SET 1', 1, '2018-05-21 00:01:05');

-- --------------------------------------------------------

--
-- Table structure for table `test_sets_questions`
--

CREATE TABLE `test_sets_questions` (
  `question_id` int(11) NOT NULL,
  `set_id` int(11) NOT NULL,
  `question_content` text NOT NULL,
  `question_options` text,
  `question_correct_option` text,
  `question_status` tinyint(4) NOT NULL DEFAULT '1',
  `question_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_sets_questions`
--

INSERT INTO `test_sets_questions` (`question_id`, `set_id`, `question_content`, `question_options`, `question_correct_option`, `question_status`, `question_timestamp`) VALUES
(1, 1, '1.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:55:59'),
(2, 1, '2.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:56:08'),
(3, 1, '3.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:56:21'),
(4, 1, '4.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:56:29'),
(5, 1, '5.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:56:36'),
(6, 1, '6.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:56:44'),
(7, 1, '7.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:56:52'),
(8, 1, '8.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:56:58'),
(9, 1, '9.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:57:05'),
(10, 1, '10.WHO WAS THE ARCHITECT OF CHANDIGARH?', 'John kele##Le corbuisier##Roman Seigh##Jay Prakash', 'Le corbuisier', 1, '2018-05-18 16:57:12'),
(11, 2, '1.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:01'),
(12, 2, '2.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:09'),
(13, 2, '3.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:16'),
(14, 2, '4.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:23'),
(15, 2, '5.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:32'),
(16, 2, '6.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:40'),
(17, 2, '7.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:45'),
(18, 2, '8.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:51'),
(19, 2, '9.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:58:57'),
(20, 2, '10.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-18 16:59:05'),
(21, 3, 'http://localhost/SSB/assets/img/1.jpeg', '', '', 1, '2018-05-19 16:19:29'),
(22, 3, 'http://localhost/SSB/assets/img/2.jpeg', '', '', 1, '2018-05-19 16:19:59'),
(23, 3, 'http://localhost/SSB/assets/img/3.jpeg', '', '', 1, '2018-05-19 16:20:08'),
(24, 3, 'http://localhost/SSB/assets/img/4.jpeg', '', '', 1, '2018-05-19 16:20:14'),
(25, 3, 'http://localhost/SSB/assets/img/5.jpeg', '', '', 1, '2018-05-19 16:20:21'),
(26, 3, 'http://localhost/SSB/assets/img/6.jpeg', '', '', 1, '2018-05-19 16:20:28'),
(27, 3, 'http://localhost/SSB/assets/img/7.jpeg', '', '', 1, '2018-05-19 16:20:34'),
(28, 3, 'http://localhost/SSB/assets/img/8.jpeg', '', '', 1, '2018-05-19 16:20:40'),
(29, 3, 'http://localhost/SSB/assets/img/9.jpeg', '', '', 1, '2018-05-19 16:20:45'),
(30, 3, 'http://localhost/SSB/assets/admin/uploads/questions/5eab3898a4c4c239d4888f76b4dbf4ee.jpeg', '', '', 1, '2018-05-19 16:20:51'),
(31, 3, 'http://localhost/SSB/assets/img/11.jpeg', '', '', 1, '2018-05-19 16:20:56'),
(32, 3, 'http://localhost/SSB/assets/img/12.jpeg', '', '', 1, '2018-05-19 16:21:03'),
(34, 5, '1.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:29'),
(35, 5, '2.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:29'),
(36, 5, '3.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:29'),
(37, 5, '4.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:29'),
(38, 5, '5.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:29'),
(39, 5, '6.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:30'),
(40, 5, '7.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:30'),
(41, 5, '8.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:30'),
(42, 5, '9.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:30'),
(43, 5, '10.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:55:30'),
(44, 5, '1.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:21'),
(45, 5, '2.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:21'),
(46, 5, '3.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:21'),
(47, 5, '4.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:21'),
(48, 5, '5.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:21'),
(49, 5, '6.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:21'),
(50, 5, '7.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:21'),
(51, 5, '8.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:21'),
(52, 5, '9.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:22'),
(53, 5, '10.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:56:22'),
(54, 5, '1.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:24'),
(55, 5, '2.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:25'),
(56, 5, '3.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:26'),
(57, 5, '4.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:26'),
(58, 5, '5.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:26'),
(59, 5, '6.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:26'),
(60, 5, '7.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:26'),
(61, 5, '8.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:27'),
(62, 5, '9.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:27'),
(63, 5, '10.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-20 23:58:27'),
(64, 6, '1.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(65, 6, '2.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(66, 6, '3.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(67, 6, '4.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(68, 6, '5.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(69, 6, '6.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(70, 6, '7.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(71, 6, '8.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(72, 6, '9.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(73, 6, '10.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:01:06'),
(74, 6, '1.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(75, 6, '2.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(76, 6, '3.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(77, 6, '4.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(78, 6, '5.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(79, 6, '6.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(80, 6, '7.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(81, 6, '8.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(82, 6, '9.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08'),
(83, 6, '10.What is the result of 2 + 2 ?', '1##2##3##4', '4', 1, '2018-05-21 00:03:08');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_mobile` varchar(10) DEFAULT NULL,
  `user_dob` date DEFAULT NULL,
  `user_id` varchar(100) DEFAULT NULL,
  `user_passkey` text,
  `user_location` text,
  `user_about` text,
  `user_gender` varchar(10) DEFAULT NULL,
  `user_profile_pic` text,
  `user_selected_test` text,
  `user_profile_created_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `user_email`, `user_mobile`, `user_dob`, `user_id`, `user_passkey`, `user_location`, `user_about`, `user_gender`, `user_profile_pic`, `user_selected_test`, `user_profile_created_date`) VALUES
(1, 'Rahul', 'dhir.xcess@gmail.com', NULL, '2018-05-10', 'admin', '59691a701045fe7d28d634dbf79bf58e', NULL, NULL, NULL, NULL, 'a83402fc91ca54f362c09c927eafa1ba', '0000-00-00 00:00:00');
INSERT INTO `users` (`id`, `user_name`, `user_email`, `user_mobile`, `user_dob`, `user_id`, `user_passkey`, `user_location`, `user_about`, `user_gender`, `user_profile_pic`, `user_selected_test`, `user_profile_created_date`) VALUES
(2, 'Rahul Dubey', 'dhir.xcess@gmail.com', '9876543210', '1994-03-24', 'Rahul dubey', 'd8578edf8458ce06fbc5bb76a58c5ca4', 'bengalore', 'Hi, I am new Here.', 'Male', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAgAAAQABAAD/7QCcUGhvdG9zaG9wIDMuMAA4QklNBAQAAAAAAIAcAmcAFGxpZTgwdTNERUxpM0dDVEpFU28yHAIoAGJGQk1EMDEwMDBhYzAwMzAwMDAyODE5MDAwMGZkMzQwMDAwMTUzNzAwMDBhNDM5MDAwMGZhNTkwMDAwZWE3ZTAwMDA5NDg3MDAwMDQ2OGEwMDAwM2Q4ZDAwMDBhY2M3MDAwMP/iAhxJQ0NfUFJPRklMRQABAQAAAgxsY21zAhAAAG1udHJSR0IgWFlaIAfcAAEAGQADACkAOWFjc3BBUFBMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD21gABAAAAANMtbGNtcwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACmRlc2MAAAD8AAAAXmNwcnQAAAFcAAAAC3d0cHQAAAFoAAAAFGJrcHQAAAF8AAAAFHJYWVoAAAGQAAAAFGdYWVoAAAGkAAAAFGJYWVoAAAG4AAAAFHJUUkMAAAHMAAAAQGdUUkMAAAHMAAAAQGJUUkMAAAHMAAAAQGRlc2MAAAAAAAAAA2MyAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHRleHQAAAAARkIAAFhZWiAAAAAAAAD21gABAAAAANMtWFlaIAAAAAAAAAMWAAADMwAAAqRYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9jdXJ2AAAAAAAAABoAAADLAckDYwWSCGsL9hA/FVEbNCHxKZAyGDuSRgVRd13ta3B6BYmxmnysab9908PpMP///9sAQwAJBgcIBwYJCAgICgoJCw4XDw4NDQ4cFBURFyIeIyMhHiAgJSo1LSUnMiggIC4/LzI3OTw8PCQtQkZBOkY1Ozw5/9sAQwEKCgoODA4bDw8bOSYgJjk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5OTk5/8IAEQgDwAMAAwAiAAERAQIRAf/EABsAAQACAwEBAAAAAAAAAAAAAAAFBgEDBAIH/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAECAwQF/8QAGQEBAQEBAQEAAAAAAAAAAAAAAAECAwQF/9oADAMAAAERAhEAAAGQEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEVXS3x9PxVpzVRdZH5ztPoisWONgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABzHupcfLQAAAyY6+UX/AF0fwWfihBLeocWKSpY+kZ+f2iJg4jtVjjLmpW4t6AmDeAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcJ3KtF1e8fOh9Fo2jSADaatlr3EVKwUSXRSRcOStCXjNYAAAAkODAAAe/Aslk+byhdXj3AAAAAAAAAAAAAAAAAAAAAAAAAADl4KnUlEgAAALAc9g4KudfGAAA9nhOdxVc2gVZacFYWgVZaclVTsKeAAAAStz+b2UsggAAAAAAAAAAAAAAAAAAAAAAABB91GMYKAAAG0k+/upZgAA9nmQnOI7fFWwSEeAAAAHfOVQW2vc1jKyt1WNQAHvwPoW+uWOAAAAAAAAAAAAAAAAAAAAAAABylTjM4oAAABbqvaStcoADJst+KietAAADJh63nM6tB4AABvtlMEnGW2HIoAHfevm/0Q2CAAAAAAAAAAAAAAAAAAAAAAEHOVuq0AAAACzQ1kpwAAs1etBBR4AAPcpOHH1VviLdzVoWTpqQuOiq9Rq1XSEIYAGbnS9x657nTABMwwvnb84tJPCAAAAAAAAAAAAAAAAAAAAAFastfKsKAAAZx1llp9lrQABZYWx1EAAWHk6zNdzgAANtwKd7tfkqFnk6eSEJdKiaQAWiF5baU4ADOBdZSh3yAAAAAAAAAAAAAAAAAAAAAET2VqoUAAACbhLMR0V08wAzjJbKlbqiAM4nCVp0lGgAAlCyVCargBsulHspCWOrXApYAFzplrKo6OcAAXqi2UsggAAAAAAAAAAAAAAAAAABF9VEGsobTUAABa6pbSr6vfgAevPstVSttSAFtrM8Vo2njvmKweQLbUrYVrRv0ACZht5puVMuRTse/AAmoXvOqGslbAAEvESRdxAAAAAAAAAAAAAAAAAAA1lUhffigExD2UrQAAFtqVsKr52awB685LZUrdUQCywNkqounFFHBrzayLitmgS0SLBX7vTjSABdalbCllgK+sceRnVy9xN1ay1oAAS0TYC0iAAAAAAAAAAAAAAAAAAEfIRBTRQCz1juNXNaqqAALNWZkjufv4AAC0VefgBnEiSdf6JUkKd0SBJwshAHnfYOQjuQOi50T2dsfaewpW64YN9M9chZuSdpBjOAnoG5kHEe/AAAnIMfSM064wAAAAAAAAAAAAAAAAAAhpmLKUKAAvdHkZcqgAGzWJiH7OMAAk4zdpHfwbTXMw3QarDF85izxMSdPNM95x7o3uOGOtOsrnmTjDyBs1i50y70gA23DzWTiAAAAt9Q7i9iAAAAAAAAAAAAAAAAAHJ14Pm7ZroABcad6OnktdUAAM4AAAABnAz68B0c49YwOvlwAAAALhDRNsKnbeyunRXwAAZxKkZ59eRnA+je+fogAAAAAAAAAAAAAAAAACmRNtqVdWnXaCrujnAO3xy7DWA2T0V3ZepWboMhdvedVTosZYHZNJYhLiIS4hdU+Kzotqyl819Hzjj+p5ufkOPrfIny99H46oi2x1zBt+mzDOAAAAzNkPZ5GlGgA2F/3EAAAAAAAAAAAAAAAADQYrEbz178A9+BdI2uzJD4t0UQz35FglbBjpo3GejONhtAAAAAAAAAEAANHRsqDo/1TkuPlPbz6OnKc31/aWPrqGkvMRXBnCVOLxLwYlYq3k0IAAAAAAAAAAAAAAAAVe0UyokB63nMAAD3aoD6RnbBz6hTbq2G0AAAAAAAAAAAyevQBFcoH2L5tvlCjeCQkyubLZuNPHGcA8+/B23uKlgIAAAAAAAAAAAAAAAAVe0QdVICVihaddaEnHeQzjeXKczjl3BQHryOlr2AAAAAAAAAAGdmMgACNksHx7Fir3Tz4FM4ye8dsqV/Xu3Fz6SAAAAAAAAAAAAAAAAAFIu/z2tAADbsOZnAtVW+m510YOfYKAAb9GToYyAAAAAAAANmPQAAABF/MfsPzjXOEG+eyUhxNQ2At8XbgIAAAAAAAAAAAAAAAAAUO+V2qwAAAZJ28xshz7GIeWZ4IDzc93Fs9Wcu7HNZMTNA44+p7qNbc77Xj20AAAAEAPePYFAAAAISbwnx7EvEdeAB02OWq9FrrRYZj5xdrJEQAAAAAAAAAAAAAAAAh5OgVqSFklpaSjbAEzE/Sc66sHPt59FBAAGeboVV4b6DquNXfVpxZFr2TQAQRMJrNy5KT02WHRySEeJDd1rgTQAAADGcET80+w/Otc4Kd6L7ZzbtmOfXxzdnmvkMzyZ6+e8CAAAAAAAAAAAAAAAAIKqT8HX0OXxnl3xS7pk+Q5s/L04zFo9c/Pt4ZLhkYZGGRhkYZGGRjz7Do595lkY5+kaN4mffn2uGRhkYZGGRhkYZGAMZwePm1nidc716cud9QVjPg+YZ4Znp57YAAAAAAAAAAAAAAAACpRU1B19a0bubl6GcD3QL5X7jhrPXx755Yk7I1a64c7psRVEhHGWBlgZYGWBljvOFZEtbT0AmU1IVVTuOFa4E4mBlgZYGWBlgXm1VW1c+zGa9LTbnQvreucFW/odNWRsNYs80gp35wQlwqv0Dpx9CAAAAAAAAAAAAAAAAIGq3ij19VxwSHLvgLC12P+ga5fN8bLlrNJt1S7bPsfyPqtRT/AKxVqsddV+gSB8vZwAAALJW7JLehy7x3zL6b8y6cvodt+RdmsQdht3AW75h4sp87fSfmwAAAdl8l4LVx9nPs+X3X5xrnZb7DzE3n5hfaJc3uRM9Iv5jORHTjYLHr2MgAAAAAAAAAAAAAAAAefnv0So1IW35j9Qx11efTO/mf035r9E1zok3rgbnzr+m16apf1L5c3z+ofPer6wVKcpNZOvT9npxQAAM4ydU/adnPrvE3wfPPqS5+T6rNWN8vsMN83slkTfbN8wLt81z9iPi3PdqSAOrl+lzVO+kZc+hmLWk8vDd+nG1HDz7VKxw9wuUBK/Lzns8JeunL0IAAAAAAAAAAAAAAAAAR0iPnF1rnEv0/Hj3z7wPNZ6/cSfzj6FUbm0dFSv01V639L+dXPi0UpvErG+BdImBAAE3J+rLjrjJnfS8+gCFjbZi5+SSEf56cbpXI4dFtpQmoUEpF2OWSsXY59hlfXzy5fLN8tv1in3SVFSrO2jn+dXO2Oxbd8uzuAAAAAAAAAAAAAAAAAAADkof0evVzXj5TesdJoY6Yg53Fnyz6PQpnfK4+Pbn28Y2DW2DW2DW2DXn2rGQHOduzVtg8+gK1tg1tg1tg1+87TXn2Ah688FlQr81KdONn6WOfb3XuSj757UlatY4JYgAAAAAAAAAAAAAAAAAAABjIpHJeaLX0nd89+ic+3kTVYq3075lvl9K21mzY6AoAAAA546IuUr9lj3aN68HfX7Ann1GyZgKABnZ49gAHPRJSA3xmrhW4AtPHCXFKLYJPNgAAAAAAAAAAAAAAAAAAAAAACOkR86lZ+oH0z38wsmOtvpszoKX9J+X2fWLaYx2yxkAAARskSK0y6yJn6Zz3MpKdPdLDTOv3NZecrkA9HrIMefYjO75tcR9hrv03py86SPfZjlNYPeejjAAAAAAAAAAAAAAAAAAAAAAAHj2ISPtYqXZYRVIX6DQK+iddKu3Pth49zQAA8x5x61Wb9PjqM559h0vWDx7zHHVuhZlMe9exps8bAIas8NkNSPct04y9m2RqCSPUXu0jfokTn5gAAAAAAAAAAAAAAAAAAAAAAAAAAQE/g+cX2nl+j41befbJ4X2DHP06UztxlWY+LZn9ED0WboqYk7KTM2vUuPEBLJ3bPG3PT1nXsGvZqTg+e2iA3y3Xnxzay2IAt3H812F/Uzpi3dfJXSb91Gwnar8udIAAAAAAAAAAAAAAAAAAAAAAAAAOCj/R6zXu4fKr5jpJbtXvO/QVq26zYxmBrPW3k92dXnOwyeF11S5abmAnals1i7ITvzvrg5T5lc8n0il3/fPVy+NcaOHt5jVWfqEDUBZZOKIvltw0Uu90k3XCq2qDn6Ac50ANG4yAcZ2MZAAAAAAAAAAAAAAAAAAAHn0KPyXqiV9F20e/8+urGvM1v8Z8mffjYrHL1mPerpTz696D3l7NWzbg0Va25uaRMRuneOmpz0fJbJKJkrPG/TCHuw0C6U+c/QvnhcPfj3EoBSbtSa7JWBtsUCyR2KmKp9A+elmm42Zj5/3cE9VigZ/51EvEWaaqkzcJ7O+0ws1AAAAAAAAAAAAAAAAAAACFmh83uERDr9R08nbjr7wzL59Y8G7OrYZ36t668Z9J69+MnrV7wmcbKTZyRXJZt8oLfOcGdyMxBz0qt2SB3ziLr85+hU+efQvnpcPezXEoBSbLWq7LVVbVFS5+jnLt82+k/Nqt8zDTMfPp+An6sXzr6L87LLPwE/FJ6ebpq2iAAAAAAAAAAAAAAAAAAAANdGvvJVH+h/OvU19MxHyXPrp36vaetO/yuz342j3q2mffjyefaj3PVT0tvn0WrGUc3SMZBzdI+dSktU6ufPXJ4sMWi4tENC9RIwNxolS1qpF3ipc/RoLr82+kfO6tczT5eKvPwXdVx+d3qoE1P0OwkH082C8MZgAAAAAAAAAAAAAAAAAAAACqRXfdZr5pY+KIs+n+/l8znd0Q03nXnZn2u7GiKsmeGnwmsSEftu9zXumz1ItQQAABw9wqsfeoSq729MoeJbn5Ikq5MRZvmdHkrHRyW+tkNMogJ/z6IXRYQ8+uQr09W99TdJsPg6LBULeBAAAAAAAAAAAAAAAAAAAAHz36b8u+k56dUPLs7okP9V0ax8wXOL1mGSHpIdY5SWlWO5dc1ydZnpBVK10vfG8i5AAAAjIyd6Sq6LjEFatMDIVAXmj34ifMxmOKOkO0zw91DPOJicrrEK5YxW82MVPunh59AAAAAAAAAAAAAAAAAAAAA8+vB87+ifOfoU3JjHUAAB0eNh69+PYEQfz36P8AM+nL6S1bbgAAAABUJytHRJQ1hqpfQfnX0I2+PdZjtmfm9zOyk3CmVJ2OqWIlXJUos+YKJr6G4+yAAAAAAAAAAAAAAAAAAAAAAGrboPnv0H5/9Bm5MY6gAPXneegevfn0BHB8r+u/I98rz3w8xrAAAADj7MEXWZ2IrTZq5NFX+hU+6CKlYqKX9I+b/SKzQ75QyXstassRNMudMr6JVLJGELeNHRAAAAAAAAAAAAAAAAAAAAAA2c7r5++NzaF9F+dfTOt6BjqABno5ugyD368+gB8k+tfNNYkrBVbVrkbvPn3rHowAABip22rHvj2ddTfRXeiJqK7+Apf0j5v9IrNDvlBJmy1qyxE02402rbOatsHn0AAAAAAAAAAAAAAAAAAAAAPfj3x1545GL46pP1D579C9QM9AAG7TtNgPXvx7AFHvEFc028fN7dnnMbHnzb8D3cgABykTF2ftqq+rQioxH0XRVEne2XPnFp3S5qpV88FAtKYiEqv0bQUif9S9c/cQAAAAAAAAAAAAAAAAAAAANRtVyMLtCSevw9Ya4ws166E0AA3augGD371+zLGR49j5Jb+SWnLlkOitc084e704AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAANdRqVrXiWNHcE80dfzu0h6xn1aDQADbsxkAbdW0ACODgk4jjJf1j1vnS+H6HW/Tjo6fnlnJwQAAAAAAAAAAAAAAAAAAAAAAAAAAAAA0+qTTlTJjYAHvr4ZPhuwjl2DvAHrzsNoAGzX7PQBiIfl5ZDzZlR7+IERQfqsaVW0/P+8uTz6gAAAAAAAAAAAAAAAAAAAAAAAAAAB4zTTXx4maz7AAB083Jzt/c3T4vSHsyA3ad56AA9efR7A07ofkof0SCsueYezmABwfPfqPEUW5UPoLu17IAAAAAAAAAAAAAAAAAAAAAAAAAEAcUL5mK97QAAAcfZg1Xv5r9G8Xb2NbDtPW/VtAAHrzk2HiPNX6obzTNj1e/dw6t8d6qQaN4ABw/O/qceUK50X0X9zdMAAAAAAAAAAAAAAAAAAAAAAADSclJ3+639wAAAAAaZPi2ctTslCZ8/WbYz3uzbo3gUEDiO2rQvi89lj7cea+Wce7kZD34Hd7jt51AA4Pnf1OPPnt4om8vjVtgAAAAAAAAAAAAAAAAAAAAABS5SsV7mte4AAAAAAA8zsJM+TerXy6tWzyvyjX2fXHyrWfUYigdVkrAz85Mx89n34euph9HjlgZYGQAeu3gEi1bQCJ+e/WK4Vu6fOLEWYQAAAAAAAAAAAAAAAAAAAA4+ujnF36JagAAAAAAAG/QynNtem/H07tHd52i89z1c9exsxdW/wBafJ02asO+A9GWMgAAABv0CRcPaZzgUmt/WPm5Z5GhXuPQAAAAAAAAAAAAAAAAAABqISv+LBWvAAAAAAAAAALNBz8btWNnk6bMe9vy+/Nq6dXr550Ze7kHfODJjLBnGQAAAAzgd3uO6jfxdo+U2Xvpx9BefUAAAAAAAAAAAAAAAAAAK3YqXXZ726QAAAAAAAAACVk+TrGcI29fH1/D9XJ496/q+fI9GWMgAYMgAAAAAA39UdtO2g33nK1N1C3gQAAAAAAAAAAAAAAAABEcfXwVgAwZMmHv0anR6OV2+jgSXsikv6IZN+iCxYfZW82XMY9sxs6nj4Hrx60bzxr2Ok0eOzj+jxD18wAAAAAAAAAPXVxiHlXOdYAAAAAAAAAAAAAAAAAOPz3Dk9dI0+/YxkAAAAAMAZAwM+9frne/lz6+N6dHXo31z+erxqeefZr+hxD1YAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAwZDGTAMg9bN+j5Pdv5OvlrHrmzi9PD38XbPgfY84AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAGDJgyYZGGR2+uHq+H6te7Xs53y869zdy+vH0eIezmAAAAAAAAAAAAAAAAAAAB//8QAMxAAAgICAAQEBAYCAgMBAAAAAgMBBAAFEBESIBMUMFAVITE0BiIjMjNAJGA1QRYlQpD/2gAIAQAAAQUC/wD3sY5S8LYojJ2g5G0XgX65YJQUf6w+8pWOuub3AZBKNlMYBiwf9UawVBaum70kPNBocL1ttoVh7QcLZunPiFjI2T8HaFitgg8iYmP9Ke4ULsPN5+nBFEd6XsTNW+DeDrSU4zaFk7GxOefs4OyfGL2YTimrbHv0zEZBDOGUAFp5WGdoARknUWmZ8HQuPC1Cs8zqQwr+vjCvUpw20zw+nn6Hm3yruGZiauxyJiY95dbSnG7M5w7Lj4+IfT2LAmEjUiAns61aHbK03JmZn+vTtlXkCgx92e9aIsXmt9KjQZbJlqrrRsWW2D/t0bUoP6+63LsJwyI59HW6/wAxl/Zcx9ARkpTqrTc+FoVnTqVZ5zXBnxNMZ8WHPiipzz1Es/8AUMz4bVbjtVaXhDIz6Orse6bC34Xp62nNt20vQXoVab7M+TpU8LbCoXXbDvSTcsIwdot0Trq9qH1nILvGZGUshyvcbb/LpmZmfRWBMZeYOvqdwjJkuiimFraObHP1hKRmvti6Wa5NoGLNZd2oZ8vcdg7xbHpadQqXYcT3dqlk0/0tQprTcf8ARU01Gq1X2IXaTKh9tE/Ds+4WWeFX9JYSw9ycIT3KEdVVYZMP0IiZyK7pzy7oyRIfR190WhsKZVG9kfLALrD2/bFyr+lok9dm47x7PbqK487tkrT+4RkpRp2THVqquTuoHJ3VrI3VrB3ZTni6uzjtRMiayWXdRaOwrPUSW9lfYMVFe0p/t+4n063+NpO1YSw9scV6/dRoMtyVqrrosWXWC7kPagl3a98b+vZUntUwls2IDdp9sTyyjd8T27c+nuP0qfbo1QVm03x39uuo+Nl/Y+LHeKzLCSweGu2EDGzpTVZ26R/Jt1E17PdQseOr2zcR+n6NQPEs74+q521f0NJ266nNt20uQ3vWsmmqhWpLZuoHA3hc/Bo7IbFdlZuuaN2q1ZKZ2LKQPcjDq3dTd4L/AGzaDzqejph6thtC6r/be/S0/bYn4fru+qAayk9zHs4AZLJkxs9dXbKHbxUT3Uf8jT99Fni1vanvWiLN8nD6OgjndtT1We3efJXZp0eNc2FjzNru1qPHubx/iW+zRHytl8iR/k6Pt/D58n2A8N3dpz9qu24rwZkZel+HvuG/NvYP1/EH7+xX+Hp+AxJSxHl44/h6P8h5SbuzVz0WZzQfmVPbqC6dhtx6b/dq55WvaLDoQoyky4wHNff+H/5D/d2B+78Q/wA3FC5a7eMjxsUsmsZ4erCZmZ4/h6f13j0O7IPkvPw79S/d2UZ6be+Hld7td957RtHdbuxQ89Z3/h/95fu7B+u//fx0i48d7Ja7FiOqpmUmWeXGusp5zmsf4F3dI8K53ar9DW9tX7n8Q/dd2sjnb9nMugCnqns14+Jr+/8AD387Pkzt3fzTxH/G0maWtBFftTasZXrhQQ5puZxrkOzotWSmdiFE5u3Ma9XKmsJoHOrDGqQUZRjqub+ed3u1A/q+z355VO3Ql/k2F+C7u0Bcrtj5P7b5der4R883BdOLGTPaMirVzV1AELtorT8Uo2k1XhcEtNLP8fbqtU3Vp4LWTTrpVqkPaT3aimLS2V4rTM58NKvrvbU+u93a+0CMiYmPZtpP+L20m+Ba3yel3dqD6Nhfjpudpl1abhQDruWm+PY0wDDbDZc7W1PNP2t2HFy54jXCtdm/zHiMyM19wwY8bUvzlpwwttWQNiwywzL0+U1PZpYhFUikp76FuUl7Ntfte6ty2OsKOU9qykD2nKbfaJf+u4VS6OBn4WuEZMrToqV1KN7I8tqxsWWWTiOeI1NhmGGurYy3M5PzmBKcmOXYH7vxF2LCWHtSirR9HWP8RXsuyjnT7tfZmrY3VXkXcR9aO0S/T4RP5McfWaT8uK1yyZtwlf1lVDlkX6tSG2bNw16ws5apGFswDG7C0zCmSns20eY13HVVhrqtvKw/0abPCs+y2x6q3fqrAPTaQVd/9GcmflgNJeTMlOQ9gjPz9HT2QIL9FlQ+Wa/WZtL/AJku6I5zPy7AnqD2T64Y9BdwzIzZKNjS9h55V3EiHxKgvLuwbb9DWh12pnnPGv8Ab+y7IOizlcIaZjIF2VXzXbYAQZ2iMlIa+0eBpnTg6QcjTV4yNRVz4XUz4ZTz4ZTz4ZTz4ZTz4VUydRVydKnJ0kYWlZhaizGFrbY4VZwf01gTCeEa6l2Kjkr2XbL5p4KgNmpyjSfZ1fl4CBHKdU4sVra68EYCB+n9EhEsKnWLC1lQsLTInC0pYzV2gw0sX6dXWWH4R1dSDmm5nFcdR+yOcCRfsWnkkRcRKRJFyveC5qmp7qesNuKUtA8I/tFXSeO1VZkW6rKrIjngVGng6m2WRpbeRo34OnQvIfrKeWdu9uTPPglJtNkDBZrV9dr2NzRStzScfdU2Nithv193GUJwhkJzXa+FR2D9f7EcbVcLKXLJLcgijPHbnjNyZmeylSZbm29YBw1auhPse3ZzP0uc5qKccu0P7Mdm5qeMruACMquqFY39j4g8KqZe2IiI9j2f3fAY5y1DEz3U0TZfygY7Q/vbSr5axwW1U4FSk7BoUFZOyqVRtW3WZ46xcDV9k24cj41brER06yzhamZxtGwvJiY46ZHh1+6Pr/d2FaLVafl6BAQjlYeiv7JtiGEeilctbygB7xn+7Obmv4VjtrVH2SNdWhjWE06ivFf7LsGeJZ9HRo/P6MTz/u7Cv5irxEYnFsqJx+zsNHhrEeGv2V38vYEDMlCY4x85rJ8vV9KPn/Sj09rX8C13UKnil7NbHosehqK/jWpnnPFtyurD26owtwefF3YO4LF7ZBYtq2x9M+v9CPU2tfx6veuw1WVL0O9l2yefo69Hl6uTMRDb0zjK+ws5GobkafPg2TpzwtVYjGU7C8iZGau0McUwWDE8/WiPW2deK9rilDHkrSlhaUOVuo2qWUX+On2O/ahQ9+sr+PY4TET6LUKbj9TGLN9B1awFhcT6R2UBhbKpGfFqmRuKuKuKd6uyq+ZrcKGvKzilAkOFlI2ElHItUfKx7E04UszlhU6p2mlpQ5Wqbq3YMSU06sVq3qsWDRKi2sxDhcAz3P2NZOM2dlmSjY2cDS2JwNIOBqagYuuhfr7hIqt6vX+YyIiI4cuGwjpu6+eVz2LbHyTmrT4NTJiJjZa3w+EfOdTQlZl+31+kertYkGYKlBwj+kRQI85v3xiBHt2E87uujnc9i28/qhHUfLlGc+G1o+FOoXB2BjlBTzn+jH07o/pbux4aNCrqsZFhEzxIoATLqPUjzf7FtvuEfzz9Znj8ih4FQt72ebvZ/wAP/wAHCfll1/mLOpCU0H0XWs2Ou8mGleTa3Dcu8KnmrX0V/YtvH6ip5Mnt3QRNd7vFXwo0zuH8CflhUodWTNh3wJ+XahU2elUrFaP4O7Pgzsdq2pVlLXMuL+BP4U6xW2/An5brFVd6X4f/AIOG5seFXUEtaIwA5+IGZoB5VuG3sePbUuWsEYEfYtuP6WKLxEcb97y0v2DXp4/hz7rNp/yGo/5HPxF976Wi+64bH7HPw59rP0L66D7/ADe/8j6X4f8A4OGwseYtaJPXZ4bF3jXNerwaebGz5armpT7JfHrqZqT66PF5y58VVQmY6ZRSrNTlWyyqXxe5lajXtotUkUq/xe5lBIbNJamnAz9fQ0X3XDYfZZWvPqj8XuZ8Jpzl6uvXI+L3MpVlbCva1dRdbvqBDLPwuplesutGbex4FTNUnwaebB3gVNZX8xa4ba15iwoJYxYQsPY5jqgxkD0Tv1C+uF+2v/P/AN7IPDuaZvNXln4aWBGa6ygKOxep1LydnNKY1apW60j5OzjENVHd5Z+aZTF2eF+JKn5WxjFmvIyLdblt2BZp+Ts5qWhXpWrKGVvJ2cYliu0K7jGlWeNuOO1sePboo8xZ4bx/iP1lXytfNvb8BOapHKPZdqrofWbKH84MOFlcpsKPxVbtWU3eBYzd/b8NR/yOfiL70P35+JP4e4f2x9ezffccNB/yGb3/AJGj97n4l+vZqP8Aj+OxseWqZoUdKsuWIrV9VSkzyy8K6bDje2qiXtiIGPZb6fGr5pbPWuflw2tWXBp7HyuK8atmrd4ta5W80HweMsL8J1R/lrH/AJAWbC351ozyn4+WbHYzdDso0otB8HjI+Udt6hFtnwUcnKNryj//ACAsvWfNvQzwnf8AkBZsb/nuNCtFt3wQcqI8sjhObqx4tlK5axYQpeHW8w/HOBC71srbYiSmpXiur2e+jwXKYSWJaNhHC3r+o6tmTzYp8G1rH+Da4X/vPS0n8XEfp2T9J+voaL7zjH12VjyqOfPNDX/Nxt211At2mWmfXNfU8KPaLSfHSUSM6q35dxRynhMc826fErxlN3j1s6RzoDOgM6AzoDOgM6AzoDOgM6AzoDIiI7A7ugM6AzoDOgM6AzoDOgMhYZ4a8gBjsH675pHdWEsZXSKE5Ec82GzBGNYbTWsmFTpCj2vZ1ufDVW/HVxmIKLCvAdpndLfXAubQ+uc/n/QfZhbd3/yGjq8Jnlm6vEvhVosbiVAkfa/rl2v5dimEplZw2k8d0nmIFIGpkNX60F07Mfriz53cmYifVJojKrE2dtsa5WdtAipdnaoTmuayyzw3XXV6K0+3vSL1tWSjo2iqNGRaHA1w0GBK2aV/MfUk/wDIzYF4NyPrlU+rbZdPo9CO7eWvlrI6r+xrNOydS6zA1jZwK4VqH09xuVosAYyJULxVDWa3h0zkRyzeI5NS0kthgGHp2xbBjbaWX1MfU1dqGpM4WGn6jKyVxQpqtJ/qXnhXWZywtCmTuOnm3AjqO3P5uADJkcxz9ut1BsQ5JpJLmIJG5LB2tWct3abq+aVo+LnLlkel1T1s+QXKLFMJ927FREVkZBx14RQIx844xxPq6cmOeX7ZWWgMmdBA06nCoPM2F1Hw/jT7gQicM1qiydY3I1jsXq4zY1RVAFIkts2a/owAiR9fLFL6BxEslfyzl84Hpn5YYc5/7EICOEdn5/F3VzpHNLT6ssnz4z+ijgkOtlgupnurAhgNCVM1NnwnZJjBd0/UhEx6WY6G9eSJ4ItLsderKxV07JfSIGILI7BKCG5bCvXMpMtbRK41hioeCV+HDT8QuC/0ke77RHUGULJWVd04QlGfnns8VQyexqDjNwmMZuHlkDevSFOuuR6eXVPmAgo4Rx6x8S7EMp2Hm+ddrztlJAleABHkCtGNYTJ4APWdovn1DBe7T84to8B1SxNZ38nES6p4mcDkTzjGoazD1ZFnwfI0oYOnrRiqddXBqxaJEdZqbEYPOZjBmZngZguN1d5Rr6k23SQgGSMKi1uJmJYyZGw0cjYWIwdmzBfFWoe0HFG5rlWlMB2wnqRDYD3S4jx1T8p1FvoLBMWdv6fidnOM5dQxPIigvE4OUDgctlQk2JxLxPjyzZvQCPriE+UqKVLMO5HV5WGTZionF0RhU/WvRZYXT1g1cv8AmrjVa50ylQJC4PRY1Y9Vj3bZ1vnmst+YX0yOc455HBc9Q8eU9RcgxLIaueol8CmYiflnJb12kTWNLueJfI5HS3LDwrqtWDst1i/FvFHiv2dnorV0whVyz4A66i0imqZD8Po18q2EQmyZHf47H7rUfy4xylzwJygLg1oKiJiY4+aR1R849omImLlea7FMJTKzAsL6B6zmRBnyGJiYLnODHIOExExERER+XFjCwghki5iA/OI5sD9pTIyN+lNfEu54Bc82KifHQXVrK8VZL8sQHXk+EoY2gS2bDJxxlK5+ur+0d99x2P3Wo/kfZLkRERat8llu9C4kpItdZacuOQW5xuKjZYssbshHJZbtgQyMptNTkbMfDTba+37PYTD1MCVnrrflXcoyerzKZmcMugeuOY9XAOth50xB9I88LkZnEkPD54McigflfpTXJTsc7ngtYBVrHjQU9WdU5tC5VdaPVZxn8c/XV/aO++47H7rXgbCUsUhswgLGsnlahQRGar7fH/J+niODP36j+JiwZFxYqsUUDYYrXwp3tGyreKGae3zg4LmEzzkRkxWAkRTBEXSH1jI6cmIIVyMhJfqR885fKOcD8wIDg4iJGdpf8wYM+RliAnJEgCJ6hzb5ri6bWM/jn66v7R333HY/daj+XNt/Prfusn66r7bLH8+n/bjP36j+LNj93qfuPathW8E4mYmjc80mZkQ5F4k9XMvnCJnoPxOrIET4BBQI9XSIisQGBwOfQcdQRzmNtsPE4a6nyy7Sg4Qzknl5jjth/SEpEllBrZ/HP1oBK6rvvuEvnzex+61H8ubb+fW/dZP11X22WP59P+3Gfv1H8WbH7vU/ce1GAsCygkMUwlHTthcAQgI6YgvGDw+fPJ+k8wVARn5+vqgZLq5nMiOdE9X5urabLnw19TxOJISZR8o4WVeMkxkCo2vBK3YjwqdGF8HffZduQqNamQXsfutR/Lm2/n1v3Wf96r7bH/z6f9uM/k1H8WbCedvU/ce12UDYWYyBrYSjpX12oMImemesvkP1EhFg8/nzxRSYkwAyZnDkoEjgA2G0l3ChV8c/p6F+n4mfTEOJBr2Y559HJ90Je6+5sUKfXjTha3s8ZlF/gtzbfz637rGR0soW/AyPEuZYDw3a6wKTruh0Wq5pZXsHXKbcvC6jwGUWwmx7YpI2bz0mhmVNoa4U1T4Dq5QvnkuGGwPThxJR1zkrGWRHU+3sE1st222ixNApraefSsVVvhusOMKo8c8s7F69xZXoLTOfXLdDKdKFcNpP+TqV8zy9T8bKdDp4X6njZU1/LhMQUXKYgdSuNcLqPHTMSM6yxzj2tJ9Gzehbxt0G1+AlIyrZ2F4raoPAatkGMkOS5asduK4ZZ2dh/BazYdHVCrNqXTr9RP6vp2NiKijaniryWZL1RCrfjPsWQRAX2tJUskXuhC0pO41YQsOElA9tl8V1ruyDPijMDaTlvy9gNYoif7Wc/rRPOMsa1D8frLKs5cuMNZGS1k8RGSmrqGsyvWVWHN1P+Bqp5WvS2JkFcNZJCesZGRr3zPg87DOmlUHm5wiCFTc65CmRHZLwa2tFhRlm0FeHvN5KJnXxdUsWGRqs+FYesbGV9cIzEQMe1l+6tPVW4RMxjVKdDdQosPU2IydbajI1lqcDUNnE6hESlKk9m7+xoF02/Serxo4bJ3hp1cc7O3n8tb7iY559OFpHmBiIiMufcaiInPLJ6/c5+mUJ6qXoxHLI7NzH/r1T0t9Xalzsauf8nbR+kqeTY+cYRQAr2KibjnAiLJQbtc9aMTZW+eD7ik5UtDYj28/2ZrPsPQGOEdm2jnr8WXUv02XkBN1gudrp/wAzafaR9V/x5tRZzzXg0VW63mRcHhsp1fM5Up+WOy7wFOuNdlup0rWwllWfFhftzP481n2HfEc+Mdl+OdLKM9VT0rKZeM6+v02kTXZR+72f2YxzII5Bmy+1z/rLn3On4bP7XFfxXqspKkTYf7c7+HNZ9h3x9OEdjo6k5q551fTZddlq15gaEc7e2ZyXr0y1/DZfa5/1lz7nT8Nn9rkuBFf9a9iUgkfbrH2+UI6aXpR2uHobp5/J6m0VAN1a4GGdV22hQpXw2X2uf9Zc+50/DZ/a5Vqc/bxyJ6stfKtlcelHpR27Qei9qJ/Vz5BhRER6N2fM2nPHpXcrVw+KRgbJM4tgNjZfa5H0y1POxp/rmz+1xX8Wc45+2D9I+uw/LXCOo/p6A/ThHbvlcm60ui2H7y+p/T0Lt2IxVWwzI1bM+Fnh61wwYEErYa5YD7FfKzLFgHQZBYrsTKzNcrN9odmLWDMSMrsNXiLjnwlHTPtgTynw5zZlzq64Ou56A8Y7dyrxKQ8uqm9ibHhzzOeZd71k0VVUq7WqW2Fa9YM+uFrlS0YgYwhgoHXqhvBiltgtaEmtYKH25TAMb8n5PSBzf6A/ThHaQwYtXKmpSF7Xtf5SPrH+isYCxds85usynprDsY8WlqV9FTvj59kd29RyPWJ8Kq5IOBo2Nble2p/+iWtgIYZm0lI5cFfqIFkFbGIEe8fStqh6BbHn8mIKL+tleV77F4h63x7+Zisbd0n4IyUrXAcaLRjE1RG1/SsH4SgRE3I439bDc5mo6l+Ge/NYKgtWSsGAScgEBHEPkenZzZ3j9fS2nWVX5C7sv0RtQwCWdK90Z9Y96YYrC1YKwYBJyIwEduv6VVe8O6OyfptLzEMpl5hfbdphbBqjSdK5KJiYKPeDKAG5ZKwQBJyAwEd2s/N6AfTtjsZPIbTPMWUB4au65UC0uwk67Kdsq8iUGPu0zERetS8gGTIBgI74cVa3XeuwHdH07Y7LNkRtDTpqs+hbrBaXYQaG1LRVyWYsH3XYW/EkY6pWEAPoWR5jq7Hgv7Yjn3xxMumFobXZrglrYmYyG5E8++3VC0t6TQyrZOuaWi4Pc9la6YxK+iPS6YW/qjr/AOuId8cJnlmxtylGoNjGgIgPCJ5YLInvuVQtLeo0MrvNB13A8Pcbtny65mZmuvl6jA6xWbH0qVsbMRxD0OfLGXBt29qwm26dfy1btE5HBKC7rlULS3KNLEOJDEOF6/b2sFS3tJzEL6p9VZko69xTHKu9B/8AWD9e6xaTWi7sGWs1qSbZKFEyZ5z3izuu1BtLaslHWsFXYsxYHt1+z47Fh1lEco9aYy4SRWsxKsnbBOLt1zmPnxNyl47bVwyxtbDcmZmaevX4S1rUn0hKYwSgu3YU4tLKJGaNmUHE849s2dnlGKDwx/ofdVq5eC/ZVOTDUwMgpjPHdGSwy4LrOZi9Yc5XpJXJT1T+0PT+mCfPt21LxRzW2eXtlp8IVMyU118v6SWykzqg6XJ6hwkqPPJ18ipXjBAB4hH5YDlkzzn1RZ27al4RRlKx46vaZmIi3Ymw1Kuuf6lGJECmBnl1dkDywegsKef9ESkcieccCGDG7Vmq6q6UOiYmPaNo/lCFS5k8v6n1wY6Rn88fOM6euPDzp6cmeeR+T+nE8sEoLjcrDaSwCWeqf1D7Ow4WsyJrIX5ZX9SqPU7hzgsEufA5jIkR/rAznx21TxQSyUtEoIfZts7KK/DGZ5z/AFKUfLiv92FPOf64Hy47Sp5durb1J9lKYEVAVyy0+uf6tWOSeI8s+uHEDP8AYA+nPrlhI2E05Ktd9l2bOmvA+XT/AFgjkGAPPgz9g/tOZierCjp/sQUxkMjNwmMEuoPZGcjsTPOe3lOdBZ4R54Lc8u3PKszyh55Sc8pnlBzyoZ5VeeXVngrzwwzlGcuERznCLpyS6hH9pn0zyhkQPKP7JDBjViRT7ISOrPKrzyys8BWeEvOkf6gfuxv1/wDkf2t/cM9M+L/rMfLCmeQnExMBAD+2Rgs8MMIen/WhnlPNeT09I/tkojInnn1yflP+sdMYyOWf/I/tb+5X1wv3f6wJdXAh6RH9pB1T8gGD+U/Of9YieWQccjmJAf2nEc+QYRc/bP/EACYRAAICAAYCAwEBAQEAAAAAAAABAhEQEiEwMVAgQANBUSIyYZD/2gAIAQIRAT8B/wDaKhQMiMqMqKRlRlRlRkRkMhkZlfRRh++g4+/BX6U17yVekx+5Fa+pNffuRVIbozP6P6P6M7FK95q8UrKa9SnjFX5uH4J+DkjMz+jXzmvsjH1kNWUJVuaYWWWWWXjLV17MkPaysqtmPA3RHUkiPBN6eouMNZCV7MecJ7CjZFUTZFaE/wAESd+pB4QOGOFbChg42PyirEqLFqzgivsk/VTrBrW0T/SOqJKvKMVXhlXihJLBsgholKvXjL6waIunu0UUVg2LXBy9mMrwmtSLtecsFsSYnQ3ftqf6OmiLry5KLrQSFp5SfQxd7S8GN30KdeDwtlyKkzIJ+EujhL62WrE6MxJ10sXeD86vB9KnRzsNlkVbPkq9OlTo58m6G76hK0aozllFozfglZJV1EBqxwMrNTKxQwnz1EOdifPUQ52J9MlY40Q2J4OHSQ5GqiQ2JcEeR6J9K1aojxs5dSfSpW09p/8ACf50sOR7L+66aLpn1sWP+V0/xvQfm6vqIsvTyzW9B0upgXpZnM5nZ/pifVJ0KSHDBKxLLqOWlLrLTFCL1JpcEnei674uCad9atRRUERdy0Hq9D5IZesjySaloQVMcHmtE3Lh9blcUfG7Zn/qj5uthNPkX+tB6PQnO9PW/8QALBEAAQMCBQQCAQQDAAAAAAAAAQACEQMSBBAhMVATIDBAIlFBBSNhgTJgkP/aAAgBAREBPwH/ALR3K5SVJUqVJUlXFXK5XBTwRd6Ad77j6TT/AKa71Gn3CcoC0WitREejKn1JzJjvuR7IUBaLTvaUT6xQMKUdfWG3sjxz4nb5OQKKaPW0CJjwnbJvgJhEpqKbkB6jsnLcIO8BdkDHeTCJnI6DI/SaPVOQP4TUdCmnuJ7J7SpyATjkB67hkEfSGYHskZNREd4yPgAREoCPbtQTh4IRKPcBwJ84HAkdgz0WiuUdg4Nw8IKiVCA4U6eGcgeOjI6BMmNeFI7wJ4kmFurVGdq2QM8Q7K5SFopCuybtxDvA3iHeBvDVH2CVTqFxgiCneBqJjVNxEnbfhMQJYmVA+rLU7wBV56ZhMIe5gb+OFpuLXlwGhR38NSpaNN1hjoRGvCvdYHMP9Jsxr4XuDXgu2WHGhd98LiP8ICpvdNrt/ATCuLi1ztuGqtubATXF1UeCsCWGE0iq5sbDh8Q0mo21Unl2h3He5z3NLvwhtw9Vtw03TATUJIjueIaSqYc8NbEAcTiB8muOyb8XWH+larVanuDGyqgcQC7c/jinNDhBRovb8gZhMxM6uEDKpUDE57q/7YEKnSIdc4yeMtdT+MS1Pr1qRt2WHqOIvIkqlTLfk7c8dj9akrDub0xHGudaJVWs/EP0VVjmUod9qn8WAuGn2sLiOrI+uMqtLmEBUWPonqDVYl97J/lU8XT6XTcFhqdIC6nxhMCV16dd8bLFtsbH8o4YdDqL9NcbiOM3WJwrqTpZsqhc6l8vtUxcwBx0+lhMPZ8vv1v/xABDEAABAgIGBggFAwMDBAIDAAABAAIDERASITFBUQQgIjJhcRMwM0JQUoGRI0ByobEUYpI0YIIkosFDU9HxY+GQsvD/2gAIAQAABj8C/wDz2bb2hWVneishH3VsNy3i3mFNpB5f2zIbbuC3qoyGtNriOSlGExmFWYZj+1a7zIItGyzLqpsPMZqu314LaeJ5C1bEMnmVYGD0W8PZd0+i2oY9FaSw8VMGY/suu70GarP9susIBMj1E2Okqr9l/wBjRtOtyC+HDA5reA9Fv/ZWhp9F8RhbyU2OB8ftICscD6ovdcFWN2Ay1qrWlx4K0CGP3L42kf8ACteHepKsgh3+C2dDn/iF/QN91Zoz2cnrYnLj1Ih17NeYMiqsf+SmLR41tOmcgvhtDeatiOpq1zVy1arGlxyC6TTIga3yzVTRIIPG5WxS0ZNsUyZ/MSNrMkHNMwfF5vNuSkNhuQ6qzZh4uRhaM0Pi4lVorifnJO7M38FMeK1Idr/wpuMz1XSxdmCPuug0XYhCyYx6mTQSeC7OoP3L/UaYxvALeiRVsaFP6ls6DCX9HBW1oMJbeggcldFhL/T6Y2eTlOpXH7VJwIPHqugd/j4p0UM7eJy6u2yG3eK/TQLITbDLHqPhss8xuU9KjdI/yNVXRNHbDGZW3FceHVfDiuHBVdMgNfxCraFHH0OUokMt6iYvCbEz8Srd42NUzf1TWNtLjIJuiQj8R28dcNaJk4LpdOdbhDCqQvhQsm9fMEg8F0elNEaH910ugxB9BRa9pa4Z674XqPEjLdbYOriabFubY1OiOvdrBjBNxuWD9KcPZF8R1Zx+SrscWnguh0sBsXuvUnWtwdnrQzxl4i9/Dq2sbe4yULQ2XATOv0zx/qYm6MkXvM3HqbArIT/4rsX/AMVaCOp/SaXtNO64qV7DunWa7MT8Qa3N3VmKboYUSJmbNZ2lRuyhflGI70GQ15NBJyCr6Q8Qm/dWAxne6lC0ZrQrAwei7nsvi6OxwW3D6E53Kvo0URGqq9pacjrnRI++N0p0N+8NUNIDmhbJ2sj4fCHPq4sTvRLvxrBjbyZKFoUM3CbtezZh4uK6PRWiJFxeVOI8nhhr1oby1dFpbA12D1Pehm52s17TItKZpsMbQG0Naa6OKdrA5+HQvXq9G0fhPWMV27CE0+J5jrdPH2YDfuuhgDo4As59RssceQW1DcPSj9NpG1CdYJ4KbbYTt06ztHfayJ+U+HgLuWvI77b+PhsM8eqhNzcFV8rdaPExiGWtL/pi1xXQQbIDMsdcMYJuNwQi6Y4F3lUoEABvFfEgtI4FEwvhxUYcQW/lO0OMdoDZKdDde0y1Q9t4M1A0tuUjrtdhcfDSfKeqh8LVGPGWtosPzW6zYDe1i2u6j9REHxX3BF8R0zSHMMnDFF8vjQk2I29pUPSmXPEjrRoWLLvz1DDiLD4XN59EWNaGsPVE5NUU/uOtorP26oJ3WbRT34XDlrw2m68roxuw7PXVMPCI2SKew3w9aJD8zVEZ5XS14kP18KqttiH7IucZk9XFP7E/nrQPo1XRLokcyFMhaVKIfi+QYc9SKcmp7jeXHVMTBjHGjSIeB1oXGxReNuuOI8JLz6IucZk6jn5GXUR/pR56o5qDlV1GQx3jJM0du7CbKgMYJuKqMk7S3C13kUzqRRm1PacHHVc0d6+iPyCOrBP7wp5t14fhNQXM/OrHdk9vUR/pR1tH+jUfHddCbNPiG9xnR0rxPSYl3BFzjMm+gRNI3juwv/KnQxxuOyUXgbMS3XjxzjdrQvrCZ9GuOA8Ic7ITRJvOrprMZA9RFH7U7nraI7NuoT3o5+1B0mJuQ7k5/duaOFA0rSROIezYnRHmbjqGA8/GZcUWPEnDVbDZe5Q9Dh+tHSxndFCzKqtbGicZyVbR3u+h99EEfvCAyZrvdkPCIntrPhm57U+H5TLXIzaon1HW0N3pqQdGF0JlvNBrbyZKHoUPLaoOmaRZDba1F5u7oyoqw2Fx4KRc0uyGFAiMMnBf9vSAviMs8wupqMaXO4Ix41sU4J0R97kY8XsmfdSFkIXDUafIJqKcjLXLHjeO8pi0eD83a0OJgDamxm3P14XGxRh+860MeWLKmCDdWmokTzOUTSIm5BbNPiOvcVI9m21xXQwuxZ91Yun013Rs8uJXRaO3oYOQvOoCDIhVY7elbnipvh1Dyl+FOc/cqrosD7SVeI6ZohwRYX2H/nVj6U5FxvPUVHH4Z+3g/wDlrmCe0Z//AAUjeNYOF4M0Yg3YgDxrRGZRAfsaYj8mH72UQ4Ivimu7lgg1omTcF+jgna/6rhnkgyG2bisI2lfZqrxXTP4Uheqz5Qm5uUi5+kP4WBShwocJv7Rb70WAq3UbzUD11Axu8TIKFojMb+q6M7zPx4M7gRrh/dNjuSGkw9x9+u0G+Hdy1nNzpIzongLAq47V137VfIYuKMLRdkHeiHecuKr6VEEBmR3j6KWiQJnzvUi5zp90KekRWQBxNqtc+O5SgaJCZzCtikDJtimSTqwdIGF+odNj2WbKdEdjd1TDhcfBog/b1B0KNiNlOhuw+TlhRsbJzxUyZmiTHVPps6o6HGuduz/CunDwdR0+lbLBbVP/ACqjOxb99eQ1WuzHgskW5HXBBkQunHbwd8cPA6mksrjNVmQdrg2SkdmH5R1DSd1m2fRT1IX0jwYnB1tFQmRdceKLXCThfqh4tGIzCNTcNreWtJoJPBWQj6raexq2o59ArXxCu/7rcP8AJdl/uK7L/cV2X+4rsv8AcVuH+S/6g9VZFeFZH92qyMwqyo71XYn0W1CePT5MNaJuNwXQznHjb3AarBk0eDB+LTTUcQ3S2Cx3nCLIjS06tWmTWkngpxCIf3KtaXn9yk1oaOHye00HmFbAZ7Lspcitl7wtiMPUKxgd9JW3Dc3mOrBLajM3KTNuOjEeZuOo1uZ8FrPKkzYb91aSaQ5pkQhB00APwei+H8SHwv1g+LsM+5UoTA353ahMPotkdGf2qq/0OdGzU/mFuN/ku57q2IwKcfSP+F8Ntd3C1EM+G3hfTVYP/pSaZjOhpwbb4IXuwVd515B1ZvlcvjMMGJ5gpwIsOM3gbfZScCDxoEaMJvwbl4CYb/Q5J0N4k5tFjiF2r/5LtX/yVp1LNmGL3nBfptF7PvPxfTXN7/x4I2Hlb1d6/UxB9A8D6Zo22X8Rr1WtJPBdLpjg1o7q6DRxUgj70huGKkLh4I70plOS22yyOB12w/fkg1tjRYPBNns32tplGhVhm0yK2NNqcHtU42lh/IqrosKZzuXxHegu1A7F1/grImYlqVCBEheR1yvdo7vsvg6RCieq2mexVopMYjafdy8FLO8LW9SCRKd1ENvDwUNO8TZ1TYbb3GSawXNEvBukA2Yn51vhsJGeC2iNIj5d1qL3mbimtwx8GfwsHVOjm5tg8HczvC0alrpKfROjO/cZBVARDZ5WWU9I7ef+PBn/AFHV2nVRymtlz3ektRkLHHn4QZbr9oa4iP3B9/B4g49TWO7Dt1dqKOQtWxDceashNW5DW1Bb6FbTXM+6+G8O+eJG+y0dRsxCqj9l/wBj4KIw5O6kA777TRMmQVXRoTopzlYviWDKclbEYFbH/wBq7f8A2qyM32VlQ+q2oTlYSCqsbbbnig+G6bfnXNbuu2hqVYbS4r4sUN4NtWzGdPiFJ9xuIot322HwQwxIvP26gEjYZaabRPqduG0qcB/+LlcW5g4qsw8xl1e1GYPVdrPkF3/Zd/2WwIh/wPWmQ+I21tNd2zCzzVSG2qKXQnY3c0QcFV8w8Dc84IudeVUbYMTktmMZ8Qttuz5hdqSAmSg3v3u66q9ocF0uiOnmwqYsOLTeNeVau7JqlAg1RymttsQ/UZLadDatuMfQK1rncytiEwenXmrc/alkuli9kMPMpASGrGH7lD8DazzGhpltP2jRIiYOCMWBuYtyokumi3jdHyNaQrZ63xBW4ErZhsHp8oXG4WlCffd9kGtEgLtaN9Sh+BsH7UBmVLLU6eENg3jJVj3RZzUvDBBBtffyTonkCmpCNDn9WoXG4Cac7MzTneUeBt+lQ/qGqWvEwVIboIcOKguFxh+ERfqpmbk+JhhyQdVm59sl8fSJDyMFgTXiJWBMrkWuMyw/aktxiWUVsXnwOGeCaeOsx+LXSUEG9jatLmMcAQJ2rtYf3ToRMy1NhNMi5dpD+6DHkEkTs6ssaQDKdq7Rn3XaM+6dEL2ybQXse0SMrV2kP70dG0gHiu0h/dGE4gkZdXF+qnoxvRPwmsF7jJBouAlRChf5KI7N1JA3GWBNYLyg0XCzwNjsjQx2bRqVGAOifhOhvayRyw1In0UR/qUHnQ36Ord9FMb6aIn10j6TQ/kOri/VS9/duajFN0MfemI7CcgobTfeaHO77rG0GMeQ8Efwtob+2zUc/wAxXR9GzdlOSIyTYlS8eaguhGRNly3x/EJmkRmkxIgm4zT9IgNIiMuM12g/iEY2lCs8GrZYiejP8uqd9FMb6aC2E4AEzuXaD+IXZn+S6fRhViAymbVvj+IQ0jSRWiHEGSivawza0kbXUQ2OuLpLcP8AJEQhIGggHaiWChs95+0aHvxuCaDut2nUyadhlgQY28oMFw8ELTcUWnAyUSD5rRSeShz8woiDA2p8E3i0LsX/AMVN7HNHEUQWujQwQ24uUWHCiMe8ixrTav6eL/FOZpDhCdWnJ9iIEeHd5l/Txf4r4kNzeY1+yf7JxexzRVxFMUNEzJdjE/ittpbzo/qIX8kYcB7Yj5ixpmv6eL/FNhxnthvBOy4yKisZGhuc5pAAdev6eL/FfEY5s8xq1mwnkZgKETBeBWy1DLdZshMh4Tt5UiC25l/NbXaOtdR0be0f9hQYxxsb4NXweEyIO6UHC42il7MjYmPHeE1Di/4lMfhjQz6qYPOhv0JvOiD9WuOWsz6aR9JofyCgfWKIHrqw/X86j3d42NodHN7rBQ6JjhzX6qOOLQceNBiP/wDadEebSg3DFACwDwYy3m2ij9O42t3eVPSsG22/iEYDjxansxlMUBp3mWINrVZGa7Y+ydDnOqmxZTq4L+nH8kIhbVkJIFdgP5JrTDDapnfquNerI5Ltj7KWsH9JVkJXLtz/ABo6WrWsuX9OP5IxatWeCZEvqma/px/JMmyrV409GXVbJrtz/FNhTnLGkBdGN2HZ6psNt7jJNY25olQIkfs2bkP/AJNBiRDIBTNjRutQAFpUu8d7wizcdaE2Iy9qbFbjT02jbL75KpGFSMMDinDuutCE919hpi8+ric/k/8AE6rn965vOh2kHCxupWebcG5qs88hlR0j983cPCSzHBEG8Ko4/Dffw1LRNdIL4f4oY/G40brfZbjfZbjfZbjfZbjfZbjfZbjfZbjfZbjfZbjfZbjfZWADqtxnstxnstxnstxnstxnstxnstxnsuzZ7Ls2fxUw1o5DVLO6wWJrG3kyTYTe7TUhSfE+wRe9xc4qqwTKrO2on48L6dg+qjoXn4jLuI1CDcU6GcEYJufdz+QitylSRl8jBhd6IfYJ3II6S4cGUWr9NCMvMaKzthiqsEvDbNw3IPYZOCEVt+Iy1GxhhYUHC8WpsQXOE+vc3zwxTHZk1tAGfXODjKQreihxT5rOSbCGLRPkg0SaxqIZ8V/C5RNL0g7EIWDAJ0QN3jOZUztv4+HljvTgixwtCrDdO8EIjDMGl0N1zhJOY68GSdAJtFretZDzaTRo0bC406VyogSvMUdd+mYeL1B5oxYUSq+Ultku5vW09oQhb1a/irPEbO0FyLXCRClfDN4VeG6YpbHFzrDzTYjb2pkQGyJd1kOPBFZzLC3MKzQ4qJc1oc20AGaEMnbZ9wjEdc0TWkRvMVNhhvtluWpsfSYoeW7rRcOtEY7wsaJ3lFzjNxvXSSsYE6gBBuVMgpN3R4fO5+ak8SVaG4tKlGhz4tVrnN5hPhmIbbrMaDCfvEbB62rVMpTmncl02jzlfIXhCBKfIS902EDbieNFS2cp0FxNgtU9c1JVsJ0AlxFUzsKtlVbYJINF5ROJtpLsk40/uf8AjxGTgCOK2HFisewreZ7r4kSfJNfDEm3FBwvCbFhSrHPPqnPxdetgCtxoLXPL7caB0oAdkKXGsTWttworMNV91bhRJosv1zdUl6zX6ZhtO9R0rhyVRtwpl3jSBgjkLPFnMdcUWOvC6Nx2H/Y0NaTa67XmqrhNpW+N7LDJMMN4A7wIomx3o65fEqtbk3HU2ooJybapaPA2cXvuCtKc4T2r7dYOG6c0YgIJuHNFzjMm9XfDG8V0cKnpIinSX4nxjpheL6G3TbY/Ph1Dntm5xG7OxNtA8w1NqKweq7UHkthj3fZbDWM+677hxsCZDjQ9sYz3lVbIAZIMnZVmRJGsQbctWpPalNRa4LOf5QrESaJCSmbIQvKEGAJNFGyFtWvVt2VIagwXBVawmcPF5G5FuGCDxdiMwmRIb9i/nS4W7JlqGZGzaUDR/UvbwAVukuPNdv8AZWxz7Lac9y2ILed9FVw/+l0b/Q5q02ImYLcKHTbKRs407bg3mV+nhm/fKq3MG8UIUISYLFcuk0iI1jMkWaM2oPMpl7p81Y8rfB9FtNaeS6eM2q53dRIZMr9SW1+jRdWlK/ggyAJ8Svium78eKyG+LqOgiHYddwNBqOnVv1Tu9JK3OWqZGcr1KcjmEGWkynNNcLrjbTUeJj8LatZg5WFW2HUNdoe+cmtIobDG+61yybmjB0MBzhe43BVtIcYr+KqiEHRMAE58UbUrsqK0OV9y6bSSC/utCmYZDRutmtuTRzVVosTwpnAeL9O3Heo6N/atHuEwQw0MxClMT1A6rVnnfqB1aTReF0oMm3ukN5OiQrcpqU6rs6bG1qLg9jk50I1oIMvpNF8wj8R9pnLJGI+78oxH+2ShN4zRGARbCsFwQaPVSZIxDguniMdPCaIJAsU9I0iZymv9KzZUCZwOo5O5UAPeATSGOeA6mb3AKYMxqVelbNTHhMjcVLum4oPYZOC/UNvNjhkukAFfNTDS45BTr1QLSVMXFEZoNGAxpkRYpASCDAL8u6gyZPE3pzQbW38E4gVjgECZieGSIeyU8E1gYZSvFwWywPa8yMrvVdNB7PEeWi1B3S7osaVUqmtkmz3zenDElSqzRdFfdgFKBorZuN7lgE+bjcihzKgcjqOTuSc3RxXIvOSJcZlGE4zlcqsI1nY8FMm1dG4Vhnki4NrSwVZ5VQCsDhQQxsyjVtbk1ScJFbLrMirWbahgmTZ3DwgsPoixwtCt7N28FMXJo6USlMslenzJMnYiSLr5YBBvelOSdWq32SyorgkMlKqRjRXLjd6IulacaAwh1m1PBEBxacxqVQyTRciCS6ea6WEPhf8A60h7bVa0tfkpqWCq5lDhbQ/kUUOZUDkdRyc1rqoN5VVgsVmKHJOAaJOvoPOiJ9SinGyh3NP5qT2gpzG3ItcSLJ2JsQRCZG6XhPStG22/iKP00Q/QUJGVttmCqvc2uLZDJB0tptyc5rQHOvKAq7Mr0XGdlMnkW2W4otNxsQqGbcFUAN054UZHNAEzOatmQbZ+VTE/VOJcKmHBdHDPwh91xoDkYjTMi0IEY0Qwm8bKH8iihzKgcjqOTqAhSedET6iovpQ7mn86Ho/T4XXaNh32UxepWdO0e6r9HN+IapzFWVybIyGPFEXcVIuc4gymRJNqBtXvTotAMqNqrW4XIVpVsZKq1sm8EZd4zW0axzkjsg5Aq29GBBOz3jnQI0QfSEYkIbeIzRDTIgJrWVpYmlr8jJBwvCa4YhP5UNDr71A5GlsFkiJbScnUBCk86In1FRfSh3NP50PR+nwssdcVUPoc0HsMnBTFkQXtUhPNE4u4oxCZAZigrZBeR90M22hTsqy+6FbEyCEmgjHgphpdwFEy8mRm0XSTbRVxRgQDZ3nUdLEGxgM6azobZqQupcxFpvCqu3D9lVhkPe/AJsR+/llRA5GipDM3n7IvdvOT06gIUnnRE+pRfSh3NP50Pkj9PhlU34FFpvCD2GThiqr5Mi/lCsLQnGtMG4ZKsZ2ZKak4TFO1vCxwC2ntbzKEgDnaiWsrOwE71XeQ0C9GHA2YeJxNBLtxt6su6jpGb+NFdkpr4jDPgr1DiME6oUrGjgulibuCLzgi/NWiw0BChwyKLHDZKtnDg8LynNwCcH7rkXAECeKNa43FTZ7JrIHaOv4KQuKDjcbPDY8JxkTOqeKLHiRoqR9tmeIU4Tw78rakDPBDpDWLTMFCHtVuViJttM7VIOLeITBVJniLgg/GUlWkRVsuvRE68TyhTe6zBuAofpETZY1sxxUUcuqtEnZhfDdWXZldm5bWyFWO26iSL4X8VXfa/wDFEsk6LlZRXZv/AJQiRb8qOkZv/lB8W/y0SImEOiMy47i/cbypDeFykRIroXX4eGB3/wAiqxGz45KY24fmFEwSCrSHj9y2w6H91sRGu9URWLeIo24jGjiVsVoh9lIGo3JtAaxpc45IPjyc/wAuAUX2Tx+3rC1jaxCthj3Vpqnip9I33VSGybMXLavyUocCa+I0A8EXn0RcbBiUGtEgKbTLVrH0CdEqAvditxi2oY9F0zHgPyKETut8MLv3IHOibfhO4XKdWu3NupY9w9VbEd70yaJlTjHo25YqUJsuOJodxcFzb1eze4yQLosieC2XhytACEEPnbKa2cE0OMy4rANbiqujwy854KvpD65yTi0S5IxXvcRgCaLbXZKs4oBr3CeR1C57g0YK2N9l23+1bLg5VoprcFIAAeGFQj+0anxYTXL4cRzeBtWyWO9V2f3XZy5lbcRjfuttzn/ZShw2t1P8gofPq2WyqurU1QdpyByUP1UP6lI0tbWkJ2qQuofzUWYncg+ptDxQ8qIR4S69/MJpyPXSyClmmHJMPFA0FzrgqsiBgaAX4pzhcU+viiGTspkdo5BGQkR4g7lRC9fz1M9aLQx2Y6yU58lXbcVDR5ihnKgOnsUfEN9wTW1qsjkiyc5J23VlwRdXrTErlXlNb0hwTYzLiLQg5pkVWF+I8Pfyohev56+OP20Q+XVhteqMVKrbnNVTdgVC5p3MIBNGQoPOgUP5qL6UGhn0hV27h+yHRiZy8PifSaIXr+eviDNpolk7rJw4Bq5uCbNsnBQ+abDzQPdbbSedAofzUX0oNDHPOC/7cH8qTG+vh8T6aIQ4fIPbkZKI3j1ocO8nR3boxRqXIMbSedAofzUX0oNAiRzXyHh9Y4KRCi/TRDbk0fIRRmZp4zFEpTQIuPVdGLmXlDR4bqsIbxzVWG1x4yvXZraDgpsdNHnQKHyzUT0oNDOVEp2+GuCCjJozKl8hDieYSTZ42IIpo6kw4R2vMFYKs8SrXsXaNUwWlScJFTY4hGLENUNFjc6Ghpqht7s0RDdVdmtseqm1xCaeyaLyMUGsYS3gpESWzEcqrYYr54KvEdXiZ+HX2KJ6KEOM/kSRewzQncv00f8Axd1VVr6oO8ptbbmdWT2zRcdoYCitc3yqTRIUScJhVr24CmT2zU2uk3JVWCQ8PiBhryyTqzQ26zFPf5R8iWm4iSdDN7TJMJMojbK2S0eE+4t2ipi0f2NN7g0KUFvqV8R5qqFCht3xWmn5stVbF5n8k2OLnWFMttftKpEEwrPiQPwrDJ3lP9iVYO07PBTcS4qb/aiC/wAlido5uMNBouFnyT4ZxTYA7sOggiYOCMSBazEZKT9tqmx3p/YBc8yAVVuzD/KkFxzpMJ3euTtI6SsTdw+Te/yiabpkN82uFuoYkASfi3NWTa4KpFsdnn48XvMgrbGi4KQUhqNPFR2Z7XybmQwS50hYtE0YdzaPtq1hsxc80WPEnBCHFtZgclMeNl7zIBTNjRcFIKQ1mPbaYkQNcclL5JrIZE5TKhaQ5o6S23WyiC5yLHiTgqrrYf4QcDMHxkucZALJguCkFIa8fR/8gp/IzTnjvGxMZ5RLXk6x2DlUeJFSNsM4IOaZg+LzJkFJvZi7ipBSHUCK32VeGeY+RhaNKtX3uC7XanYyfU1H34HJFjxb+Vmw3hBzDMHxbombgv4qQUupnkqrjsPs+QsEzko2maRIulZJP0l987FYreoqusPddkiyIJEKYtbiFXYbPFOhYdrvGjj1ba27NVeEx19lj37qe1zi6HVtmg1u6KbFbr1XWOG65FjxIhVmnmM1Wb6jLxKzfNymb1WPp1ksUZWR9HNkllEF462HozD8Ke0fMpS3bAF+9+91snWOG65FjxIhVm/+1Xb/AOvEC91wRe7FTNw66uw7X5XR9EIMR3e4rodKFR472BU8Op+I+3yi9VRsQ/KmkWBtpK6QwwXDHqbdaVzxcUWPEnBVhdiEHsNh8Pk3cbcpKQ68HEXFQ40aB0kQi5OjaJsObvQ7wvisI4tWzFb62Kynbisb6rYnEPBSZ8McFMmZQiaQ0km5qIhNqj5GztG3FEESIUj2ZvUxd4b0LDb3qOPyIA7SH90H3YOXSQpdG+6S2mOHorCQu1f/ACVr3H1o2Ybl8R4byU6s5YlTXE9bx1enhjbG8M6OgebO74YXd7uhEm8qufT5KuF0kOIADeFBay2G2jahsPouyC7Jq2WNHpSeK2rlPrrdXpoY2HX8DRbvtv8ACpm5T7ouUzu/K1vMt1Tb7ak3eyu+TspLXCbTeqvd7pzQfhigRcfCehGNrlVHqclJu6LvlJIDJWb1E7lepm2iZv8Ak7NQsN/dOSLHCTgjBN4u8Ic83BFxtc4ro++61/8A4+VHC2nan6KUqJFWWn5a2np2DbbfxCa8YIOFxt8HbBHMr9S//AKZv+Vc7562mu0fDf8AZGGb2eDFxuCJN17uSssaLAPlhx1J5fN8KHQnY/ZdG+zunwaoL3oQu+61/wD4+XaOFHCkKwKTh8zYrU3SmXjeTXZifgpjO3INjeJUzeda4rdPstwrcK3fusPdXtW+Fv8A2W8Ve5Y+63futwLcCuGsUFJTUiZ/NFpuKDDezZ8FkXbIwC7yu+63FuBbo9vlpooIcqN3+2qzT6K1GqgrQt1cP7buRqof27cgnIL0pP8AbZQpmRL+270ZIK10lvrh4Z//xAAsEAEAAgAEBAYCAwEBAQAAAAABABEhMUFRECBhcTBQgZGhscHw0eHxQGCQ/9oACAEAAAE/If8A72Zqu14z6dUmrPeGZbsjMHUSozd1f/mb9elkPWXx7Fiq2uMvkv2d1K73lQqV9T/yq77Y9pi522b38LL09CCfpnVMAV3KC904Ra/z8C4vcnXfuqYH7A+8oS3B/wDF+nnUUQt2GQ8GuJoWYDn4FhXRoxkM0uBglvesQ4Bu7mVdlIW/uIphfomH9UVzsppn5/8AP4z42hGUo7WKcLJtOYEoaC2Ur14x9oHNfsfma7f2YR/VD1mDD3BMNw/R9T7oP7J/qXwWxdddX1l8twesNRiYY2x/MBIJknnWEeq7MEE3xMz/AHQai3nwWv6o4co1ByCViLFFPdivsDR/LLWwQXpLdf8AoEXPns6kHsKxPN+22ObLV/dHu+FbMBmH1NUiHGu7+JZi6Gh2PDrkrxc1S4PtBAIIliea3lGu6f3ilrZr4WJTVrhJelBPZ08G31aC5VL1DqagPVmqV0ympu9NPO/BtcP3tH56SXqz1/uataIW4G67icqzBT4Srb1X480pOIZH7x8OkWxX4J+jcfbnqU5N+APWUoB6QmMZZ1zoaPCqKDc2e0Olcq8Y1uNzL8zvLTk+vgGWpLGGbTj38yNBThHWO0VNq+EYOCEwGRY51q+sc+Z4DqAYsIkXuPfeOC0jCa7xs+MFMMlUzEqMGzB/Maqbtl/EzGwA57UOX93mWJHhkRFE2fL+I0eNfY25kOtoEwoHo6Xg5hf+IMM6wIyCHCVVtysv7c2yrZ6+Y7xFDux8LL+Ai34L8P8APMCtVKqkOyjuW2r4FTNB7EzN+qJrR9U+cwqV4Gz16Do/zLPvE7p/PKrCZkqXS8wfsFXhhqW31YjOXtNOZWBYhesYEw4c8B2PILWbzPt/RMkK1/VTCXMrf4jn7JD5jnAOhn+bl+lXQfhNuLi4++UakOYU86j4Nvn/ALAxpaeXAvsGSHeYDX6ry/C0MXh7RVP09eYJLrJgBCp1/c+e34DovTeJexQPX+J0l3Q7HNctTujg+kOO+AYHvpO0+fzzYjZBmXCRba+0eVEBRNSYb93Y+XZu38PCC8oqp3PQ5t9wusVfcO2nMYUzyuH+YuChgCn+ngfYiTEwur4bwcfA9ILtxex05jwkcB/WZFfmYt9HPjneH0N/Ley0eF0FT7yhGmc20aD6/nmJuz0VtFCrCnR/EeZoLaCaFNaO1azBcMr18Ew79zZxSIJtT6msqADLYbkuWWGzr+oZtXHKqlGE1UB2H+75016+j5b0IX8eF6p/CdHviw5SYRzV/v8APKF4ay71HZqH7hzkUHSxM+hHaL7HQ4tVZYNIxgYzX7rNf4dyVMwifXMr/Gz8H55yWq38F5XglrkM2YMgEzXwuuj+J1R+7lIul3+DlErvvxEt8/ouNclGrL6ZEsMHB8uWxsyoaPVizpfXpifHNeDhZ7TqafLnzDofKsEAsD7MQBml8P0D8orG7++XEe8wDsuQn3YCv2+IgVMAM2FSlGZ+3bkF1InuzNVB9+UW2lr6V+Yrbc2Yo0L9RIKU25fXn4Tuce4561vHlONcmA3Zf0VryJoBe6/48D4mK36uXV7J7hr35MxAY0W6nX9rgg1tAQ2TogHTrECKuKvIJrRfZiZkJ88r4SwW6GnAfq7zH3eWlP0ZV7H88/y368pxO0/y5d/vzvA+NmAOvLgLszGm65GZzvVMxEQCtBaxQQFFh+j7Trwxv13rPXYS/oF6BgcLiU3oMXQC99ec5Yxewr741xtg5/ln63V57nuPlAo5NC4qS3lqUsB9PAXdfnBR2XKShv6ByLT65wYM+uyvf0mMmvYQFwquad92Wsja8hlw8T4Ys1tI8oZW1EdzQabH8vCq2u9RJjJjTjRGtWKFeh14Ul+jOjEfLz3dG+/lF+3D5cxmYEreoq2a87rC/ZBT2+7m6X3+P44hQBiy7kR6kHazAiZ0tmfurwqTwI69Zh5nDZcOl5xL2/L36ng7tOEswoH1/siITZiL14nFjIhSQ9A+j+Y81tfaGiaF5L+CM3V9/qy4K7vhhdgjmL2FH05iYVBZTSAEEyTyequxzWk/TazR10vU/rnvrk/nOi/2czb9+4viWmhdjGNu4nbSbjQ9dJqdCIWD6O2gPAwysl/EEgCrlUEalJnYeV9q8aitsUJgkrd9B/aa4WeOGiui5IfUNH8y5bS2O3BsGo+yHkEjAKOx/cZm0t8AFa/S+T5XZzvK3o7mb8RHKkpObJGQh+3WD+b5rv8AA5xwNmI7/wBkJrwvYYflF4KoNWUWXx10HmZQI8dhdINUaBp2RWAqyCF/IX2mDP6P5YD67PuYxYizNF2IjoI7JyUScqXFk0r8OQpbEEYLEXXY/l8K5W8jr5MvG45+i6IKtOh30fWPMjbS7n9/fNRoqPqcad6xhihOlg7RhLXJqezfvGeA8WYELNwP6AJjUWr5hAXMT4CPkO5l23kPD2IENty+EMuL2mDM3uZYGwkPxLYzdb5LqZ1cD6v75MISYDobzVeYNjQ8J7HE+g+Tdzj4GOOUN22gT4vB3NHmGvEVtrjFRbBpwzb0H5RwpM1bhWsvVDnqRKtVevg1qN3UvOHOJ3+pgloLekooDAsC+vRMb0TDr350ALXAgsmphxGm50QHyVAKySmMtmxzqWRYmkCgAUGu7yIQiKJlLhMqtX6jnDGfbSvePZU2N97y+ekWC9nFLDc3yfotvJttmvCmTCM4bLi900HTlPrQfLWIbJcQ5nQxQuZSjfDPzeM1Ej+Iggcx95D/AJ06niEJdqg05Pqisn9PSM+iGbTgP5gSfTiWM/uGfdNiVmV/xIXZQaxvQPGe3y9Lx8eTUduuzxPYlB8nWDxOjyqSmwy4kXPQXDQdtAo6yX4nSiAqCrb/APDbB6P6DMyvak1J3M+aema59K5fUMGq7kHhUxmwvW7EaGOVbn67Sw2cXk6OBKrDbyTA7NDV7RB9G/KOW51eLYFWJpMlqMj50Zj53hg9JXKI9fEJVyGrq+vEWn/S4lOJMRW3TG1u7k9pXvBxPITIWTKy/TeZF7CKzDLvjBYHkTapyWPUW92VrG7l6yxbnwxEHNdBuxBQsOrh3AfkmU1kN3aPbC6bc9J6rPbaCdruEL0CrJPSrQVDFlstxfLqYq4ryH/pC3jqLY7jeX5BTw+Npmj8qL5r6ohaL15LSewkN8E95/jjbliYeSKXyNu74dhSkiMTBxNXeLbby6v+nJyaDv8AT041criAU8gXMwYG/wBv4gaQWBX+Ym3A39b2ICCgoPJLY+1PbjRoW1coQGDj9A85nyW1tqlIqNHTmzP/AEBfNbUr0Dpwue2Yj/MXtvXvuF4G0A+rYv7MU982Am80wh6TNjgVrrwDZnq9fJa0yudziS9DZ4/o2hi7vMW4vkv0s2d3FmCocCbRTzjr/nBfPULWOsCkSkzOUxaiW3pLrKOPBu2pCWlmHyXFmudHhZWgiodEHgaD/wAucCjnyTKVjdtXKXcpWoHgPWA9K/c3i4c4xt/X2eTZiwfteFcfger4VTr/AMgV4NRfkyOfForPa4OU/X4smlwaMkuEtw2OnkozIr/cx5ao24QIxjqfyY8AgBawNKl/d4Q03ECz/iHh38fsPO4GmwHXPTybvvffwag9b30mMcdL0mDJe6nyRqiXD91Zi/if5moHcIhXWskv3ZnGCrCCDD/gHiV9v1Y1Oe3djVl6XZHwTQ8lFBcv6HwKlXq/ozgiEGatBPUHasex9bV7R/x1sXQ9P7Sn7/zNbe6Jm3sxZtLcLJdweo0xcH4L+YPBtSD3f9gTFYTsPJ2rwZRoPSD7R+DdyQWY9BMusveY6/kevkhdi4jkPAxgvU9iLbfDDyGyTIowPAHrrNY+8rOM/TGYsZ2Qmdsd2NN8LN62n8vLKtV2lNZZqsa7Hv4oFLMt+kcOD+KXq7IeCO2vfiBmXFtoiZyVMu9CnkeSUb7xrre2ZSTF8hPwvsXz9GIuQzeFBvM1KxOvjdIIssUr1CbdZi7HDOOzNJ5ci1oNY6+6PzMXO5dTLD7CfcZcFVrcrmcH++UxWlyTFL8R4M1aO4joJEw3P4gIQYAacKIiVUpLK8sPWvjyOmnUexDOHuxfrgzNglZMpiUY63b04BAFrlGRGVsMdL/gxOOFNMUg1y5uHcV7TDe2mDRRh2mJ/wCFiL0foTNXDO3+IOAdA0OVLJd+udkK/Hkd+zt8zomEARyFcKby4aYmwtf8R7XnW3QDGAROgSpUqVKlSpUqVKlSpUqVKgwSpUqVKlcNSpUqVKlSpUqVK5t5rhZ+WD3f1igKaDNYJY2U5M45L0jOZtG2v2+Rn2M/QbzMlzWnDKLVRUkOsrTshuc0e7Ld2W7st3Zbuy3dlu7Ld2W7st3Zbuy3dlu7Ld2W7st3Zbuy3dlu7Ld2W7st3Zbuy3dlu7Ld2W7st3Zbuy3dlu7Ld2W7st3Zbuy3dlu7Ld2W7st3Z8P9cUBSgWs35NHbRBA3ule0VvZv9BAyG40SMuoheKhGmr214YrMx6eR94M+Z0OL8x4Ly/xIhifgSXZx1GGip+h/CCKVSkOgqhcp+t/CY1VDJ4Zkx0HGQnBwtC74HobhaP6z8RKagl7FvJP1v4QkZCuTHw/j/rjj/p9tUyxhGUOh6cBsnEtfROyOehxvDf8AbTOBagK4NPI7OmffhS+u+OQQYC28oUMopFPI/a6nGPnvp4fF/b4fyn2cpfvdCZnaZnFv7Dbw/h/rh3wN41xgaOhKUaDu41a2fREc9TPWeBHP2UcZgl/fHySs6j48K/eLXHB4d8tZYa3Bh65WIN3WcZTNVLbM/BVHNg2R2W2HD6tiSMthhHtk1jWXDZkleVkz07wUYJeaZng/LfZy5bXIsuMFazYBrfdROwApkc8Hh861aOgYZEBPxoZ14ASWZEKvyo11Ntt8MAT2rXhh9X9BwpppnrsUx9Rxs7Hr+7D0xamRa15IeSCmZ61yVIcnrEPBbDzt9Sm2xveOaYOYtfWX0+n1jY/aliI1o4YstgBIXNwCrHaf6mJELDXSjeMZqqARtfswghuV5fMFs2n9cvoiXRqcVyJhAxZ/pIqDzkCpmO8OPoxYCbHK7E/1Ms1MUjHZhGCiKqn+phxs7CvlDKeSUgDobV0TIcce7/uWbnLdrOYGBgcLXXptXKyleibHDF3BrD3OFW8fYavk1CDMeus3wh6ksHYWdOOU742kHIQxlP6Yn5iaSa7NZY4jY5T9Ppx+e+nh8X9s+IhkT5D65jOfHR0OX9fryl/Y7T9nvw+F+HL+11cdLlAP3zHGUl+nM+DJqmB3i2S13Bu4MtgZG7aWMH9ukJuGZ7EMulQeTUP9FfC81V1bILVwEWhwEDcaGb8k/v4CN3jL8avtpDXeYVfBJHYir3lR34zdhP1X8RR14MbnSRufvv4mioRblZbwWq+CRRsK4GJfIqlkGKIEApjEAhFms5+q/iWrYAxXlMLsHXep+q/iNYLvla74qW4tgvhABa75K14moY1/e1QuMIIc1EHByHyHAKD87tPrlj+45ZwAJrLjr8eUX6P1ajkU1kyUxibOpxawDbZBdzaOGtwV3kr7+TlRVf0XjX8f9ci5eZ2md4Ob+2XJiEGyx4MKVra5stHw99ryY1Tys4ydjJyEDQYzB/Cwbf58pFjA4vrBLpKSdIT1NGdg4hWimVmUrAxre6WGzOdKPqnBdtZ3RP8ALz/Lz/Lz/Lz/AC8/y8/y8/y8/wAvP8vPh8K5NXN/nZ/nZ/nZ/nZ/nZ/nZ/nZR/Bn+Aids3A5MmKVoVO5dwsrrCZDgxd3V4eglr+xfVmaSBYHS+hKSv4PK1TMaT74aRDE/phMuIl2FJH1JwdyWswL7H/B1zr3OIB1tL9fDMuVyuB5MPAUu7fE/Yjd4ALQY1GS3Syz7TOUtu45vaU5jV1e/liARLHBI69S/wAS7YbGYPOTeclJsfZ6R16en/AOhtig7nF6xjgoHHCeAZ8we8m+0wPRINtEsZzDbUyrAKLaAhSOh+aYqBVmJr8Td8GUSr74MD08v9YpulTqQ3Gwt0lNp2PHM4ihZU5T9pis8VjcH8cNiV/p6zL24YDyqe1HB8dg521jznmpGIzD4JU++YaOUusO8+8AmQX0xZ3zh3QAAKDIONYeXXyhmt+jEwKpGXRbuz1IfK+pp34kcjg+imctXNs1db28QSJHcEwkL1QPmZwlYK1mAiqgtlXEu9RAs3zmNeils2ucyEGmk8AwOLdYFvBO1vFgTc1l142owSvt9WWzS64de2XmyHEBnPxPQA69fL8TK8t/eW7rR0Z2Ty5wVB66n2heJRbArkeGiM6nEOW4RLwhRhLVj4GtcGrb7D27xK9RMxPv2XaIpC8TFRfwz7kF1nMiDYYV3lmUqxFZ6RABsSzkGPGy4NQYcDW1BCuvSZXLRy94cttRDUrir36cdgBOtrhxrH/q8xMXrQR60tsyGyzrZE5hAW0GxminS8mJ7T2MWolSZCcdc/BAnWLMQpGV8GLgY+8S8dN7duCtb3FvCNjP1mosz3TArOyFCzKPUEDBtxZQooHWNKCXNeLxwHINRy9fplOpLextHOKtd7CCjrdcNcOT3ahizB2w82yempmyNS8r4f0MSpUwupvz4BojoecHWK1esw/d3iLDqsLP5nXGEafav+RKEQte3udpRVVhG8KmluULTvSS/amZr0DOGBjOrWcaBNNQ9NuAt5O6uYJapaY/rCP8XahW0P8A0ynwVhZpxHIKyHSLbwNDjjfo+cVg6PbMpo18V9QlZXmS8arltpjGMKAWh9TEYE0LvDi4Z4R9+syxvpCst7XrgmGG+6Zwdqo1g8SmGMAeTGCKiwlru2MzGiSqUbcBRx9hWtN5huBm8qcMEsGYAUPXuzGczu9CChwtnBWrOukxFbRLBhGXE4GucGUpCDKTi+bgQLRSRtZ4vcmNdkkODGeSsv4hevAQA4iyr7cg6JTMyN5tYl8EGj7MnwLLhvE/hGan3KpiYHdi+ZpUxatnVdJbFfbEUU2zpFkTaBibwQYq0K8m/BusC4CR1zqgCdpYbbTHzN9DaGSJk2mOQldAuUfDLf669ppxmxj6GkctLNtG79fjM67gz6qKm3trY9CMsl3Zh4s1NVA6abLCCTWgM5gCd0K7PNTfcX+IFBKTBIOdXG/pjETBigGyqRaz4DfAVXkOUXUBKgaTE2VUZhBRc7DP13mamiLgret+Ku0a69RMfr2vxvWZ6l+GCBX4nheJnOrGsZWTlkJ1ZSt1hYexDrENjOP3pZWseqTKg7EGujVTHt0hZGIN4HuLS0qQbNYX+WHK0qGH9wX1vMzBG1dZQ+Bdw6azzeqo4ZHXeExuvVSwK5yqw6S3qmrxjk6zJlXAbmtBqAR4uQIcDP1mMoIlf3RETMMoL/EFRfMhdMG+BJZWFGnWICqAZsMgTeJgzEAyRt2GVi2UVdGswCikXppodIx9DI3bEWvFwNA2mDVhd2IwrWc7BHxl5WsKPHNbsoNBNR1je4ZBUtsKN57RynwYyn03QUqMd3tcn0+JZLXB4uRmi8QwlyvWAhJknIg1Q64RAII5J5SzOwpJW1uN+KWTDYxYrSW850l6wJWHGLirvMebNwF4GZAT2FnaUVwMGGfpCYrhFrhljnHGISKKR1gMAFAZEoGzHjX1QVVtW1L2lVeqJACLu9I0UoFUHMFC27IPT9GRpCJlID1MKtjf9W0CkMFql+C0ZD/Y0cQwIwAq49ukTrTHtEdezUN9DExGYZBsWDVfYJbhx69J87mEb6f1wZtBeHlLJFcVgmpHbrKgrcVYQ0cpu2XInJFa0I3sO20C3t3wyNIwqGFrEgUuNBGrAzuYVd3BMYboHBhjly3lGpHitmUQGpiGtcD80cJxZhUSCA1l1XKDfpstjc6wFBoui17Qa4W6gO0Ichovl14LE3jUcWbDLGWJBhRcBvACioHccMdHUjDsv8RWm7xAxwhh/MsGVvSA2YqKBXPCVi1rW3aMsQcTd/EqMYAcfWMgIcGrgVUC1fiWh56xQxVsJ25wOjcH6rafO5hG+n9SgsMLOocqD5i1NVup3EiF1ZDeOcAPWcmcIAKLfcoUYKD7wznyk/R6ShF6zCNNUQDwVMYmoreUtARgOAJYzU+pgjYLNr2RN094sIgw2W2uIgC9RgUukt8naESoLQLZeMOZZcxrrEcpwj4oeAlY6RcLJp0i0xnI+zvMDBHtFXBsMNkNAYxpnB1j0kroO8AkLLoUzAAFiq6rY1wH9+8sA4DXeIlRCRZeN4YShiLB+4WQgPB9ioNx4H6rafO5hG+n9T4PD4E+G8MzvwEzJ+o3nzPyhPlJ+j04fX+p895XruvdtCaIGxJdrUhw74EWDDMe+0bmSKpje9wphFwpdIy9VkDSYijK+YsabZuJ2iXrMWvdll0wohUSxZaj+IhcNCLTIS23zNt4woG6YFwTYXHJ2ZRgpWra4WReT8e3DUFmv3KkObQ/tMYWL3mwvBFpO/G+ZZzJZFSsBnzv1MT6sHakqOQzyMSW0+n9T4PD4E+G8MzvwEzJ+o3nzPyhnPlp+j04fX+p895WQtnTEeKZ7CP9bYzCJ/ujpGWGtxN4sx3Ssb2bEAUKbwOkLKgsrSzMiNXFAuPqjVY2YDWmsqm2uNf6RA9EF4zAUbmapvFKA7jwVWGAbGTvEww0a1jelQegx69CEvGAZmv+OLhJ5tQBEAwA4g7heJ3gA0lM16bGCswULeEuWuY5IS0GsG4ItH12n0vqfB4fAnw3g5u/AcsXAjtDEt9z5v5Qznyc/R6cCShMMu0+e8syRj0mZ4yjGh5QQA2x07YvGrZejvA0uhblCusVuhbBCogl04MEUFGupDQzhc67ShoHxSrjQMORRCuOHNSjfrKbRmUhuJrS4EKtLh+rRwJlk03gAAAMg8ACj0NyJanOV8wKxI4oG7LDHX7VGLWjHrEF0euXQOlvMlU3HXAjWzDekzxJ8CfHZrLx1CBjJ7wzGY/oOSJBiJhe0wUMx2qCzFB1RoGOoZMSII5rJmBjqdO8rmUrF13m8IPWZ4mT5WZy+JXshlAc+YKNjTDBJZfuuVmupo7ktdbKr6aRrbNpVUSpZlj+UuEvGWuu0vLLGBYmI38hGSWczEqWmGa2M2NjPVlOXdmTtyOAe64Ov9ZidBeF2NEsRHpcIgj6GMFa+Caa3luAVoyvI4IBRYx7DnnslPTpHBY9g+peWBhdb4VMoGJAVF5zbwXA4MyA9BRkUFBGJk0ZoMtqP6lJMf8ACl5uUMKBgk2+YvfyszmKuFh7LUZ1mgz7Jek7Bl34BzDJGpWG2hj7ygGN8kMIXSBap7pKYJIOFnoinzLwr/tfDITAQ2PNH6Llx3D5Srffl4lwSUq0SxiTopXHw2WRXGIgMzSY228jnKY/Usue13cakusDqx/sW/4Jo5FxqkrZXy5019Sa77pyNp+sy1lt1LEDzwrlKqznfyszlItE/M6EBg1GnHdRi9Jcj1z8RSpEdnhe2EyVujmbnu4t4vAOxMgLld7yP+JVbv8AyOFRbCYDuHh0G9c1KywusdT2TqplYB3WDAm4DKJNS8B1WXgACsqWCY0l/wCkUQXVMjkQyyhgYJlY4hTwKY2yM0K8gyJbOrU5DcVoO02D0lDl+nrPgSwgoK2GBDAhoFeWYu4xkc3jZAyvdQqn3l0s7NIrgfSv3EtfYzOh2M+ES1AHUjJBDskx5M+Vj3p7+HSMpyZ1xynL8TdUv1GD0W3xHT9EKwWMAFABscGErWwZwEdDIhnwZEB1DvKBASxvzR03VHFZ0y+Lwqkz8lybfdOiax8YdUdhl+5M6AF+YuoF8GKorZYqebwUdBUVM1Usjl6YKr1j1WF4nFex9llimbHzD5H64fsdXg6zm03an54dLF8RHeyHrtGso9Y+GAU2kqD1jtun64Bv2tUYU8GdyYmzJvRWqa/Grl3ad1zpFDBCbL6XUexW06iXhA7WGcZkG0K4B9J8vdN1/XD9jq8C5z+/mEtO1PDtKsyakRWjqosxljvHFRMVmtS78xOSD4CGfCs/6a8PkH3w/WbRxjvCJvXRDIsp8wx+x1eAa53pqvjh3lHhrQtL2mOpOcGFPUk99viUJrv2lM8Wy8sHwEM+FZ/014fIPvhQKK0auETf2HOQhDCmmL5e6Xq4euX35zPwfV/+Ut2wfEo2ITdBtCUGgUbIaS2yvQnroO7ywfAQz4Vn/TXh8g+4RxcEL8QJ28uNCVmQguoXkkeL3cOhy+PDy8jlMMMPkkr69+YYobxWcdqzsgHhUihhI4dZ0Kk5tZaPargCmOp1ZKwjxz4BDOE3Jeftd+HzD74abb9cEwgLIvy3F01x03WX0VmHvKR0CVQGQV4DvwGqcrXcg2QBbMFwVt1mDpvBMU3JL+wZsG5oV7sf6diWh6DjLH9pJcA9HOZWoWzuhDIOLs+gh8myWk3PacmXvPRzgMXEYR7YMoYua5aEtmZFDa8I4Y9l3mLDcZHby0MXJKgSYOqEs6PmbGFnpjM/Ayvga/YL05MKNYnGE8bCvrjbMKvOFgaYeAd6TLsjJ3cvlpeHzExbLbT+YgETBKqEgua7vWDyBkHBORNI6S+y+sACjA4VhmHEa2f58vw7ItwN4KFHEdx6Erm3C6DT6vgiuLPy5x6ULWkKUcgjcIr26AaO8EBBMRNf/DdxYQi7P75TGMa/cJgDCpY4x3ucYdZXI+g08AWrkzc1Ofs4OMIXvSPg6TqdooLvdf1UDr359P8AwirVuckvvO8DUPAcUxa5j75Lr/kN+jp6eAcL35DPm0z1jsw6WeJ1w/Ec63hlsErJlenP1f6yn9bcT1mJUmazP/AEV1zL63Y17pVi2G3nr4jW0K11i/yYmUHgBRXhGvlFfgqnpUGN7ca5M/Q7esMRL9klMpp6fPlPB+ZbviOe9R2nvcd+RdADFZvHWd+fEOYy5SlVoGkpayNPTlYNQy0dDHw5wYjQ5Gr/AFggJY4ia+eKBfWQc99jtKz/AN81UTqgJeOq4cwxXmy8ipMAMdmrhCagoenNUWv8k9I7/OExZtp+EMlkk85zeyXgsfvMdoJ/353W6lToo/5F/KYC9cfEM/IbrIxZ/T4aQCdH1c+Roysz+osrvsm5Mc+c2dSFGxQnm7IAYq6TFcZD7MEQ90zv4BIXutTaWY1khky7XmwjwphuDQ0MDuIHZMD38DJoO+pVmGToNyVr9TiQKuu82v1xsW/+IohiytM9XwaU5wS1Bt0dGI4OE1p5LnhVTIcN0bW9QrxZmVl6tZmiaR9SALGznyrvc/pPveLrM4Jm5MC2NW55pbYp6HSArQYzN8+fhJZTkwKC6XuXFt57kn05NXOq4GFWgxXaXDPTcG8S9HVWQW6yOKK1UwDA78/0sR/UUP8AKgP6xAt8fMgGsy+3WIkVYrKVeLk28Q/aGKlgt5Ids/dpNV78cz4DQqgGa6RmV/SMfaOWyhAQWYd9HN1AmSZ7c3y6Qf1PveqHH7mggRcNTVeYOvXyTNdyGxMOvzeNh/UpvIbMd1ihgxi3/wB2MEQEVqeC3ANuIpdZzkc+8t+X25BmTJmMZl8CrDGbwRLGzls+vQct/HEmcFYbhLXGV5dli5RbL7nWIR9WEeQePY5L2GkIdQ4pcHj7bPSUo73CGvRqEC0J0ZTtKZp4byGnZFHvLBj3/vHCEzWC1BpVG8vXLaXfho4e0Aw9uW3EC73RitkUjpM1OS26wAQUWJr5br0ZjQ2gKgYsGjVn/wAOUelshVLoDUgEbGxonyyR8XjAlBndPnoUpXDGJY7uVMcA2xMLDXOPFsekzDxAVWYMPC4cqwwHgad+/C8YhndHbyzCbbDcY5dpasrav/EPjeFJuTMdvYgLB7aYz64AhX++LWetPhREvhYeRqli6AjXPGYwxm8ESzkDOlhP2qKkdSZ20D+fKkCUC12jHLgHpMIsHz/ytg4LKJQC6xA9zkANCLFFWK+mh/wubm0O5ca/xobxu7VjsoYsch3IzdhY+U174+w2gTCM9hvKaCsD/kAoGbhBJ0VKWehBTCxlAOJzmXf2lC9pGducNPSH/G7uDNnbjgFnHdRBSaSWJ1e3yjLzblgEAhNZx9f8roPgDTZGtS0FgUo4Fw3HaYhbqEVW3F/5DBsmQz78c+BYSGaG/eIjY08nxkZf1waS3JtXeIiWm3/l+Ncio9eF30w/6Mll346yizq2l2MTDs+TKjQWzAPbdtBDWn0R/wA3qc8lFsXog0s1lJNS/wDpTA4wILGyZABwd281iF/F5NuR1XSd9A+v+VZvMdCdCRws2xRse0wLDafEgTEK2gVyXaOscnJ/6GbUWaGMG44U+GETkXko4mhVFGa0t5hMvYguUwuXswaQ2j1gXbBq+9DX9iB1cH9fP9yA74C3eqBwBy9mB5e1EIlHCqIAFGUPqWLbAqsp8SIABwuIFqfqXtR/1EPY0zNdH2eSdoFXaQVjDqvWAa2ANHrAMvZgWQxgZB/x5HAORhUPp+58TgmOVc7nv/5lKs0iQmtdkUDD8zAHpc+JNeuEuYYr/wA0tx/ssxUMyM6T4kdpu4AsYgKSyCw2/wDMak6eHaFGMPonxJkRaxpw+d/5kB12iCQaSt1nPiQAVcqw4LS5pFY7/wDmUdkWFA7S1F5T4kaNJlNy0ytUMjyz/9oADAMAAAERAhEAABAIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIII7RxgYIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIbyAAAACBDAQoI4Y4IIIIIIIIIIIIIIIIIIIIIIIIIIIIIZziAAxzDxBAAADACACCAIIIIIIIIIIIIIIIIIIIIIIIIIIJBgAAAABgAAwCjQSgAgABCgIIIIIIIIIIIIIIIIIIIIIIIIJ4AAABTiAARgzCAABCSSQgAQoIIIIIIIIIIIIIIIIIIIIIIIaAAAABQgACDAAAAAAwBATAgCwIIIIIIIIIIIIIIIIIIIIIIJQAAAARwAARgAQBSiSyAAAAQAQQIIIIIIIIIIIIIIIIIIIIIJIAAABSgAQAACxAABSBSwBDwAAC4IIIIIIIIIIIIIIIIIIIIIigAAAAgACAABgQBTzCDQADQgACwIIIIIIIIIIIIIIIIIIIIoAQAAAQABQADSyAASABSiAAAgAAAIIIIIIIIIIIIIIIIIIIaAAAAABAgBAADAhigTwADTjBygAAgIIIIIIIIIIIIIIIIIIJIABAAAAAABCBDThiRwiBARjDwAADQoIIIIIIIIIIIIIIIIIJIABAwgASAAAgABRgigBTASwQAAAADQoIIIIIIIIIIIIIIIIJYAADSgAAQwyxyyjzxSAAABizgABAAAoIIIIIIIIIIIIIIIIIIiwQBAReH83444505n/A0hSAAQSQxCIIIIIIIIIIIIIIIIILQBQgRxZzn333333333/wD/AOGzODHILFAgggggggggggggggggICCAEHH/AGn333333333332EOdzCSAQAIIIIIIIIIIIIIIIIIQCChwB/323n3333333330kEECPCAiAIIIIIIIIIIIIIIIIIJgAAQDt/332n333333332mEEEFoCwDQIIIIIIIIIIIIIIIIIKAgAAgTnPrGdf33333/+sEEEEFU0RZQAIIIIIIIIIIIIIIIIJCMUDd/3/wD/ADHydfe8SFmQQQQQRZsBoOQggggggggggggggggqPyttcMMMMMMIBMMA0IEAAAACVdNSVHwggggggggggggggggudbX6iBCAAAAADTTxCAAAAAFKBWzfXAAggggggggggggggggoMve0eFANCAAAKZ1bGAJAAAGYk+BDNAgggggggggggggggggoOPFR6oAGLCADMnXFvINDACH+dVdp0AggggggggggggggggglkfP66zyCMAFDHVfSTLLLClACIRTQwgggggggggggggggggggkEv+4/3vvvrHfF//AHzzzhiNLLEygIIIIIIIIIIIIIIIIIIIIJKxD2Db333337p37H331kEW/YMqYIIIIIIIIIIIIIIIIIIIIIIIvIOvDz332VVl3XT3mFR9AK4KoIIIIIIIIIIIIIIIIIIIIIIJJKKQHT33qildWody0M4qJaIYIIIIIIIIIIIIIIIIIIIIIIIIIIJKVfn3zQ8tXiHQhXYBygI4YYIIIIIIIIIIIIIIIIIIIIIIIIIIQKWCi7pr3yVCglRq4iTgCIoYIoIYIIIIIIIIIIIIIIIIIIIJJROU5wCVXXSGjXo6gT4IDLjzbj6CwIIIIIIIIIIIIIIIIIIIJZZm3OVC02vWNroYBzYIgJ5T6jgKgIIIIIIIIIIIIIIIIIIIIKCjo/EWpfWIoIIKBRYIQrJhITiDAoIIIIIIIIIIIIIIIIIIIJZdEqMNS1U0IIIJKQAKI5BIYJbQAgIIIIIIIIIIIIIIIIIIIJb50Vgm7WBkIIIIIYLwzIo4gJJJKIIIIIIIIIIIIIIIIIIIIJIn333200NyoIIIIJphxZaAhrwoIIIIIIIIIIIIIIIIIIIIIJbD33333UNOoIIIIIDDBYTwIQDoIIIIIIIIIIIIIIIIIIIIIMYXHHl3EEEoUEIIIKLgJ5DwIwIIIIIIIIIIIIIIIIIIIIIIJUMUEEEEGkEXLUIIIaCJBQCRYYSIIIIIIIIIIIIIIIIIIIIIY5AkEEFEUUlA78IIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIwABQkEEWkGEEPiZAgIIIIIIIIIIIIIIIIIIIIIIIIIIIIIJAgABEkFFEEFUFHfzyhQIIIIIIIIIIIIIIIIIIIIIIIIIIII6gAAAEgEEEEEUFdPzzwzQIIIIIIIIIIIIIIIIIIIIIIIIIIIgAAAAT0kGkEFFPL1jzzzBwIIIIIIIIIIIIIIIIIIIIIIIIbCAAAAADKss8k87GTTBDTTzigoIIIIIIIIIIIIIIIIIIIIIJDAAAAAAAAMAoJxX4wwwACTTxygIIIIIIIIIIIIIIIIIIIIIJgAAAAAAABEcjJWFMBAAAAADizS4IIIIIIIIIIIIIIIIIIIZyAAAAAAAAADoRDJoDiRAAAABByzgIIIIIIIIIIIIIIIIIIIRgAAAAAAAAADy6AcBAAQAAAAAABQCgIIIIIIIIIIIIIIIIILQAQQwQQAABy7UkZJTLKJLLLIIIIKJoIIIIIIIIIIIIIIIIIJJILKIIIIL6I5tmKUMIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIILor4VMf9EIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIIILrrLAAOEkIIIIIIIIIIIIIIIIIIIIL/xAAkEQEAAgIBBAMAAwEAAAAAAAABABEhMVAQIEBBMFFhYHGBkP/aAAgBAhEBPxD/ALRCdRXcJH1T8J+U/CfhPy6CfuL9MQiHqVwNmYANfMgw0s8+1b4VLfmkqV4QsqCmvMutyMwNorpFcxgG4HzKFRKa6LpHc8QbURN9L3cg7gbhtO+wEW0S1A934BZlgVEsjh8MUQxFjUIVLJZLJZLJZLJZLJZMMKSyUlJSUlJSX0UFhjotEct+EdcVxW38JnE/CK2+KqXCq4IXNUop4jsdLRrUXT4dHTf4G0lCpmqVQrQQUVLHiWFR1MVJcwF/BQjfS5cFNd1qoctBYJLS5Y2lePFuXBssikAHCIqYYx3ID2KZe025ilkWiYglBcB3AwIt+NVl0BKmIZVyiUSiUSjovZRKSkpKdCDMCqgUR1x5NTPSixMh3LUwL6OyDlO+xrpl28oabIDD2JeruSkyEWXFjMw1ARfbWVwNS+xajDc9yo0RDkh1RUuXwNyD1BDUQ0R+iewzTeYGmEIsVuOD9jq9Liwz0OFwhbUAUcLRlz6Q1DPWo/kZIjUBwqK4JkdLz0COSXHOpQWxS3CzMopwp3BBiCxy4lEu9yyEIit4jXS1h6MA6YUiG4+sIpYriHlIG0+mIepUDSjcAMH8hIjnhr1QhY3N/gOBgXglBvhFULkh2/AbjXcCx98KQWyQ18BLhmHRL2N44WiP9+I2JtFk+nC++A2fDXBZ4YAWY0+CglwKXt4chDBWu9UHuO+Hoc6lQF9qhuOBDVbt4lWJ7lsH+wfsn9Y+qA0Qiw0HFIrInCVcpwOej6wM7cJoUcYZN0wHCCaNEEeg45VWAd8aFUTNYFn0l0Fn6mA/fGIAsAvMR+TPUc/TxgW1M/dzIfkFMlDxg1Da2hD+iOymY2J143//xAAqEQEAAgECBgEEAgMBAAAAAAABABEhEDEgMEBBUFFhcYGRobHRwfDxkP/aAAgBAREBPxD/ANolDeJ7RWl8kt7lvc+TWBSugB8F2CLfOuIOevox0VmOuW3ohrMGy+sVHSdrrLmAsA3YaaHaJzg03BvRBvAO3SIN5elTgqVDEF3gNzgGwLdlS+nH2pXg0JudGrdBRLitcqVKlSpWlcNStKlSpWpq0zrsdK81AorkuJWCO3KAtqKioy1N8sejIlOmEgctbeQO6WNwd47YKLi2yo6QU3psHQRa5CJWqGy+KpoAtigFsdYS3PSiyonaWFphhhbCI78TjwCOFURTvpmuXNQajuWGOm7hoqbhsuDM8GeK2ZmZmW6C2LRN57epodFZUsce+tBTE46i9AGzqnMV2hR2gJfENS8yi2MyRLxXPgTTwGYcBbETDrcBlBXgbCJwGAd2B7yzPoj3GoQ0eD7pqaVK1oiIxlzfhRaVCLwXPrCkGy4jjwqWVETDGVjUlaFmiABUbil1vCrJSOY1DEuVKiQAeItSgR9Io3iwF2h7RQShfiBiCm0PeDS4SjfaLfiTbyNniNnI2+GO9mOqx/E28h5qAVbEIxQbH34RVTtn8QHlKz8R8h0w+yqL1YLfx4R2zMoD3/Ud8hdSvRawECzQOfvnwoW+1/bb9zF7uTsPhr6/8iKe6/t4W73ClfWOQ4fvkALZWbNx7t2XwyLudvqTECIZvkAHp/2VBQryV8Hh7oU5zDH0j/fGDkD+U75lUJ4dQdrJ/vzLCCjHv5m3BS7QHGsMRroX8/7v4mvABzXp/wARl5Y5T/H9ROkJFzj6Nh8KhjxLPaZX+ijFolO8EckPzldiM5Apbiz1j48WglMSuS/JHIUGxEq12e0UWvc8aobwlExt94zt68aSvYlF+0IB3v6RlJ+jeVFbe734zeASDAwwneZ6Vf8AhABzO0Z8ZYekAaKe4wabfy+kpy5mRcV4xKUzOJW3xBLv/pLIUdhAKyns9HTf/8QALBABAAEDAgQFBQEBAQEAAAAAAREAITFBUWFxgaEQIJGxwTBQ0fDxQOFgkP/aAAgBAAABPxD/AO9YSxrU6CNU/QXrGf0GWits4J8NYz9/fIpwSNwPUo/teR2/8zaGbLXOP4U2jfhurlpQhWrUt6mpaloGP7Cmy8UcHmYe1YUMLjg7PD/yp8DsapsNWnEotJZ4vj6RCKrLi2Smggwq+w/mpkK/QLFTRyAe1WAHSEvdpmsXA/FRRO2C/pR0DdV16M0yPWA3dFvWiTJgSeYZx/4V8kywugOG7WFhZnIFLL9DmKjiVEa1CjWaCG9T5poLc8s55hSKPZTCcNnhSMxF6bTl+1p1pwcWI9CCuxDFKSng/AoRBNH3BqERcN9LNQFuqWczJ9+BdGuwlnvScL7M+a6GPFw41IKOTb8m/mwAKcnpUwY19klpk61CZylNBEJ6rPaVEECRZPuoOD/o3aJgXAX2FIZ/9wlCVUuCEOpbzzFC1GBtIYLQcoKUyqq5qV8kt6VJkkZOtEbTgFzk150R8ZRInD7yXwNTYB/62h1qV/XK0pRjnYvQpZqVdVmhi5SZlIqWRi3kL0+wwkFoGEYFDhu8Cofxb1FPuU2NBGHqXpMn5Ur1f9CEJ/uLNbkFxfh+7jrhvenpzavkLlsdypzx+jf0mLdyGr2rGVTILvvBamBVqx2wqbfRK5qg3qOJUcSt0kVH05qUzvRLZ80ZByEiP3WW5bZ/yUylrcrUz9FjKdXShkHQ3aZiDkEHbZxZaVpZ85bCJiehUECx+Lu0y4dmBHqz2pjp/JIXpHvQiBNEX3WsU0xZ+K/hf8pSQOsJQIJbLI+KGwpcUe9CxV4QLw0e1GhrlfKzWdASB0fojeropdTh1/H7pChDDMNj9RSzKqrdX6ITTaUQ5k0HF9qPlL4wRocHfzicFG35foB5FRio9WJ4xf1SlmylX0PlaiWUug4KYn6BFPQaR7jWqFK4RSbw/DVgLy33BezqPOl6iYAnlCzUO3nV+YbRMVGSFlsLJ6/cpgBUep5FMOUhdXL9J0ogNV+K2PXYLuKQ4Hnjx2lScCr75nSn9LYoGAXCXYj2KRFlW6rL9UtSo3lQOpRDdOEh1t1etLIS8U8BN1wbcadrEQiUkPlxW0UPt8PuISgWnXamlrbdLZer9MeG7haxxwOdLuUw00BwC3mCBbJLS3gUci+x3eVJYi4xwNjgVP8Aglp7TyNHR3OFRDdYQvB0eDZpG1NlY24cHmkxjpmykhT7hcCFL0Du0pZyufpExPOBYrFXJ1CwebPmEAlWAC7RSLtLzE9ItPpUlQDXXz5qW1qThPZGiJANT8FRRW7+GmIf4/uqTUR5hipeENi70TThopdfKH0ng1qI8iooSR40FiHqh9wU5sS30H5fpkSTgsFo9CadZU3aG3YHmg+CuLHeeMe6VdcToNA+Xi0svmdaMII4BRQjJAMON49U8KWcOaC9Y7K0BQimOQPep8XtP3NK2/aR7NSaRmQaI62uwTzkepU+3JFOQFz6U3i7mHTzTaIo7LP68MJwa7lSRbDR2Tgl/KSy5BwQ/Kghkd7XTvWPtzXVxB6fSCaEgzQ1uw7SqdPLGpYeKxV/QHZLQebPopV8pTUx9tZuDVURFQyU47uEClXHZHBCxUvkmhUdE256hg0RIsqOkZPnJVwFVpjYGj2fM2oQzqUJAjBeGDzdmhDbyTT80kSEeFSCBWWxwcXHX7cGfT5/pGUCVsVZegjGwe6+Ykwa1gVjtLT/ALdB0wHpHlirvEv4NB7nXBQB0EhU3DHB61PmhrvcnsovicQ9qBaMICi5vt+mSpmkUX5r7OpWPIZqPxXRWXOx0KNBZLal16eYYhFEbRSNZBNdD4P21nQ+rg/H0szxaGkJ7UK60FssvsnlzR1JHwo+aiJWDaNh3fy0LqQdgrJ5NPWlOkeYj3AZVpwPvPM9mT44rRriufTj1poQsiCdJDUzxCBm4NhxL0Re/RfQJqNKgkimDCcVHSpGDDy15a+V/CRNEZKIkRiaBJPKDzyFSAaLs+melOdHZPtikl+hv/R9JHBMHOS/NMoz7IfDy6uVRkgAOiu48swAqYA1oLNlrKL9vdU6eYS0VhhiJw7Wu8KU4tibOgaFTQpUonSwqpeBkcwSxwF+ZT3IBh1DqUuUnIyxLelunlGk0V5/TPnZUkJPiTYdo+1l4Ck09PQ4tHUWQQuLp0pZj6P7kVHzSIZb3eWTIUJFhodDyiOTmwtq636VK0mG6WD1z18ZR5C9zHLuwdauoxAbSuvY6U+ScVpOISdpohcBHq09ka7m/wB4nTzQuWUdVfhaVQSC5Cjt5ilRklj2fj7VkaBLh9zYp2eSqV+mI/UR/FccX3eUQdwd6EPiB6nkypQ2QMZQjpLrTl8Fa2ByjoGtRTCQDF1Rh4OvkhTZHQn2pyhhLdXl9Zc6R3FMmQVqOLj/AEGKlzKR8r6AS33VYVHaB893bdnn4+0mgXT18HzT2kkavkKuZcwj3fQYI6J3a2EU7+WNha5ymg7PkQIdscJbtSIgAMTD4O6lmtSQJlrAAburQPdmncuoSq6vkVNhH6caylR6I8ouSfEXD1X6FTTT8DvRSC4tPXysshAnnD5q0UT3jCPg887HE9X2lgtLqWXsdPKYRcXlA+foGT3Du0FLIzv5VwIe9B0H3B5DkL0cSH4mnilZ1bUaQiACVa4mQVdDlld4KQWRqVOWgVAFWoU2IMHo/Yy1JMpNlwA8AKXlcFmejD0ptgMuhiPW/WnPliaTUzTtE7u1ZqJqW1R4aCwPTXbvPGl+DP8Av2jM2joUuqgm6s+W1oK6n4foTS4Dew+avjMOer5dVTakUnq+TWAdJhZ7D61moPZyjcSVcBfnFJhFxOLHVy+EIIs+nBvrwpk88NOBsG3iZoEWnOYI5Oj0a2JRmfx5Y0K8DdeAUIyGZX0p4otBLUF/s/NA4OPoUq2KJhxE/ioUEQYm4W5bNJFPmSnoH4oxNS5qfPmL1bKQy8V+B+0IdaQ6jzXd3i1I+FoR2ELqDZ9I8+1XaJ8U6uQ93lMJRBXSjxCXiUMtAbtC2IWOIPx70vw4tVYKMEDlIzDxkeQUZhxULBQeZt1vYNWn0WSMaPVy+AJBw5Ti7HOhIx+Ji08CaGGpnqka7juNEJHgPh/3KLsnHpD+Xi2pbKX/AJzqVyZZR/eaX4KthoHALUbUsjE3V4F2o4fisRtFu6GhUpmb0ABCYaWWXLUjyZukHdqLJE6APNlUoZiSbCATagRjKJE+zyewvSXzDEgOrbsaMIMdYit6w9PODgEp5EO8Vs97g+bKQb4Cj3fF84nOhcL0KlbIS5vhFWIFpYnYc80sMufA0OhBSkRJFgG7j7TTvjIjArTGzAU0BIAlXgVH3yE8k4TtnlWTuQQG5XeXhDUqWFknI4NGo0hEQcZtRYg5oucip4F5GJ6RQBRiAnXC7q02UbDA7DQqGkdUEWbneUKUx4xNQIkK6jL6oKQwu7qrK/QUcuGdTo4blWSREbiYT7MJXb2nzTVwobuYPQS6nkII0SyeZH0UDcZqMuTZyDPZ5j9cbR+AeKBwdMz2KsqtgHMbyQPNF0opTiJUsBQdw5LmB1DFOE+AYN3Y41eBWFy7TpHq8K0uirFsNCk4pAFXkUbHPUiG+r1ig3IEEnEaclpzpQDBxkXamSQuWhZG4rXGxQGp8Skww5JKSxNzGk/8eRKJQaqxQ7A6akleq+n0ZpIgIJ1Mejb7NvV3GPnzuZWztVrzM9KOYMliM9AdystvKNSskZtWmOkvMZtS38S3ZfFCIA3dafzRRLKxU+MU7FD2mgOCnf8AZjvLGxfapq0oJ3d3gXaI/wBDRwzthegiiul1fNC6KRkPUOtQia43N9+lqONS5fkc2nRgmeZyNqkYIwCN6Qd2h3RgkXKgUXpAdBShTyper5BITJeoB5caBB9BFPgZq6r7masd3B1qzVa0Tt6H0rYkM3sf96UkKfZYHJYHMv8AHnM0y4tqGXWNzrSPM01sHM8yYWfpDDQwzSuhWVqXCSQYnfn4GWGyfZkdKYJErJeK0wyJNqYY3bnMl31pQ95VK/RU4oTWHcOTjSGKyBYOwlBkJgErTg5Z+wX4HBlqPthYhC0jQ2Kc+afQwDVadXIrmeLAMjJX9Y8H7KbcqDcbVlPD0Y859iLQow1qhTBtzbXhfzx4xUVFRUVFRUVHhFRUVHhH0WRBKGEdyhBeZZnSc1JQmV3KWgSAEXd6qU+cXpcdAMuoUzWWXXyKU1X7PsznkC6lnueA0RWwNDgcdSnmIKhRp5Q3XM4LJ0oiDz8quTxMPE80uY1C7UYSbCHvqCQ9QVPQjvRC6cv3aMBXVH4K7Cb8FQUtG93vX7h81x36ca479ONIIC4n5KYg44kKVXhAE70S6U/jU+7DmezUpwj/ALtGTG5T3CrkD+xDTTZMrF6xTKE4E+jKVLv9CF/4ZVUNtJFgyPbjfyGasxHYB9msyIAWHF7x4wiQWoWDcN809Y4gzxHU402fJMAMz0nJy8Iq1UwanoUsI68HIsdWlgHwHoqLiaMdqvjN3+HjPrXDQ3uhTMqb/Aip5lu2jpNTC3shOxRFQ9x7KlwcmRezDT9QZpAVjWoafNDtQyEMuONbaSEPcPtU18RJ50WPAvSqpxNNg2Cs1EeCiCsScWKhAYEHT7Je8rHd9hUT6W1Lno6UyUtXXxnY4eFcKMh3RV3PcWasQF8B4jPMpgphMj5ArFzc2eA4OLU4zIC/PyfGBcaiLGD/AELAbCSd6cV7Ml61KrSzWPFWaiPSyO+H40pVAHixULMuC76XUIIB3f2WkvUZ+xWMLWS9ir5rSiLlKrTq4qZN6R0ooJ0ZQtlY6BSIiplVlfAFaSqwMpoG7SJ8kIHuG23grxIPSx3j7JhFIku2BTaFMaDoBoeUYZKloGNdwBxZ6KnCLJFPGM9SanIhmzHFM+lZYQMR60EAFVgDWhJiyo6Bq8KdkK+SZOx/qDFvAK4ON6Y+atmhN9k4JD4d3HPagSAGx+WhYA4r81KgtVLUtT4PJB2kZ5tTxIvYO72lLPhacncAx6v2RESR/fB2+kMXLUngmBZKEChDWDL5aUjIq5fKsf8ASY5vJGSpYC+p1y5TUMT4CwJqVQ1DtTeNhRPQpWHokY4b3BRNR7Zo2jT3UELhs+BlJgdPPrigPkC0DH2ThL0kPEz3UabnwouswLhuFkpIY8yHpGWhl6Ug2OHAMeZQW5/oncKCMY8mkQI2RLJRSWRtib9DTQiOFRScB1kcdR1ohKNGF5gGmBDR16KgLccZB3VQ7QWbY8N3FrQJVxTGF1l+KzV7HoZgQHK0/ZVGZFxLdnxSMmaQKC06ksuVGBHaocJkj0onRiQ95O9CqKdJvo0xIePhg1a8SdyF+WfTzwT0/wA8goIIPN6hjgmOpanLKRNE8ZYqatNzFKiA0LikBOtrQQODuRtxrVypDELPNu+/2WxUZmgyvr5sVLu1O74G4pzhLd6UGEEDYI+hOTXMf5QbCuceeWGjUJGC4LBh1z1rHkAEWavbj34VvSowDLN233uFMyG52A0DQKhfK5I3fxVtCDb7IEsUi7ohsZd5+iEtZeOyZZd6HvSyruz9CYuUfAZ/x5rWZ+g3qLsh36OpJRRCIlkfGRDt1SOhQT08gesvVqwroQ3BOalN71lSpoVqX/I5+y99TIWVTu8o/VyY9JKj27CaITbHg4REAariiBBY+qv+H0nMZ/xoIbudPpJcaJyD5M4dHxlqX18UYTlpBocDWkQ0HDH2UYRp3JxZ1Lp7/RCSDv4dD1v0pHXhmsJQDKsB1qREf0DFOps6B+WrEvjnxQWSdeg/VfylAlzsA9L9qiW4lLTmZKnHVU4/wNV6fUzQOPMHsX6VDE+WGtyxxxQiF65HRtTWvZlk4bPDFYzb7JOXja0P0KSPPhNYqFbuSdg9/AityMDitNMhxbfk7VLBXAh6K1EMgT2rRu2q0YGL+NAv0Y2mn2BOCvqFEhTnvomh7hkQFO4S0LFTAUFscE0eFWxQ+suS/V1wPzUTAG6TbojT4BQHU8tcS4KZKayXVQe9KdhJdhGpRZTp5bvwoTJQjYZpjEoJrs6j7JGRWeU6vHak8xR2GcmEe4+1Myys+AoHMkonk0MFgwFg88uJQpPxbiOi9MQA1Lcj8qITzD/GeZQbEBsuzw418a/Ri0tjdplAVlBe00nClwb1ilrEfg+7UKb+iGPRpiIYKXYjv9RzWlsBvDM9kmONFSIiWRz4G0c09H86I9eMlusr4iARLFyyOtDpDS4jFOu4xxLnz9jMWXx3aHrUlGEd6ksAiOY4uxTFA0RPZespBjuxp1pPFJgg8pwU6EsPq9Ohb6yt5yMxycjxqJwzPFS0d6iWrCRsD2dalc23lUQFwpgOtIFlof8AKl5UwU+0FPqgyB6ChUegphbPQqexuCHqtRyKct7QKdF6sKOrepJn6oYZ2paDJHKKPqk9auBTFkNPk0Zy4eAbBUDmuEUjFSY0IgAoGzf5piNX6kfY2jhUdw/L4C8AAgujhyD38BURCyGyUm7BHibvZSUqJQAJVdKhk3Ub68THOa5kt/giCEW8AF1qQJpQyDueRMhmID0IPWjgfsb4pMA2sKOS/hP+BNydNgS1OZLQaDjoKEcwqAPLzgoTUSEThb4rgZDovsaaKy6/8VEf5lijXARDSCPjw4P1oDhE9ajUcdvU4u1SWWJWbA8Yu0JgHEx1rSRgJzXMepXMepXMepXMepXMepXMepXMepXMepXMepXMepXMepXMepXMepXMepXMepXMepUtz1KbSxuVLh6lS4epUuHqVLh6lS4epUuHqULuPUqXD1Klw9SpcPUqXD1Klw9SpcPUqXD1Klw9SpcPUqXD1Klw9SpcPUqOXqUkbPXxaeBns5C/L7UpzHXTOxQGQpRAc2l6lgEi7ZpI8XNhS2BNZkidWaRouSeKA+fsbTaMHq1+22VbzWniYeAqkYoGDzjI5rahgRWJ4kpU+ADDkUr+xX9yv7lf3K/uV/cr+5X9yv7lf3K/uV/cr+5X9yv7lf3K/uV/Yr+5X9yv7lf3K/uV/cr+5X9yv7lf3K/uV/cr+5X9yv7lf3K/uV/cr+5X9yj/ALlNZVXV8YwEkYAutJMN4NCw+etGo2hEMSWwWmaVOlnvMvqaUllaETvcohq3pZEh0h8bb6lN9a9IOtOamI3oCx8/Y44+ocv+qBfDXQVOPUk6+VGhZHVBU9TvTFKtLrL2HwKlBLpkJDQd6/m0R6p4gvCaRZCVgwt45UyZulAzakWxU1B0+mvVUg2CGnOv5n4V/E/CoD3ZmOElBLUZ6syWBtA70IXALiifTiirlQbDOK/l0EU6BwSZ+keQLFyRRkcuuKM9RkcWKsMmfAQeCJoIRxP4GpiIisafkXwBWDLigKwMeFm7q+1YOmOG70KiaFHgfY3NMzeT/lDDJkolU4nk8lySI23Emq7UyuUqgRkv0pvUePxiu7+x4erVodfpeUvHDkLvcoYfC7uHhv1mxWK/b7fpHj3IZQXdhQ8XDQtHqy9aCaJCcYDtNRQSxiguQD0T1vVtIL1fx4RAgj4svQl9KapVWbu9RXIzL3fH2SFriHV+KKKDMHaAydmhIbPhIXwX5Ck0n1cFgPSKaScmG4iZm9CWyFO4xSMszb1qRO9GCMC1DmyDNMX41et+5woRKASlpAYMUG1htSMjDZaZv1PSlhBeEIC0DKqeRUTnDnV/O+og797lGaiMKJGEamxQpQqH+VAkVLv/AHpx/ASWcg0r9M+KXRrgooYDBSIDJUgktNN2d/PetcUSLSw6f73o/mzWaEa+ETym9c1/S3WkiroMv44ekeA+3KtPQlp1iojsbHVgrWi7HvWZxQYXyPtSLEo4bvpQqgURru9X7IXkrLgkVndnQaa0QjPM9R7VBIuPhpPDneVBBC1liIzShNmowhzGXvea2ZA4rA6360/eX9IosrIFhdr+BIMDMS5FpkoiVg2DLYaWf0fShAbBUCQgxI0aDhGqmAGmMILZFHtTpNhTLhPmgA1qS4DhIntSmYRYXBfxUb8WUkwVe/f9KC5sppOtWtsKEHF+t6AQwM4WW41+x/FJfQCIpGw4pmyaiIABlVr9j+KbXZRdwznyyk/kBFrIU3r0cE5VKHpHgEsFFJNUWYe4+1I/LOjS52UAAgkAaGnhLsWzmBxQgqBWXufimfAMxAVfU5nBU2irMRoOT5GPsyQNfOG3wqftRD1D0qNo8GqJ8CNSTXiU6RSPMuvRKgC6YkuesnSpAtr0C421d3b8ulAAQJRhNGl+zdTmpp1Fv4E/1G5XbUq0+XFzr9JsU3NeSaU/ry8Ja/TbHh+m21i/pHwVr958gpPjgJWyxRggHOzPQlpNzd1aC+pK713Vt08J/wAU9zY6GaOOJMys8jassy1ZRcG30RV0tEaDQcCpPxsev+KKOEfQPszkB6rGHUri0MwGzvM6G9TujPgpSAyuBxKFMMosnu61ExMnqx+KAQITJRyitzLrelulD6LZesm/Glb3uX806wXcjmikHEKGCSM9adGDnoYEllQK5g3oHNLmhmo7TcZUGSsFpyRqHkKchlEFwnegX4P5q+0xS3jwUG48jm+2GV1nPGlDgFw/NSROKMGjgMNYr+pogc/CAhGYq3NDK0lMVs+rpDZgBMTgbeJIEDpUWjrR/wAl+aQXmlyU46+MELsS82rIYcGyZ/HSpLXBCdelFWghwM9a51IwVJJHqhq6G1BY2wBgrWck5Ww1auqWgNju7ql5MDSrRSBCDq7OB9nLO9SNEnA36Go4Gv8ADwqBUymU8nLwFGTNHIJSwGrq4YaVOeIbHdsu5UMITFpkdGSg3EXicvX3pIYcmfC7nfY+keWyYcHy96pjAzfwjjUcajjUcajjUVFQL/8AbyBA3aMog4xGehLTJylRutQYRMxqy6FutcvCGF2q1R7u98HGrYVhnLB80iBFMAErSEPKTJrzdvtMelxdD+cUrVxWRM0MmGEcfqjUiarj45pSYTLcnFXdOYMnoxSCiBkdqNVIQtrT62fB0vZSXmxX6t8V+rfFfq3xX6t8V+rfFfq3xX6t8V+rfFfq3xX6t8UQgbkOXp4iXuWzwpY9fN+x/FftfxX7X8V+1/FftfxX7X8V+1/FPl+nyr9h+KtcuJJHMPJ3dD+ElhQS43jpT0zharUSrF/SJfB06DLVnosoy/H2KSWUrnpwKxJYDHF2KwZ1nL8N3jTmdftSQhFuw+LUb4or3ksuXz7KRSOfGYI2+Ehp7FnE5g+ladWlsB8luh/gnRZM5D8lKEbngOts5FPZ+lijAPKkQFQwa0TgGDeAu81gOtWSjQs2HxSjgpmNcfD6+AYKgSxK4DjSeQX4g4O1s0irULJTgt8Hy1KUuNx19sKuZRhHJQ0Fm2RquJTjAxOuzwahNDi9U5ankK71OGrJ6yelN2BXZGaiohjg6nrP15HY5tL8TTs5eA2DN8Ufz4QCkeKhMen0BIPMKIdqzGyHnaig4Gdh6USMFmTFNBiC7cHFqPkECQHj+NC1xFQJQbgy70MxfshrYnWCC1NAjzeXD8qWeP260yN9XQfzS1mw7JonBqciJoOFxNKJHGLCfCbVzt4CMYIwpZ6MUwEou40GWg3U0uWfX6pix0Ug9/CcJGXwm/aiBBGVkZk8JK2Kzj8yfCcgEUTKk7GhCm3nkV28sUV8MIaavu9KfYO0LSlAjVOE4U1ldgd2lh2sn0gqPlxSxJSycgKIpjCA6eIlJMGX7dbYl/T+kbVq0QENKLjp8uw+9ZUUZOAZGotnjUNvK5azKcBjA9T2pmYCTRNR4JNHTCFrpZBuXnaKbZQ5/TTOa2NdHKkDVGJdRT4VGCDBYDGhVpB4LcMPFMNFZUd4Ex1xQOewhZKi/CKEwkAIllCIKlpnN6o/QMB4sSKTCxUUmDW4AiwwCJvimqNtyrmmQGGjEHvQFs2XIseCj6Y8ta3AGNl/54wnai4Gq0jghavVc/t9ihoisNtxx0pLz6B3HDRUE1tcCYahT8PdSz6lHnUArHUmrvdZZC6vxrJvNCuEBpmXFpObbUclJDUhJbWlqx1fQkNx4UsE3te1GC5i5zHHuomhDB4FQJmZMusb0iaw3l3XChKQJtTKcDByoAClxNIz+MuUo4JnSpFCKaUOpvKgZYL0IIJDUSSsZ8ZuTxJS8uSXiFae9EGWkjAevgqZFooiJ3atqQMUIatRqfR2SROwmpm7Kt1fCdYshd3/AJVzJF6Cx4cWs5ayb/cTKVaYf2nThr+a9OsCxJHtSkl7yfiiw5mNPVpJCF4dhl3pW5JmIRkqFol2NEjF/wC0WFll4xOsfRJVFJlLEEDYttWDARYKSZS+J60EkCYprUKFF7CiTGYtTUUDAXWZ3pX8CYB+amyMGCiWutYgiDoWxvVvA3UgR9hISYNkb+tNkRnkpuDZKkkuePiOY+REQLRnIzOlkVo44bfS53XwJbAMNOanFxTUHQF26eAKASrAb1C+CYebn0KMeEqD2Mr+MLnv92IiXu2Nno0K0SDo7Jzop0oFbdk2aRIkJk2qRIREthLfS2/nKhr29qDkRphmjSdG2285zTAoY6YuOYYOdZcG01GwlvMOSfIcKhoC7U8UI4D1oAEAwRYrbM3kpgcALqsB1oOi4l6WOrUeBIhR3HCaSGxwEBcDSnUlAoEIsx0eHIDxmBXATS2zdCWGCRhL1f2K8Jsj3NJwa3VagkcoWeHdaMsTMLH8+1etdFdA1p6whPeOdLARttH58TBNL2ny1zz93vVmRmdL0oZWmd9qua1og9OawzRkhQqOBM+VAtlNHwWgMpRE2W7wqJenJwoHSH1r2qJcTFCE2N2xRsgMhn3q5FNy9oocGsTPme1NqDhR9Rt2q6FUzA9YKiqMmL+ZcJNrUUTXTB2Cr0jAokgjERm1CSHKa4V7pvRXMPFLD1dri7GaQWXiZzBs5KO5FXFjOotAbLILvuu7pQduUeusOq70VMQDKsOtRc8JAl6GnOgoOIYPy16+Gsg6DWmQwJIb6HpR3uUg5B93HYkjUclXvPO7j0o808myZH4pM0G2LMWJ1D7U2WhPglkkHCiZTkvnyDIoZk66DBQAMiDuOHw20WKOpfvSKyu98qGSw1v/ADVrN4Ee7UyTGYSX0Pmo4EwPclWAAAwBEUiEJk7bhb1A0t1tujjuUUeWSy/kVJeQXo3M30gqVnSm4yCLa0GLyQ7eESuNpqCrYDJygtITSbklcLxstCZIkfGxxajwaaYaHy60SRmQKXan6EYGevJcB1qAk2GnxwczLWVz6y9aJBJu+VYYP2WChpG8w0xeAHlf3NXYoNC1m0Lri9MEXRKMFg6TRBC58jjahZyzAsAForKaUGBGzP3U2i47V16qeMqQXE0aBRJDrbfL3UigiZmoDCvcCk2cNtqMEraUsCtgzQCS54EE1lgyWnhNMhbODxkZi8UJmrBK8w7NF360CdMk2koIgmTAEFcJbUJZBDgyBC8oOXjoYwMm5o0BxacLoGnuoqXxcCxxKlaOP0tUUwCLtQsVCylKE70cLlqIdXIDktNQsCiANWoChQ8qL+mCrEjNsHKhA+i3Q46+GKFNJdHAgwFPAYCsuKUaBg5EBQkzpUFsBBypx3E2G3Skbk4CBz6Bir9Cqtd291UatWh0Ao9OGePiWjmKWud6eAQQdHR7fd567oLTR1a0oR2oI/BDo9eKYavwkSEcm0zvTKkhhQN4zTJkhGN6ulqNqxfaiAfhKAMA/FILycdL+ExfFENdqETw7Iq1E8x2ESLyVaVA4UgYzdqVZpyYK1KDkzmpbZIYvr4LBjHBCw3aGaFeaowAZaOttlwdG+tOk452nPehgDa5rRhkM3xyaNyxdOwuGVEozmsENi30OJ7UTjGsHANqaW8s7kvCxU4gwjbIamoaILreo7qBGUvflimkx66F8CidmW8FmVHmRQraYmRJGlKEhMoC+ovWoDCiCnVvdpU8YzRnBU+J9P212r58MpYBfrtQzcREsjnwxs9xOe1RHgptY1OQoygyqRPFsLgCVoImwrk2mhgNKJHl4Z+zipcVhGkASatTdxKdaWb25UYK8mmiNE5nWoFTuiR2naowTQpkvE2tmplhRhK8nTUo3gjmquNSsQMlDG129ROEaQxqurUkWGoKAIcUqBwUgcjRjjGQBoUoOQQgMMI0nS2aMaly6sqvOhR25zBJPMoYawYWFg6TWZCMbS48qMjIImWBk3LxVwDcELKEaTpypxIzNxPFBEOWaHV8iuz2349KzCU0alQhqNafZDfJNXGhskCBdWm2E+GcB2NaMbG/EX5fahRHmQQ48KKOFuvRaE8JngwNie9ABFAS93rY5Oe6m5FZXedL9DWv3fHydvV6cPvUgoGBYznLU5ISNabahKlwTDjpSwVRKYPmpUjCXmkILIsHndaDN0iRNbIfBANgp9h/A5OlJURSSjpwpyaNkBOEVaeHKRj11psAQMpqH4Ff4dKxObesMW5UMoOAY1cv2iGUcDfTfzT2mgf3FRACJe2g4lEZgbhCNxGnBevBTHAKl2C2OWRsHqoZM+IWg1poIBTCZl0VPlJsojQSzyUEoVDq2E4u4UYoIBSmWgT2I2ZmzR40TKMy4YvterKNl0aBCXVsighl3VGdEiHLkm1GJCrlqKSGSMLNXVEtiy1RCdezGANTKuZpGooAgtMZDjSesZcmnwaNTIJSpyWbCrtm2UcNyh5dHIE39VTJWMcbv1qA1y4ee9RQSTxwJfipC1xzErWv2W6u4e9foN6/d8fJ29RWSTiKQ5k1LG0rq93jUQwTGJgl600HVuTSxcUjOrHwaMgG672rHO9AGAQNLqc0KQFwbqwV+i3a/b4KGmbIHDRCNyNJBp6kICZE350QsKKvbcftIShthg+T2pzQsAXZ6/jTpTgFaw2nfSo3qbghKUN9hoRRDXNj604UQy7xduFScAOIWIZZJvSC1/INgMtLFwhAhh04VEJOF2gZi8ACdA55UhRsuBVktig+QmcgWR0iKipKvChi6iAQXCpGpSUiCZaMcKjYOLCcXYMTSi5bGoILKXRm9E6yCyHccNRSoIkIXyXHPCl1oaGItXDYpkbgHsacKaLoGYg3LioiYiCHeWRKxjd5JPgs6hPWWoDCMealcK/Zbq7h71+g3K/d8fJ29Xafnw/T4HhYy9a7hXcfau+r99u8CMiv0W7X7XBTrX7nBX7bc+1Fr0colWOr1ZKEapCEdGrllxobOR12qYWw03NwUSM1LLRMPK+4RpS2oMigsDpegEuIRL3J14UmBQM0cgWTZM0QmSmoFoty5zU4uIo0HjHQtTZoSwQTLG9A2TJyyxblE8aN/ML59KamGWgRqsHFWgx3kvJbTgtgtVibIMN22lS1wwqvS2JC9Yw0iM2Lw6lESLQ+yNDs71K5qBc9kxxntURxsWA1Q091XJAMSGJgbjFAK2cSFSXQ6kb1AABAWCPCIi4S4ItPpBk4lGqlgcMYpw+z91YQVSA1pyDgZJa/d8fExTsUrmM6RXb1dp+fD9PgeFjL1ruFdx9q76v327wIwUOl77X7XBTrX7nBX7bc+12muPycSpndBW0EqDkAezuUUgfLn3PZRRBMnUkt3ThQI6UguEljXGaAl00QjgZinRCQVNIUFIQTR3olBYXPF1adaV8UgolhYZODRMgTIlvWjSynIQKclBbxgs3bVarEUqBs3vFqiXtDBIxabVihQGGAssY63pKFQZSsksAXmaImVPrZ9t2sqS7jJMGv6v45SiMF5xR2lAoANjxQxQlNlzvSnEydEp515sV7nVvVxQjGRCwU0YgiQKNeNNfv+NNpxa7eisVDGejWplYSFyJ7123tV2n58P0+B4WMvWjQYw3hz6UIhAG6sBQMhFEwkvALBX6Hdqz9WFNSaUJUkwpHP94+2P4rqG/4nWiXA7G0jDFL52WwlE4OXbjLfhQmVmcGBxpJDoJZIY5t6sFUcoC8Bq0/xKJBJMJvwoKoKlISRts1IpQO9TEEkY3UriakGMwLkhLlRoggEyx72o303K1wcUWoEEiFPVpQwwXE7TrUdWSLDt8GtdqCuJBy3BytQREgEAfQd/rkte70iGgYRyNTg5sohzRNQyHyZpdjd11AQFwwLhR3s+AnqmaTL5Vy9+VZNLA1jSntqsGxjtRmgkeLytPehAII3KX69igsGjUd1KWh9EanouvQI9KnBypShbObRSAghy2dqZqOWcpR70gigER3KJK6kAz80FAIkvS3tRXYLDgJ9TajOMpyqD3NYyRaMEL0IBBCRNT7Xg506TRYYSTUSSlpLs6HRHUoSgGRLJVgzgNjno53owIkix3QqyjXAjPdqmaANOXKkCBvAxeokjFXFl4NKuh+V1QtsLYpfFYAWzi+jhqRaMFMJqm04M0YJKJklOHWdadebtbYalBiKNEiwWi7VJVSaEOBq8Wsl6f1BSH0TaSX1r9iLp9HFLDbhc6YetDcDEM6rFMiJyu1GhM7sp4g/QL0GaaqqUI6E361pAAbFESFCOEq6MKzqcor2q7hQwW77ta3qP2fdClkAMeQZ9LeAOZhm3fZL0VBaaNaKzem+lSgoIe0CI1shRY1lOgbKj2oAAAgAsFGACEM0ZrBxSLrMvU1gXxg1+A1a3KNvudfikIJUFxKh1WdLKMp0+14OdSrBMcQuzR1AnEfdfFMSht6AdPaoYHSkBvKyOpTQTzI9C9XXTeHdL9qfmCQOfTNE2GBjpUWiFgy1fSG8AnTNFseZ7zd6FG2BmUU45NN1d6dLEClfxRhHGU/Hd2ppKPS0VfXE+g/P1MFZEKbRmuldA0LYK8g6Gb0/MjmF6MiA3xKLYtQaUUxJc+FWIJzYc6aSrZAiNZw1FIVjbRTOGkiwMwbqhjCBHiQHqE4l4UCggo7eRaBZNr/AOTSDdMnCRYdKZWDOX5Ukg1lMnRpg5iYLjjepKErDkjY3+14udLaCDfmr+yqDSSvZITROO9SgXV027p6VEgHS8cimJjZCErFDGUrctRUbYIe9GQXsj5pUpK6t2s04HoWT0peeWbIHLHM1cXC/fmeC1H5KfihHbXOz8fTlMEpQ3lfagwGI3DeFnNS6EYSTpjvXTkE7UEzyFg652qYNE8Qoy96k1mpUlqDdgyYysXpVS2EiNG+ambSZXKvpwioNHhMli0c6EHr5Bqw+ECJGTD12qWrdno0yPUIXs1tyPAzSkQKqGiA4U0ER2VPeipgTei9jzEBR60ClEjhOK59KxQ0EDofaxhna9OTu3elEVZenjkIpEzTaei9LaHu6SGvUjJ2FRzrtPerSFuP5qCQnT8Qd6Zo+4J2r96IAb33Nb038f3vGv0NhPmsfSNWctuyW71L4KdhhGl8vxQOZA6oogrKcUU/SO5RZEoRLNcONEHbwOpepMdu1EBPAGCsHOn66jhUWE91ES6kgnlj7poNCdmlInKtOtnuifH0QVAy0EOutez5LWZvs+acti5ckqCqY0+qhaCPUH5odeEdBaYzResV/KOFcPL1eBSUE5fNKlQEGJ43tTYNm5xq3AiJuX3pb1kiXpVgttOLteJTEk3AEY38AXAtRAphUVcdqBkbCw4T7gofb3VFdh9EQkHLwyXyIZp9M0KMmSv7J59NQFUAJV0qcFoYWPWltAWFyAPipK6vrVKcvAdr1E2gambK/Z4OBGGUSNk1trQ3pHUhFR1vxtatRsnlkjcrk0jE9KhGHzKeJtXp75XGcu1KJtBxiGetRQvMMKcYzU5q6lUyZbUlUZlJPBqM4Uamp0+3sZk99Wldh9CZnBmu23hq8jEZW9L/ABWVa6KPop9Mm3WQTtVokeCPpMU5D84FOE4fmn1/coWrMc1imEXl0A8O2ezWK/dbFYOddyrsvA/ebPCLICXBLNlGgsNiVbPC9qZfDBYW3nbnUlJAFJmHU+3Tt2firauw+gI6ct3xxfIpZKScVBUI4r9wTD9PFgJgStMvxRFxyah8nSNkvYpj7L0JokDM8HFke9IcRTLKODjSyr4ds9nw/ZbFYOddyrsvA/ebKNamCZhlhjepyUSZAPZwUnDLC679vQ7I/aogp2te+X584kHGkjxxfJE1Mlk45IpNis5ifHhbf6ViLG0EUNSCSAS1jpTjKlajL6NLtpCUBl170KJBeO8WfHtns+H7LYrBzruVdl4H7zZULzipEKm2K0zZtpFAAAACACD7cPqwJ41D625I01qkOTfFaPKkeZ9gecYZ2oRBNfAzWbn5HCacwAByBq4OEHEHwtBMyoo0WF5zSDsGTcfpQrkhAGVPC/OlwphkcBdbhRHQnCXG81cyjn/2pE1zCHozXIsrc5mlC5wez4X/ALVisHOn+WBPJisHVLPAgByxeitKYqpM5yeGZfIBen224lSIOVcLBV5kOqEFMCVgTWWKDiCHII+hYdnxxfIk20aY0TG4n4aWEYpASVE3Iz2otGlRdMJJ6fQinfVBYDcOOlCoTlKTzi9MLzwohWR5VCBRMqXIikpbmE0Pl0kY6t6kmahkl5nJaF5q948UI+wQ1qlCFnCNazQHaRTW9GzFFkOrhWYRhKjGVqSZ6oUrZDSmgDkL1BwK19htFHfIFiHvdP8A2nnzGVmXQuD7buGn1q8COyrSBAu9tG7N3BiD7gpZL9DvPHX5UAEyBd/AZ6UwIKI0FzSm3yjEm51HfSkEkpXaUqhYxd4+hMBEQm2h0qdoS7E+te23kd6JMwOpRlUJQI73oZZYtCOlXAYFLLhK16sgGwjwLqMKoY0hVSRvK9AAALBpUxQAFxo+pUtkywp5StQoI6Cq837cwiAZTAVOZPlEMBpLFCgWFqJvoYwTSGGzvF/A/RiZ1Z8cnLymcJg7JFMYADwbNPCkkvhnESLUnt1RYEgblFdESsN//CxNMiDC7vIy1GAjGvy/Krhbu0OmFAmOGk/lVlgU4CYZ6K1Zec7aLex+hCbqAADB42mooPIlvCzocPU9qUgODBpocorMvEELutGsJNje0d3HDQDfaQubDSRmz/4JgFUAJVbFAAaz2netBi5S9DShAjKaDnVoiA2ChJka6o29oqHhaU5TKUHEGexZU1Plmo0+TyYPNDhFtTDcanNmJjORRjvKCgjZCyGzTIktb8vf2VfYNotXDV1qy1JtuefP/gBoFf8AS7wpKHmwY4n4UD9sBUfQxyOXjAm3ZQxQgJhehELN2CgB1nzhKG9AGzyYoweRqCORB1iiFTwwTEjzLlA6mhN3wFERxRODBtvOzgp0wwdQaNaTGwc7Z+/FT9StjjWYSsthx3eNGxtqYFABu5Mryfx2GlDkquJlH3KxYI8ajzDkr+bF5b7lpElKuxaiAtlDVoHmr5WUN3yz+sNPbmBQ/wDTjVvOEX4Dv7KICeQkG597DwK7', 'a83402fc91ca54f362c09c927eafa1ba,b1da7839edd4969a1aaa4435721a149c,e7b26d653c8b64a48bef062ac0b67374', '2018-05-14 18:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `user_notification`
--

CREATE TABLE `user_notification` (
  `id` int(11) NOT NULL,
  `notification_from` varchar(100) DEFAULT NULL,
  `notification_to` int(11) DEFAULT NULL,
  `notification_title` varchar(100) DEFAULT NULL,
  `notification_content` text,
  `notification_status` tinyint(4) DEFAULT '0',
  `notification_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_notification`
--

INSERT INTO `user_notification` (`id`, `notification_from`, `notification_to`, `notification_title`, `notification_content`, `notification_status`, `notification_timestamp`) VALUES
(1, 'Admin', NULL, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 0, '2018-05-17 22:22:10'),
(2, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-05-17 22:23:42'),
(3, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-05-18 00:37:35'),
(4, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-05-18 09:48:29'),
(5, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-05-18 13:05:33'),
(6, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-05-18 16:44:21'),
(7, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-05-19 14:25:22'),
(8, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-05-19 14:32:46'),
(9, 'Admin', 2, 'Result Pending', 'Hi, You have successfully Given Your SSB Test, Soon Result Will Be Shown In your Dashboard<br> Cheers    ', 1, '2018-05-19 17:56:37'),
(10, 'Admin', 2, 'Result Pending', 'Hi, You have successfully Given Your SSB Test, Soon Result Will Be Shown In your Dashboard<br> Cheers    ', 1, '2018-05-19 17:59:56'),
(11, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-05-22 16:55:41'),
(12, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-06-21 09:25:20'),
(13, 'Admin', 2, 'Welcome Back ', 'Ready For Test? Or Looking For More Test enrollments? <br> Have A Nice Day.<br> Cheers    ', 1, '2018-06-22 08:48:03'),
(14, 'Admin', 2, 'Result Pending', 'Hi, You have successfully Given Your SSB Test, Soon Result Will Be Shown In your Dashboard<br> Cheers    ', 1, '2018-06-22 08:48:19');

-- --------------------------------------------------------

--
-- Table structure for table `user_ssb_answers`
--

CREATE TABLE `user_ssb_answers` (
  `id` int(11) NOT NULL,
  `test_score_id` int(11) NOT NULL,
  `test_ques_id` int(11) NOT NULL,
  `user_answer` text,
  `user_answer_remarks` varchar(10) DEFAULT NULL,
  `answer_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_ssb_answers`
--

INSERT INTO `user_ssb_answers` (`id`, `test_score_id`, `test_ques_id`, `user_answer`, `user_answer_remarks`, `answer_timestamp`) VALUES
(1, 54, 21, 'qwerty', NULL, '2018-05-19 17:10:11'),
(2, 54, 22, 'asdfg', NULL, '2018-05-19 17:10:11'),
(3, 54, 23, 'zxc', NULL, '2018-05-19 17:10:11'),
(4, 54, 24, 'edc', NULL, '2018-05-19 17:10:11'),
(5, 54, 25, 'qaz', NULL, '2018-05-19 17:10:12'),
(6, 54, 26, 'wsx', NULL, '2018-05-19 17:10:12'),
(7, 54, 27, 'rfv', NULL, '2018-05-19 17:10:12'),
(8, 54, 28, 'vbn', NULL, '2018-05-19 17:10:12'),
(9, 54, 29, 'ghyu', NULL, '2018-05-19 17:10:12'),
(10, 54, 30, 'ujm', NULL, '2018-05-19 17:10:12'),
(11, 54, 31, 'oiuy', NULL, '2018-05-19 17:10:12'),
(12, 54, 32, 'qwerty', NULL, '2018-05-19 17:10:12'),
(13, 55, 21, '', 'RESULT DEC', '2018-05-19 17:56:36'),
(14, 55, 22, '', 'RESULT DEC', '2018-05-19 17:56:36'),
(15, 55, 23, '', 'RESULT DEC', '2018-05-19 17:56:36'),
(16, 55, 24, '', 'RESULT DEC', '2018-05-19 17:56:36'),
(17, 55, 25, '', 'RESULT DEC', '2018-05-19 17:56:37'),
(18, 55, 26, '', 'RESULT DEC', '2018-05-19 17:56:37'),
(19, 55, 27, '', 'RESULT DEC', '2018-05-19 17:56:37'),
(20, 55, 28, '', 'RESULT DEC', '2018-05-19 17:56:37'),
(21, 55, 29, '', 'RESULT DEC', '2018-05-19 17:56:37'),
(22, 55, 30, '', 'RESULT DEC', '2018-05-19 17:56:37'),
(23, 55, 31, '', 'RESULT DEC', '2018-05-19 17:56:37'),
(24, 55, 32, '', 'RESULT DEC', '2018-05-19 17:56:37'),
(25, 56, 21, '', 'RESULT DEC', '2018-05-19 17:59:55'),
(26, 56, 22, '', 'RESULT DEC', '2018-05-19 17:59:55'),
(27, 56, 23, '', 'RESULT DEC', '2018-05-19 17:59:55'),
(28, 56, 24, '', 'RESULT DEC', '2018-05-19 17:59:56'),
(29, 56, 25, '', 'RESULT DEC', '2018-05-19 17:59:56'),
(30, 56, 26, '', 'RESULT DEC', '2018-05-19 17:59:56'),
(31, 56, 27, '', 'RESULT DEC', '2018-05-19 17:59:56'),
(32, 56, 28, '', 'RESULT DEC', '2018-05-19 17:59:56'),
(33, 56, 29, '', 'RESULT DEC', '2018-05-19 17:59:56'),
(34, 56, 30, '', 'RESULT DEC', '2018-05-19 17:59:56'),
(35, 56, 31, '', 'RESULT DEC', '2018-05-19 17:59:56'),
(36, 56, 32, '', 'RESULT DEC', '2018-05-19 17:59:56');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_credentials`
--
ALTER TABLE `admin_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_credentials`
--
ALTER TABLE `payment_credentials`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_details`
--
ALTER TABLE `payment_details`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `registration_details`
--
ALTER TABLE `registration_details`
  ADD PRIMARY KEY (`course_id`);

--
-- Indexes for table `registration_enquiry`
--
ALTER TABLE `registration_enquiry`
  ADD PRIMARY KEY (`registration_id`);

--
-- Indexes for table `test_categories`
--
ALTER TABLE `test_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_scores`
--
ALTER TABLE `test_scores`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_series`
--
ALTER TABLE `test_series`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_sets`
--
ALTER TABLE `test_sets`
  ADD PRIMARY KEY (`set_id`);

--
-- Indexes for table `test_sets_questions`
--
ALTER TABLE `test_sets_questions`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_notification`
--
ALTER TABLE `user_notification`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_ssb_answers`
--
ALTER TABLE `user_ssb_answers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_credentials`
--
ALTER TABLE `admin_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment_credentials`
--
ALTER TABLE `payment_credentials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `payment_details`
--
ALTER TABLE `payment_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `registration_details`
--
ALTER TABLE `registration_details`
  MODIFY `course_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `registration_enquiry`
--
ALTER TABLE `registration_enquiry`
  MODIFY `registration_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `test_categories`
--
ALTER TABLE `test_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `test_scores`
--
ALTER TABLE `test_scores`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=60;

--
-- AUTO_INCREMENT for table `test_series`
--
ALTER TABLE `test_series`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `test_sets`
--
ALTER TABLE `test_sets`
  MODIFY `set_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `test_sets_questions`
--
ALTER TABLE `test_sets_questions`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=84;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_notification`
--
ALTER TABLE `user_notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `user_ssb_answers`
--
ALTER TABLE `user_ssb_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
