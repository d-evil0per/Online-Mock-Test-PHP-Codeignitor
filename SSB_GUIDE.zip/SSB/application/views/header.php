<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?=$desc?>">
    <meta name="author" content="Deviloper" >
    <meta name="keyword" content="<?=$desc?>">

    <title><?=$title?></title>

    <!-- Bootstrap core CSS -->
    <link href="<?=base_url()?>assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="<?=base_url()?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/css/zabuto_calendar.css">
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/js/gritter/css/jquery.gritter.css" />
    <link rel="stylesheet" type="text/css" href="<?=base_url()?>assets/lineicons/style.css">    
       <link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
  <link rel="apple-touch-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
    <!-- Custom styles for this template -->
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style-responsive.css" rel="stylesheet">
    <!-- Morris Charts CSS -->
    <link href="<?=base_url()?>assets/morrisjs/morris.css" rel="stylesheet">
    <script src="<?=base_url()?>assets/js/jquery.js"></script>
    <script src="<?=base_url()?>assets/js/jquery-1.8.3.min.js"></script>
    <script src="<?=base_url()?>assets/js/chart-master/Chart.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
  
.border-red{
  border-top: 1px solid #da4453;
  opacity: 0.3;
}
.backcolor-yellow{
  background: #ffd777;
}
.backcolor-red{
  background: #da4453;
}
  .color-red{
    color:#da4453;
  }
  .index-content a:hover{
    color:black;
    text-decoration:none;
}
.index-content{
    margin-bottom:20px;
    padding:50px 0px;
    
}
.index-content .row{
    margin-top:20px;
}
.index-content a{
    color: black;
}
.index-content .card{
    background-color: #FFFFFF;
    padding:0;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius:4px;
    box-shadow: 0 4px 5px 0 rgba(0,0,0,0.14), 0 1px 10px 0 rgba(0,0,0,0.12), 0 2px 4px -1px rgba(0,0,0,0.3);

}
.index-content .card:hover{
    box-shadow: 0 16px 24px 2px rgba(0,0,0,0.14), 0 6px 30px 5px rgba(0,0,0,0.12), 0 8px 10px -5px rgba(0,0,0,0.3);
    color:black;
}
.index-content .card img{
    width:100%;
    border-top-left-radius: 4px;
    border-top-right-radius: 4px;
}
.index-content .card h4{
    margin:20px;
}
.index-content .card p{
    margin:20px;
    opacity: 0.65;
}
.index-content .blue-button{
    width: 100px;
    -webkit-transition: background-color 1s , color 1s; /* For Safari 3.1 to 6.0 */
    transition: background-color 1s , color 1s;
    min-height: 20px;
    background-color: #002E5B;
    color: #ffffff;
    border-radius: 4px;
    text-align: center;
    font-weight: lighter;
    margin: 0px 20px 15px 20px;
    padding: 5px 0px;
    display: inline-block;
}
.index-content .blue-button:hover{
    background-color: #dadada;
    color: #002E5B;
}
@media (max-width: 768px) {

    .index-content .col-lg-4 {
        margin-top: 20px;
    }
}
</style>
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
              <div class="sidebar-toggle-box">
                  <div class="fa fa-bars tooltips" data-placement="right" data-original-title="Toggle Navigation"></div>
              </div>
            <!--logo start-->
           <!-- <a href="javascript:void(0)"><img src="assets/img/ui-sam.jpg" class="img-circle" width="60"></a> -->
            <a href="<?=base_url()?>" class="logo"><b>SSB Guide</b></a>
            <!--logo end-->
            <div class="nav notify-row" id="top_menu">
                <!--  notification start -->
                <ul class="nav top-menu">
                    
                    <!-- inbox dropdown start-->
                    <li id="header_inbox_bar" class="dropdown">
                        <a data-toggle="dropdown" class="dropdown-toggle"   href="javascript:void(0)">
                           <i class="fa fa-bell"></i>
                          <?php if($user_notification_count>0) { ?>
                           
                            <span class="badge bg-important"><?=$user_notification_count?></span>
                            <?php } ?>
                        </a>
                        <ul class="dropdown-menu extended inbox" style="word-wrap:break-word; ">
                            <div class="notify-arrow notify-arrow-red"></div>
                            <?php if($user_notification_count>0) { ?>
                            <li>
                                <p class="red">You have <?=$user_notification_count?> new notifications</p>
                            </li>
                            


                           <?php foreach ($user_notification->result() as $key) { ?>
                            
                            <li >
                                <a href="javascript:void(0)">
                                    <!-- <span class="photo"><img alt="avatar" src="<?=$user_avator?>"></span> -->
                                    <span class="subject">
                                    <span class="from"><span class="color-red"><?=$key->notification_from?></span></span>
                                    <span class="time"><?=date('d M y h:iA',strtotime($key->notification_timestamp))?></span>
                                    </span>
                                    <span class="message" >
                                     <b> <?=$key->notification_title?></b><br>
                                        <?=$key->notification_content?>
                                    </span>
                                </a>
                            </li>
                        <?php } ?>
                        
                            <li>
                                <a href="<?=base_url()?>notification"  ><span class="color-red">See all Notification</span></a>
                            </li>
                            <?php } else {?>
                            <li>
                                <a href="javascript:void(0)">
                                
                                    <span class="message color-red">
                                        No New Notifications
                                    </span>
                                </a>
                            </li>
                            <?php } ?>
                        </ul>
                    </li>
                    <!-- inbox dropdown end -->
                </ul>
                <!--  notification end -->
            </div>
            <div class="top-menu">
              <ul class="nav pull-right top-menu">
                    <li><a class="logout" href="<?=base_url()?>home/logout">Logout</a></li>
              </ul>
            </div>
        </header>
      <!--header end-->
      
      <!-- **********************************************************************************************************************************************************
      MAIN SIDEBAR MENU
      *********************************************************************************************************************************************************** -->
      <!--sidebar start-->
      <aside>
          <div id="sidebar"  class="nav-collapse ">
              <!-- sidebar menu start-->
              <ul class="sidebar-menu" id="nav-accordion">
              
                  <p class="centered"><a href="<?=base_url()?>profile"><img src="<?=$user_profile_pic?>" class="img-circle" width="60"></a></p>
                  <h5 class="centered"><?=$user_name?></h5>
                    
                  <li class="mt">
                    <?php if($this->uri->segment(1)=="dashboard") { ?>
                      <a class="active" href="<?=base_url()?>dashboard">
                        <?php } else {?>
                        <a href="<?=base_url()?>dashboard">
                        <?php } ?>
                          <i class="fa fa-dashboard"></i>
                          <span>Dashboard</span>
                      </a>
                  </li>
                   <li class="sub-menu">
                    <?php if($this->uri->segment(1)=="profile") { ?>
                      <a class="active"  href="<?=base_url()?>profile">
                        <?php } else {?>
                        <a  href="<?=base_url()?>profile">
                         <?php } ?>
                          <i class="fa fa-user"></i>
                          <span>My Profile</span>
                      </a>
                  </li>
                    <li class="sub-menu">
                      <?php if($this->uri->segment(1)=="notification") { ?>
                      <a class="active"  href="<?=base_url()?>notification">
                        <?php } else {?>
                        <a  href="<?=base_url()?>notification">
                         <?php } ?>
                          <i class="fa fa-bell"></i>
                          <span>Notification</span>
                      </a>
                  </li>
              

              </ul>
              <!-- sidebar menu end-->
          </div>
      </aside>
      <!--sidebar end-->