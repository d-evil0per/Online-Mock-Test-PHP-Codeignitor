<?php
defined('BASEPATH') OR exit('No direct script access allowed');

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
       <meta name="description" content="<?=$desc?>">
    <meta name="author" content="Deviloper" >
    <meta name="keyword" content="<?=$desc?>">
    <title><?=$title?></title>


    <!-- Bootstrap core CSS -->
    <link href="<?=base_url()?>assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="<?=base_url()?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        
    <!-- Custom styles for this template -->
    <link href="<?=base_url()?>assets/css/style.css" rel="stylesheet">
    <link href="<?=base_url()?>assets/css/style-responsive.css" rel="stylesheet">
<link rel="shortcut icon" type="image/x-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
  <link rel="apple-touch-icon" href="<?=base_url()?>assets/img/SSB_GUIDE.png">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style type="text/css">
      .backred{
  background: #da4453;
  color:#fff;
  padding: 5px;
}

    </style>
  </head>

  <body>

  <section id="container" >
      <!-- **********************************************************************************************************************************************************
      TOP BAR CONTENT & NOTIFICATIONS
      *********************************************************************************************************************************************************** -->
      <!--header start-->
      <header class="header black-bg">
           
            <!--logo start-->
            <a href="javascript:void(0)" class="logo"><b>SSB GUIDE</b></a>
            <!--logo end-->
       
            <div class="top-menu">
            	<ul class="nav pull-right top-menu">
                    <li><a class="logout" href="<?=base_url()?>dashboard">Go TO Dashboard</a></li>
            	</ul>
            </div>
        </header>
      <!--header end-->

      
      <!-- **********************************************************************************************************************************************************
      MAIN CONTENT
      *********************************************************************************************************************************************************** -->
      <!--main content start-->
     
          <section class="wrapper" style="margin-top:80px;border : 1px solid #da4453 !important">
            <center>
          	<h3 class="backred">Instructions</h3>
            <h5><b><?=$test_name?></b></h5>
            <h6>Time : <b><?=$test_time?></b> Mins</h6>
          	<div class="row mt">
          		<div class="col-lg-12">
          		<b><p>Please read the instruction carefully before taking the test.</p></b>
               </center>
              <ul>
               <li>
                <?=$test_instr?>
              </li> 
                </ul>


<center><a class="btn btn-theme05 btn-block" href="<?=base_url()?>skilltest/question/<?=$test_name?>/<?=$test_key?>" style="width:100px"> <b>Start Test</b></a></center>
          		</div>
          	</div>
         
			
		</section><! --/wrapper -->
      </section><!-- /MAIN CONTENT -->

      <!--main content end-->
   
 

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?=base_url()?>assets/js/jquery.js"></script>
    <script src="<?=base_url()?>assets/js/bootstrap.min.js"></script>
    <script src="<?=base_url()?>assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="<?=base_url()?>assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.scrollTo.min.js"></script>
    <script src="<?=base_url()?>assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="<?=base_url()?>assets/js/common-scripts.js"></script>

    <!--script for this page-->
    
  

  </body>
</html>
