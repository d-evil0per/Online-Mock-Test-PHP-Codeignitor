<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0 text-dark">ADD Questions </h1>
            <?php if(isset($_SESSION['upload_session'])) { ?>
             <div class="alert alert-info alert-dismissible">
                  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                  <h5><i class="icon fa fa-info"></i> Alert!</h5>
                  <?php echo $_SESSION['upload_session']; ?>
                </div>
           <?php  }  
           unset($_SESSION['upload_session']);
           ?>
          </div><!-- /.col -->
        
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

   <section class="content">
      <div class="container-fluid">
        <!-- Info boxes -->
        <div class="row">
          <div class="col-12">
            <form method="POST" action="<?=base_url()?>admin_dashboard/import" enctype='multipart/form-data'>
            <div class="card">
            <div class="card-header">
              <h3 class="card-title"> Import/Upload Questions</h3>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-12">
                  
                  <div class="form-group">
                    <label for="t_type">Test Series  <sup>*</sup></label>
                     
                    <select class="form-control"  name="t_type" id="t_type" onchange="get_testset()" required>
                    <option value=""> Select Test Series</option>
                    <?php foreach ($test_series->result() as $tkey) { ?>
                      <option value="<?=$tkey->test_key?>"><?=$tkey->test_name?></option>
                      <?php } ?>
                    </select>
                  </div>
                   <div class="form-group" id="ques_set_list">
                    <label for="t_set">Test Set  <sup>*</sup></label>
                     
                    <select class="form-control"  name="t_set" id="t_set" onchange="chkset()" required>
                      <option value=""></option>
                    
                    </select>


                   </div>
                  <div class="form-group" id="ques_new_set">

                     
                   
                </div>
                <div class="col-12" id="ques_upload_option">
                </div>
             
              </div>
              </div>
              </div>
               <div class="card-footer">
              <button type="submit" class="btn btn-primary"  id="btn_update" >Upload </button>
                 <!--  <button type="button" class="btn btn-primary"  id="btn_update" onclick="upload()">Upload </button> -->
                  
                </div>
                </form>
               </div>
          </div>
        </div>
        <!-- /.row -->
      </div><!--/. container-fluid -->
    </section>
    <script type="text/javascript">
           function previewFile(input) {
    var name= $(input).val();
    $("#label_pic_upload").html(name);
  }




      function clear_files()
      {
        

        $('#U_prev').empty();
        $('#U_upload_file').val("");
        $("#label_u_upload").html("Choose .png, .jpg, .jpeg file");
      
      }


      function U_callimage(reader,i)
{
  reader.onloadend = function () {
        var image=reader.result;
        
       
       
       
        
         $('#U_prev').prepend( "<div class='col-4' id='prev_img_"+i+"'><img id='temp_img_"+i+"' src='"+image+"' name='r_image[]'  style='width:100%;max-height:200px'  ></div>");    // preview.src = reader.result;
     
          
           
       }
}
function U_previewFile(input){

var total_file=document.getElementById("U_upload_file").files.length;
 // var child=$("#U_prev").children().length;
$("#label_u_upload").html(total_file+" images");
// var total=total_file+child;
 if(total_file>10)
 {

 
  alert("You can upload only 10 images in one go.");
  return false;
 }




 for(var i=0;i<total_file;i++)
 {

      // var preview = document.querySelector('img'); //selects the query named img
       var file    = document.getElementById("U_upload_file").files[i]; //sames as here
       var reader  = new FileReader();

       U_callimage(reader,i);

       if (file) {
           reader.readAsDataURL(file); //reads the data as a URL
       } 
     
  
   }
 
}


function chkset()
{
  if($("#t_set").val()=="0")
  {
    // $("#ques_set_list").empty();
    var div='<label for="t_nset">New SET <sup>*</sup></label><input type="text" class="form-control" name="t_nset" id="t_nset" placeholder="Set Name" value="" required></div>';
    $('#ques_new_set').html(div); 
  }
  else
  {
    $('#ques_new_set').html("");
  }
}


function  get_testset()
{
  var t_type=$("#t_type").val();
  if(t_type=="")
  {
    $("#t_set").empty();
    $("#ques_new_set").empty();
    $("#ques_upload_option").empty();
    return false;
  }

 var url="<?=base_url()?>admin_dashboard/get_testset";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{t_type:t_type},
                         dataType: 'json',
                         
                              success: function(data) 
                                  {  
                                    if(data['has_set'])
                                    {
                                     $("#ques_set_list").show(); 
                                     $('#ques_new_set').html("");
                                    $("#t_set").html(data['t_set']);  
                                    }
                                    else
                                    {
                                      $("#ques_set_list").hide();
                                      $("#t_set").removeAttr("required");
                                    $('#ques_new_set').html(data['ques_new_set']);   
                                    }
                                    
                                   
                                   $('#ques_upload_option').html(data['ques_upload_option']);

                                  }
                                });



}


 function upload()
  {
    var sample_image=[];
        var temp=document.getElementsByName("r_image[]");
        for(var i = 0; i < temp.length; i++) {
            sample_image.push(temp[i].src);
        }


    if(sample_image.length==0)
    {
      $("#error_msg").html("Please Upload images ");
      $("#error_msg").show(0).delay(3000).hide(0);
      return false;
    }

       var url="<?=base_url()?>admin_dashboard/upload_ssb_question";
                 $.ajax({
                        
                         type: 'POST',   
                         url: url,
                            data:{sample_image:sample_image},
                         dataType: 'json',
                            beforSend:function()
                            {
                              $("#btn_update").html("Updating..");
                              $("#btn_update").removeAttr("onclick");
                            },
                              success: function(data) 
                                  {  
                                    $("#btn_update").html("Update");
                                    $("#btn_update").attr("onclick","update()");
                                      if(data['status']=="success")
                                      {
                                        // window.location=data['url'];
                                      }
                                  }
                                });
                            

  }

    </script>